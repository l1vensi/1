#version 120
/* VeraLux — bloom, passe 2 : flou vertical large */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex3;
uniform float viewHeight;

varying vec2 uv;

void main() {
    vec3 bloom = vec3(0.0);
    #ifdef BLOOM
        vec2 px = vec2(0.0, 3.0 / viewHeight);
        bloom += texture2D(colortex3, uv).rgb * 0.227;
        bloom += (texture2D(colortex3, uv + px * 1.4).rgb + texture2D(colortex3, uv - px * 1.4).rgb) * 0.194;
        bloom += (texture2D(colortex3, uv + px * 3.3).rgb + texture2D(colortex3, uv - px * 3.3).rgb) * 0.121;
        bloom += (texture2D(colortex3, uv + px * 5.2).rgb + texture2D(colortex3, uv - px * 5.2).rgb) * 0.054;
        bloom += (texture2D(colortex3, uv + px * 7.2).rgb + texture2D(colortex3, uv - px * 7.2).rgb) * 0.016;
        bloom += (texture2D(colortex3, uv + px * 11.5).rgb + texture2D(colortex3, uv - px * 11.5).rgb) * 0.020;
        bloom += (texture2D(colortex3, uv + px * 16.5).rgb + texture2D(colortex3, uv - px * 16.5).rgb) * 0.012;
        bloom += (texture2D(colortex3, uv + px * 24.0).rgb + texture2D(colortex3, uv - px * 24.0).rgb) * 0.007;
        bloom += (texture2D(colortex3, uv + px * 34.0).rgb + texture2D(colortex3, uv - px * 34.0).rgb) * 0.004;
    #endif

/* DRAWBUFFERS:3 */
    gl_FragData[0] = vec4(bloom, 1.0);
}
