#version 120
/* VeraLux — entités (fragment) : éclairage forward + flash de dégâts.
   Écrit aussi normale/albedo pour recevoir les lumières screen-space. */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/distort.glsl"
#include "/lib/lighting.glsl"

uniform sampler2D gtexture;
uniform vec4 entityColor;
#ifdef PBR_TEXTURES
    uniform sampler2D normals;
#endif

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec4 tangent;
varying vec3 viewPos;

void main() {
    vec4 col = texture2D(gtexture, texcoord) * glcolor;
    if (col.a < 0.1) discard;
    col.rgb = mix(col.rgb, entityColor.rgb, entityColor.a);

    vec3 albedo = toLinear(col.rgb);
    float dither = bayer8(gl_FragCoord.xy);

    vec3 nrm = normalize(normal);
    #ifdef PBR_TEXTURES
    {
        vec2 nXY = texture2D(normals, texcoord).xy * 2.0 - 1.0;
        nXY *= NORMAL_STRENGTH;
        float nZ = sqrt(clamp(1.0 - dot(nXY, nXY), 0.0, 1.0));
        vec3 tang = normalize(tangent.xyz);
        vec3 bitang = cross(nrm, tang) * sign(tangent.w);
        nrm = normalize(tang * nXY.x + bitang * nXY.y + nrm * nZ);
    }
    #endif
    vec3 color = shadeSurface(albedo, nrm, lmcoord, viewPos, dither, 0.0);

/* DRAWBUFFERS:0125 */
    gl_FragData[0] = vec4(color, col.a);
    gl_FragData[1] = vec4(nrm * 0.5 + 0.5, 1.0);
    gl_FragData[2] = vec4(lmcoord, 0.02, 0.0);
    gl_FragData[3] = vec4(col.rgb, 1.0);
}
