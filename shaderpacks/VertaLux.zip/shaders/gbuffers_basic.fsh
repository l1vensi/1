#version 120
/* VeraLux — géométrie basique : rendu direct */

varying vec4 glcolor;

void main() {
/* DRAWBUFFERS:0 */
    gl_FragData[0] = glcolor;
}
