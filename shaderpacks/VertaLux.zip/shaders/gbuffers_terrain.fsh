#version 120
/* VeraLux — terrain (fragment) : éclairage forward complet.
   Blocs émissifs (id 20) et lave/feu (id 21, plus intense) deviennent de
   vraies sources HDR ; le terrain écrit normale/albedo/flags pour la passe
   de lumières screen-space. */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/distort.glsl"
#include "/lib/lighting.glsl"

uniform sampler2D gtexture;
#ifdef PBR_TEXTURES
    uniform sampler2D normals;
    uniform sampler2D specular;
#endif

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec4 tangent;
varying vec3 viewPos;
varying float mat;

void main() {
    vec2 tc = texcoord;

    // ===== POM : relief des height maps (labPBR, height = normals.a) =====
    #if defined PBR_TEXTURES && defined PBR_POM
    {
        vec3 tang = normalize(tangent.xyz);
        vec3 bitang = cross(normalize(normal), tang) * sign(tangent.w);
        mat3 tbn = mat3(tang, bitang, normalize(normal));
        vec3 vdirT = (-normalize(viewPos)) * tbn;     // direction vue en espace tangent
        float h = texture2D(normals, tc).a;           // hauteur 0..1 (1 = sommet)
        // Décalage de parallaxe (relief creusé sous la surface)
        vec2 par = vdirT.xy / max(abs(vdirT.z), 0.25) * (h - 1.0) * POM_DEPTH * 0.02;
        tc = texcoord + par;
    }
    #endif

    vec4 col = texture2D(gtexture, tc) * glcolor;
    if (col.a < 0.1) discard;

    vec3 albedo = toLinear(col.rgb);
    // id 10 = feuillage : diffusion sous-surface (la lumière traverse les feuilles)
    float subsurface = (mat > 9.5 && mat < 10.5) ? 1.0 : 0.0;
    bool emissive = (mat > 19.5 && mat < 24.5);
    bool lava = (mat > 20.5 && mat < 21.5);
    bool glass = (mat > 29.5 && mat < 30.5);
    bool portal = (mat > 24.5 && mat < 25.5);
    float dither = bayer8(gl_FragCoord.xy);

    vec3 nrm = normalize(normal);

    // labPBR : normal map du resource pack (relief réel des textures)
    #ifdef PBR_TEXTURES
    {
        vec2 nXY = texture2D(normals, tc).xy * 2.0 - 1.0;
        nXY *= NORMAL_STRENGTH;
        float nZ = sqrt(clamp(1.0 - dot(nXY, nXY), 0.0, 1.0));
        vec3 tang = normalize(tangent.xyz);
        vec3 bitang = cross(nrm, tang) * sign(tangent.w);
        nrm = normalize(tang * nXY.x + bitang * nXY.y + nrm * nZ);
    }
    #endif

    vec3 color = shadeSurface(albedo, nrm, lmcoord, viewPos, dither, subsurface);

    // labPBR : émission par texture (alpha de la specular map, 255 = aucune)
    #ifdef PBR_TEXTURES
    {
        float emisS = texture2D(specular, tc).a;
        if (emisS < 1.0 && emisS > 0.003) {
            color += albedo * emisS * EMISSIVE_BOOST * PBR_EMISSIVE;
        }
    }
    #endif

    if (portal) {
        // Portail : tourbillon énergétique animé. Violet (Nether) ou
        // turquoise spectral (End), selon la teinte de la texture.
        vec3 wp = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;
        float t2 = frameTimeCounter;
        float swirl = fbm(wp.xy * 1.5 + vec2(t2 * 0.3, -t2 * 0.2))
                    + fbm(wp.zy * 1.5 - vec2(t2 * 0.25, t2 * 0.15));
        float pulse = 0.6 + 0.4 * sin(t2 * 2.0 + swirl * 4.0);
        bool isEnd = luma(col.rgb * vec3(0.5, 1.0, 0.9)) > luma(col.rgb * vec3(1.0, 0.5, 1.0));
        vec3 pcol = isEnd ? vec3(0.25, 1.10, 0.95) : vec3(0.85, 0.30, 1.30);
        float bright = smoothstep(0.2, 0.9, swirl * 0.6 + 0.3) * pulse;
        color = albedo * 0.3 + pcol * bright * EMISSIVE_BOOST * 0.8;
    } else if (emissive) {
        // Seules les zones claires de la texture émettent (flamme oui, manche non)
        float eMask = smoothstep(0.30, 0.80, luma(col.rgb));
        if (lava) eMask = max(eMask, 0.65);

        // Chaque famille de sources a SA lumière :
        vec3 eTint = vec3(1.25, 0.95, 0.62);                       // 20 chaud doré
        float eStr = 1.0;
        if (lava)                          { eTint = vec3(1.40, 0.78, 0.38); eStr = 1.6; }
        else if (mat > 21.5 && mat < 22.5) { eTint = vec3(0.35, 0.95, 1.50); }  // âmes : cyan
        else if (mat > 22.5 && mat < 23.5) { eTint = vec3(0.88, 1.02, 1.20); }  // froid lunaire
        else if (mat > 23.5 && mat < 24.5) { eTint = vec3(1.20, 0.62, 1.50); }  // améthyste

        // Vacillement des flammes (torches, feu, lave — pas les blocs froids)
        float flick = 1.0;
        #ifdef EMISSIVE_FLICKER
            if (mat < 22.5) {
                flick = 0.90 + 0.07 * sin(frameTimeCounter * 9.0 + mat * 7.0)
                             + 0.04 * sin(frameTimeCounter * 23.0 + lmcoord.x * 40.0);
            }
        #endif

        vec3 emis = albedo * eMask * EMISSIVE_BOOST * eTint * eStr * flick;

        // ===== LAVE STYLÉE : roche noire + veines incandescentes mouvantes =====
        if (lava) {
            vec3 wp = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;
            float t = frameTimeCounter;
            #ifdef LAVA_ANIMATE
                // Convection : le motif de chaleur ondule et dérive lentement
                vec2 fp = wp.xz * 1.4 + vec2(t * 0.05, -t * 0.04);
                float heat = fbm(fp) * 0.65 + fbm(fp * 2.7 - t * 0.08) * 0.35;
            #else
                float heat = fbm(wp.xz * 1.4);
            #endif
            // Croûte refroidie sombre là où la chaleur est basse, veines vives sinon
            float crust = smoothstep(0.62, 0.34, heat);          // 1 = croûte noire
            float veins = smoothstep(0.55, 0.78, heat);          // 1 = coulée vive
            float hot = smoothstep(0.80, 0.95, heat);            // points blancs-jaunes
            vec3 deepRed  = vec3(0.9, 0.12, 0.02);
            vec3 orange   = vec3(1.7, 0.55, 0.10);
            vec3 yellow   = vec3(2.4, 1.5, 0.45);
            vec3 molten = mix(deepRed, orange, veins) + yellow * hot;
            // pulsation lente de luminosité (respiration du magma)
            float pulse = 0.8 + 0.2 * sin(t * 1.3 + heat * 6.0);
            vec3 lavaCol = molten * EMISSIVE_BOOST * 0.7 * LAVA_GLOW * pulse;
            // la croûte noire éteint l'émission par endroits → contraste fort
            emis = mix(lavaCol, vec3(0.04, 0.01, 0.0), crust * 0.85);
            // teinte l'albédo aussi (la roche elle-même rougeoie)
            color = mix(color, color * vec3(1.3, 0.7, 0.5), 0.4);
        }

        color += emis;
    }

/* DRAWBUFFERS:0125 */
    gl_FragData[0] = vec4(color, col.a);
    gl_FragData[1] = vec4(nrm * 0.5 + 0.5, 1.0);
    float smoothness = 0.0;
    #if defined PBR_TEXTURES && defined PBR_REFLECTIONS
        smoothness = texture2D(specular, tc).r;        // labPBR perceptual smoothness
    #endif
    gl_FragData[2] = vec4(lmcoord, glass ? 0.7 : (lava ? 0.58 : ((emissive || portal) ? 0.5 : 0.0)), smoothness);
    gl_FragData[3] = vec4(col.rgb, 1.0);
}
