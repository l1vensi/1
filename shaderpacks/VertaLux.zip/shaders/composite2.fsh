#version 120
/* VeraLux — bloom, passe 1 : extraction des hautes lumières + flou horizontal large */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform float viewWidth;

varying vec2 uv;

vec3 brightPass(vec2 coord) {
    vec3 col = texture2D(colortex0, coord).rgb;
    return col * smoothstep(BLOOM_THRESHOLD, BLOOM_THRESHOLD + 2.5, luma(col));
}

void main() {
    vec3 bloom = vec3(0.0);
    #ifdef BLOOM
        vec2 px = vec2(3.0 / viewWidth, 0.0);
        bloom += brightPass(uv) * 0.227;
        bloom += (brightPass(uv + px * 1.4) + brightPass(uv - px * 1.4)) * 0.194;
        bloom += (brightPass(uv + px * 3.3) + brightPass(uv - px * 3.3)) * 0.121;
        bloom += (brightPass(uv + px * 5.2) + brightPass(uv - px * 5.2)) * 0.054;
        bloom += (brightPass(uv + px * 7.2) + brightPass(uv - px * 7.2)) * 0.016;
        // Second halo, très large : lueur onirique des sources intenses
        bloom += (brightPass(uv + px * 11.5) + brightPass(uv - px * 11.5)) * 0.020;
        bloom += (brightPass(uv + px * 16.5) + brightPass(uv - px * 16.5)) * 0.012;
        // Halo stellaire ultra-large : l'éclat du soleil, de la lave et des
        // torches se propage jusqu'à des dizaines de pixels (style cinématique)
        bloom += (brightPass(uv + px * 24.0) + brightPass(uv - px * 24.0)) * 0.007;
        bloom += (brightPass(uv + px * 34.0) + brightPass(uv - px * 34.0)) * 0.004;
    #endif

/* DRAWBUFFERS:3 */
    gl_FragData[0] = vec4(bloom, 1.0);
}
