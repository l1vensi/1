#version 120
/* VeraLux — géométrie basique (lignes, laisse, bordure du monde) */

varying vec4 glcolor;

void main() {
    gl_Position = ftransform();
    glcolor = gl_Color;
}
