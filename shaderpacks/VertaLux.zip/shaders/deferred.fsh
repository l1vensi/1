#version 120
/*
    VeraLux — passe deferred : LE CIEL EST PEINT ICI, AVANT les transparents.
    Atmosphère physique + étoiles + soleil/lune + cirrus/altocumulus +
    cumulus volumétriques, écrits sur les pixels de ciel du gbuffer opaque.
    Ainsi le verre et l'eau se fondent naturellement PAR-DESSUS le vrai ciel :
    cohérence parfaite à travers toutes les surfaces transparentes.
*/

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/distort.glsl"
#include "/lib/lighting.glsl"
#include "/lib/atmosphere.glsl"
#include "/lib/sky.glsl"
#include "/lib/clouds.glsl"

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform vec3 skyColor;

varying vec2 uv;

void main() {
    float d0 = texture2D(depthtex0, uv).r;
    vec3 color = texture2D(colortex0, uv).rgb;

    // L'Overworld a une vraie couleur de ciel (skyColor) ; le Nether et l'End
    // non (skyColor ≈ noir). On choisit le rendu de ciel selon la dimension.
    // skyColor → 0 à minuit en Overworld → le test luma seul rate la nuit.
    // fogColor.g > fogColor.r détecte le ciel bleu nocturne de l'Overworld
    // vs violet de l'End (g < r) et orange du Nether (r >> b).
    bool overworld = luma(skyColor) > 0.004 || fogColor.g > fogColor.r;

    if (d0 >= 1.0) {
        vec4 ndc = vec4(uv, d0, 1.0) * 2.0 - 1.0;
        vec4 vw = gbufferProjectionInverse * ndc;
        vec3 worldDir = normalize(mat3(gbufferModelViewInverse) * (vw.xyz / vw.w));
        vec3 sunW = normalize(mat3(gbufferModelViewInverse) * sunPosition);
        vec3 lightW = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
        float dither = bayer8(gl_FragCoord.xy);

        if (!overworld) {
            // === NETHER / END : ciel propre à la dimension (full post-process
            //     conservé car on reste dans le pipeline de base) ===
            bool nether = (fogColor.r > fogColor.b * 1.4);
            if (nether) {
                float down = clamp(-worldDir.y * 0.5 + 0.5, 0.0, 1.0);
                vec3 sky = mix(vec3(0.06, 0.015, 0.008), vec3(0.40, 0.10, 0.035), down * down);
                sky = mix(sky, toLinear(fogColor) * 1.6, 0.4);
                sky *= 0.7 + 0.6 * fbm(worldDir.xz / (abs(worldDir.y) + 0.3) * 2.0 + frameTimeCounter * 0.05);
                color = sky;
            } else {
                // End : vide violet + nébuleuse + étoiles froides
                float up = worldDir.y * 0.5 + 0.5;
                vec3 sky = mix(vec3(0.020, 0.010, 0.045), vec3(0.075, 0.050, 0.120), up);
                vec3 ax = normalize(vec3(0.3, 0.6, 0.74));
                vec3 eu = normalize(cross(ax, vec3(0.0, 1.0, 0.0)));
                vec3 ev = cross(ax, eu);
                vec2 np = vec2(dot(worldDir, eu), dot(worldDir, ev)) * 2.2;
                float sw = atan(np.y, np.x) * 1.5 + length(np) * 2.0 - frameTimeCounter * 0.03;
                float neb = smoothstep(0.35, 0.85, fbm(np * 1.6 + vec2(cos(sw), sin(sw)) * 0.5))
                          * exp(-pow(dot(worldDir, ax) * 1.6, 2.0));
                sky += mix(vec3(0.35, 0.10, 0.55), vec3(0.65, 0.25, 0.85), fbm(np * 3.0 + 9.0)) * neb * 0.8;
                sky += skyStars(worldDir, 0.7);
                color = sky;
            }
        } else {
        #ifdef PHYSICAL_SKY
            color = getSkyPhysical(worldDir, sunW);
        #else
            color = getSkyCelestial(worldDir, sunW);
        #endif

        #if defined CLOUD_LAYER_ALTO || defined CLOUD_LAYER_CIRRUS
            vec4 hc = highClouds(cameraPosition, worldDir, sunW, frameTimeCounter);
            color = mix(color, hc.rgb, hc.a);
        #endif

        // Arc-en-ciel après la pluie : arc primaire à 42° de l'antisolaire,
        // arc secondaire inversé à 51°, plus faible — comme en vrai
        #ifdef RAINBOW
        {
            float wetGlow = wetness * (1.0 - rainStrength)
                          * smoothstep(0.05, 0.3, sunW.y);
            if (wetGlow > 0.01) {
                float a = acos(clamp(dot(worldDir, -sunW), -1.0, 1.0));
                float pos = (a - 0.709) / 0.048;
                if (pos > -0.2 && pos < 1.2) {
                    float band = smoothstep(0.0, 0.18, pos) * smoothstep(1.0, 0.82, pos);
                    vec3 rb = clamp(vec3(smoothstep(0.45, 0.80, pos),
                                         exp(-pow((pos - 0.5) * 3.0, 2.0)),
                                         smoothstep(0.55, 0.20, pos)), 0.0, 1.0);
                    color += rb * band * 0.30 * wetGlow;
                }
                float pos2 = (a - 0.873) / 0.060;
                if (pos2 > -0.2 && pos2 < 1.2) {
                    float band2 = smoothstep(0.0, 0.18, pos2) * smoothstep(1.0, 0.82, pos2);
                    vec3 rb2 = clamp(vec3(smoothstep(0.55, 0.20, pos2),
                                          exp(-pow((pos2 - 0.5) * 3.0, 2.0)),
                                          smoothstep(0.45, 0.80, pos2)), 0.0, 1.0);
                    color += rb2 * band2 * 0.10 * wetGlow;
                }
            }
        }
        #endif

        #ifdef VOLUMETRIC_CLOUDS
            vec4 vc = volumetricClouds(cameraPosition, worldDir, lightW,
                                       getSkyBase(worldDir, sunW),
                                       dither, frameTimeCounter, 1.0e9);
            color = mix(color, vc.rgb, vc.a);
        #endif
        }   // fin du bloc Overworld
    }

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, 1.0);
}
