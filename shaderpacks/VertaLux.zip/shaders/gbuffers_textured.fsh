#version 120
/* VeraLux — particules et divers : éclairage simple sans ombres */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/distort.glsl"
#include "/lib/lighting.glsl"

uniform sampler2D gtexture;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 viewPos;

void main() {
    vec4 col = texture2D(gtexture, texcoord) * glcolor;
    if (col.a < 0.05) discard;

    vec3 albedo = toLinear(col.rgb);
    vec3 light = getAmbientColor() * (lmcoord.y * lmcoord.y * 0.9 + 0.1)
               + getLightColor() * 0.25 * lmcoord.y
               + getTorchColor() * (lmcoord.x * lmcoord.x * 1.5);
    light = max(light, vec3(0.05));

/* DRAWBUFFERS:012 */
    gl_FragData[0] = vec4(albedo * light, col.a);
    gl_FragData[1] = vec4(0.5, 0.5, 0.0, 1.0);
    gl_FragData[2] = vec4(lmcoord, 0.0, 0.0);
}
