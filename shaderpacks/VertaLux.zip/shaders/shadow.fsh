#version 120
/* VeraLux — passe d'ombre : la couleur écrite sert aux ombres colorées (vitraux) */

uniform sampler2D gtexture;

varying vec2 texcoord;
varying vec4 glcolor;

void main() {
    vec4 col = texture2D(gtexture, texcoord) * glcolor;
    if (col.a < 0.1) discard;
    gl_FragData[0] = col;
}
