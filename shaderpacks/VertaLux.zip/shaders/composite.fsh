#version 120
/*
    VeraLux — vraies lumières screen-space + occlusion ambiante (SSAO).
    Lumières : chaque pixel émissif visible (torche, lanterne, lave…) est une
    vraie source : direction réelle, atténuation en 1/d², rayon d'occlusion.
    SSAO : les coins, fissures et zones de contact s'assombrissent.
    Les deux sont lissés par accumulation temporelle (reprojection).
*/

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/distort.glsl"
#include "/lib/lighting.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex4;
uniform sampler2D colortex6;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferPreviousModelView;
uniform mat4 gbufferPreviousProjection;
uniform mat4 shadowModelViewInverse;
uniform mat4 shadowProjectionInverse;
uniform vec3 previousCameraPosition;
uniform float viewWidth;
uniform float viewHeight;
uniform int frameCounter;

varying vec2 uv;

vec3 toView(vec2 coord, float depth) {
    vec4 ndc = vec4(coord, depth, 1.0) * 2.0 - 1.0;
    vec4 v = gbufferProjectionInverse * ndc;
    return v.xyz / v.w;
}

void main() {
    float d0 = texture2D(depthtex0, uv).r;
    vec3 gi = vec3(0.0);
    float ao = 1.0;
    float curDepth = 0.0;

    if (d0 < 1.0) {
        vec3 viewPos = toView(uv, d0);
        curDepth = -viewPos.z;
        vec3 normal = normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0);
        // Jitter par frame : la rotation du motif alimente l'accumulation temporelle
        float frame16 = float(frameCounter - (frameCounter / 16) * 16);
        float dith = fract(bayer8(gl_FragCoord.xy) + frame16 * 0.618034);

        // ============ GLOBAL ILLUMINATION TEMPS RÉEL (SSGI) ============
        // Un rebond indirect : chaque surface reçoit la lumière RÉELLE des
        // surfaces éclairées autour d'elle (colortex0 = scène déjà éclairée).
        // → color bleeding (mur rouge teinte le sol), rebond du soleil et des
        //   torches, lumière colorée à travers les vitraux. C'est de la vraie
        //   simulation de lumière, pas de l'ambiance plate.
        #ifdef RTGI
        {
            float screenR = clamp(RTGI_RADIUS * gbufferProjection[1][1] / curDepth * 0.5, 0.03, 0.55);
            float aspect = viewHeight / viewWidth;
            for (int i = 0; i < GI_SAMPLES; i++) {
                float t = (float(i) + dith) / float(GI_SAMPLES);
                float ang = float(i) * 2.39996 + dith * 6.2831853;
                vec2 off = vec2(cos(ang) * aspect, sin(ang)) * sqrt(t) * screenR;
                vec2 suv = uv + off;
                if (suv.x < 0.0 || suv.x > 1.0 || suv.y < 0.0 || suv.y > 1.0) continue;

                float sd = texture2D(depthtex0, suv).r;
                if (sd >= 1.0) continue;                       // le ciel via l'ambiance
                vec3 np = toView(suv, sd);
                vec3 dvec = np - viewPos;
                float l2 = dot(dvec, dvec);
                if (l2 > RTGI_RADIUS * RTGI_RADIUS || l2 < 0.02) continue;

                vec3 ldir = dvec * inversesqrt(l2);
                float ndl = dot(normal, ldir);                // le rebond vient de devant
                if (ndl <= 0.0) continue;

                // L'émetteur doit faire face au receveur (échange d'énergie)
                vec3 nn = normalize(texture2D(colortex1, suv).rgb * 2.0 - 1.0);
                float face = clamp(dot(nn, -ldir), 0.0, 1.0);

                vec3 bcol = texture2D(colortex0, suv).rgb;
                // Source émissive (torche, lave, lampe…) : vraie lumière, pas
                // juste un rebond diffus → contribution fortement renforcée
                float flagE = texture2D(colortex2, suv).b;
                float emit = (flagE > 0.45 && flagE < 0.65) ? 5.0 : 1.0;
                float w = ndl * (0.30 + 0.70 * face) / (1.0 + l2 * 1.2) * emit;
                // sature le rebond → le color bleeding se voit nettement
                bcol = mix(vec3(luma(bcol)), bcol, 1.7);
                gi += bcol * w;
            }
            gi *= 7.0 / float(GI_SAMPLES) * RTGI_STRENGTH;
        }
        #endif

        // ====== RSM : REBOND DU SOLEIL HORS ÉCRAN (Reflective Shadow Map) ======
        // La shadow map couvre ~shadowDistance blocs AUTOUR du joueur (pas
        // seulement l'écran) et contient la couleur de chaque surface
        // ensoleillée. Chaque texel devient une petite lumière secondaire qui
        // renvoie la lumière du soleil → color bleeding depuis le HORS-CHAMP.
        #ifdef RSM_GI
        {
            vec3 wrel = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
            vec3 wnormal = mat3(gbufferModelViewInverse) * normal;
            // Clip non-distordu du fragment dans la shadow map
            vec4 sc = shadowProjection * (shadowModelView * vec4(wrel, 1.0));
            vec2 baseClip = sc.xy;
            float radClip = RSM_RADIUS / shadowDistance;

            vec3 rsm = vec3(0.0);
            for (int i = 0; i < RSM_SAMPLES; i++) {
                float t = (float(i) + dith) / float(RSM_SAMPLES);
                float ang = float(i) * 2.39996 + dith * 6.2831853;
                vec2 soff = vec2(cos(ang), sin(ang)) * sqrt(t) * radClip;
                vec2 sclip = baseClip + soff;

                // Position de lecture distordue (concentration près du joueur)
                float fdist = getDistortFactor(sclip);
                vec2 ruv = (sclip / fdist) * 0.5 + 0.5;
                if (ruv.x <= 0.0 || ruv.x >= 1.0 || ruv.y <= 0.0 || ruv.y >= 1.0) continue;

                // Reconstruit la position monde du VPL (texel ensoleillé)
                float sd = texture2D(shadowtex1, ruv).r;
                float clipz = (sd * 2.0 - 1.0) * 2.0;          // inverse de distortShadow z
                vec4 vplClip = vec4(sclip, clipz, 1.0);
                vec4 vplW = shadowModelViewInverse * (shadowProjectionInverse * vplClip);
                vec3 vpl = vplW.xyz / vplW.w;

                vec3 dvec = vpl - wrel;
                float l2 = dot(dvec, dvec);
                if (l2 < 0.05 || l2 > RSM_RADIUS * RSM_RADIUS) continue;
                vec3 dir = dvec * inversesqrt(l2);

                float recv = max(dot(wnormal, dir), 0.0);       // le receveur fait face
                if (recv <= 0.0) continue;

                // Albédo de la surface ensoleillée → couleur du rebond
                vec3 valb = texture2D(shadowcolor0, ruv).rgb;
                valb = mix(vec3(luma(valb)), valb, 1.8);   // couleur du bloc accentuée
                rsm += valb * (recv / (l2 + 0.6));
            }
            // Coloré par la lumière du soleil : le rebond porte sa teinte
            gi += rsm * getLightColor() * (16.0 / float(RSM_SAMPLES)) * RSM_STRENGTH;
        }
        #endif

        // ================== VRAIES LUMIÈRES (mode hérité) ==================
        #if defined SS_LIGHTS && !defined RTGI
        {
            // Rayon de recherche : SS_LIGHT_RADIUS blocs, projeté à l'écran
            float screenR = clamp(SS_LIGHT_RADIUS * gbufferProjection[1][1] / curDepth * 0.5, 0.02, 0.45);
            float aspect = viewHeight / viewWidth;

            for (int i = 0; i < GI_SAMPLES; i++) {
                float t = (float(i) + dith) / float(GI_SAMPLES);
                float ang = float(i) * 2.39996 + dith * 6.2831853;
                vec2 off = vec2(cos(ang) * aspect, sin(ang)) * sqrt(t) * screenR;
                vec2 suv = uv + off;
                if (suv.x < 0.0 || suv.x > 1.0 || suv.y < 0.0 || suv.y > 1.0) continue;

                // Seuls les pixels émissifs (flag 0.5) sont des sources
                float flag = texture2D(colortex2, suv).b;
                if (flag < 0.4 || flag > 0.6) continue;

                float sd = texture2D(depthtex0, suv).r;
                if (sd >= 1.0) continue;
                vec3 lightPos = toView(suv, sd);
                vec3 dvec = lightPos - viewPos;
                float l2 = dot(dvec, dvec);
                if (l2 > SS_LIGHT_RADIUS * SS_LIGHT_RADIUS || l2 < 0.01) continue;

                vec3 ldir = dvec * inversesqrt(l2);
                float ndl = dot(normal, ldir);
                if (ndl <= 0.0) continue;

                // Rayon d'ombre : 4 pas le long du segment surface → source
                float occ = 1.0;
                for (int j = 0; j < 4; j++) {
                    float fj = mix(0.15, 0.85, (float(j) + dith) / 4.0);
                    vec3 pp = viewPos + dvec * fj;
                    vec4 c = gbufferProjection * vec4(pp, 1.0);
                    vec2 ouv = (c.xy / c.w) * 0.5 + 0.5;
                    if (ouv.x < 0.0 || ouv.x > 1.0 || ouv.y < 0.0 || ouv.y > 1.0) continue;
                    float oz = toView(ouv, texture2D(depthtex0, ouv).r).z;
                    if (oz > pp.z + 0.08 && oz < pp.z + 1.2) occ -= 0.25;
                }
                occ = max(occ, 0.0);

                vec3 lightCol = texture2D(colortex0, suv).rgb;
                gi += lightCol * (ndl * occ / (l2 + 0.5));
            }
            gi *= 16.0 / float(GI_SAMPLES) * SS_LIGHT_STRENGTH;
        }
        #endif

        // ================== SSAO ==================
        #ifdef AO
        {
            float aoAcc = 0.0;
            vec3 t1v = normalize(abs(normal.y) < 0.9
                ? cross(normal, vec3(0.0, 1.0, 0.0))
                : cross(normal, vec3(1.0, 0.0, 0.0)));
            vec3 t2v = cross(normal, t1v);

            for (int i = 0; i < AO_SAMPLES; i++) {
                float a = float(i) * 2.39996 + dith * 6.2831853;
                float r = sqrt((float(i) + dith) / float(AO_SAMPLES)) * AO_RADIUS;
                vec3 sp3 = viewPos + (t1v * cos(a) + t2v * sin(a)) * r + normal * (r * 0.4 + 0.02);

                vec4 c = gbufferProjection * vec4(sp3, 1.0);
                vec2 suv2 = (c.xy / c.w) * 0.5 + 0.5;
                if (suv2.x <= 0.0 || suv2.x >= 1.0 || suv2.y <= 0.0 || suv2.y >= 1.0) continue;

                float sd2 = texture2D(depthtex0, suv2).r;
                if (sd2 >= 1.0) continue;
                float diffz = toView(suv2, sd2).z - sp3.z;
                // Occulteur devant le point-test, mais pas trop loin (range check)
                if (diffz > 0.02) aoAcc += smoothstep(AO_RADIUS * 2.0, 0.0, diffz);
            }
            ao = clamp(1.0 - aoAcc / float(AO_SAMPLES) * 1.4 * AO_STRENGTH, 0.0, 1.0);
        }
        #endif

        // --- Accumulation temporelle : reprojection vers la frame précédente ---
        vec3 wpos = mat3(gbufferModelViewInverse) * viewPos
                  + gbufferModelViewInverse[3].xyz + cameraPosition;
        vec4 prevClip = gbufferPreviousProjection
                      * (gbufferPreviousModelView * vec4(wpos - previousCameraPosition, 1.0));
        vec2 puv = (prevClip.xy / prevClip.w) * 0.5 + 0.5;
        if (puv.x > 0.0 && puv.x < 1.0 && puv.y > 0.0 && puv.y < 1.0) {
            vec4 hist = texture2D(colortex4, puv);
            if (abs(hist.a - curDepth) < 0.1 * curDepth + 0.5) {
                gi = mix(gi, hist.rgb, RTGI_ACCUM);
                ao = mix(ao, texture2D(colortex6, puv).r, 0.80);
            }
        }
    }

/* DRAWBUFFERS:46 */
    gl_FragData[0] = vec4(gi, curDepth);
    gl_FragData[1] = vec4(ao, 0.0, 0.0, 1.0);
}
