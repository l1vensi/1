#version 120
/* VeraLux — passe finale : FXAA (anti-aliasing) + vignette.
   L'image LDR arrive de composite4 avec sa luminance en alpha. */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex4;
uniform sampler2D colortex5;
uniform sampler2D colortex6;
uniform sampler2D depthtex0;
uniform float viewWidth;
uniform float viewHeight;

varying vec2 uv;

#ifdef FXAA
// FXAA : lisse les escaliers en suivant la direction des contours
vec3 applyFxaa(vec2 coord, vec2 px) {
    float lC = texture2D(colortex0, coord).a;
    float lN = texture2D(colortex0, coord + vec2(0.0, px.y)).a;
    float lS = texture2D(colortex0, coord - vec2(0.0, px.y)).a;
    float lE = texture2D(colortex0, coord + vec2(px.x, 0.0)).a;
    float lW = texture2D(colortex0, coord - vec2(px.x, 0.0)).a;

    float lMin = min(lC, min(min(lN, lS), min(lE, lW)));
    float lMax = max(lC, max(max(lN, lS), max(lE, lW)));

    // Pas de contraste local : rien à lisser
    if (lMax - lMin < max(0.0312, lMax * 0.125)) {
        return texture2D(colortex0, coord).rgb;
    }

    float lNW = texture2D(colortex0, coord + vec2(-px.x,  px.y)).a;
    float lNE = texture2D(colortex0, coord + vec2( px.x,  px.y)).a;
    float lSW = texture2D(colortex0, coord + vec2(-px.x, -px.y)).a;
    float lSE = texture2D(colortex0, coord + vec2( px.x, -px.y)).a;

    vec2 dir = vec2(-((lNW + lNE) - (lSW + lSE)), (lNW + lSW) - (lNE + lSE));
    float dirReduce = max((lNW + lNE + lSW + lSE) * 0.03125, 0.0078125);
    float rcpDirMin = 1.0 / (min(abs(dir.x), abs(dir.y)) + dirReduce);
    dir = clamp(dir * rcpDirMin, vec2(-8.0), vec2(8.0)) * px;

    vec3 rgbA = 0.5 * (texture2D(colortex0, coord + dir * (1.0 / 3.0 - 0.5)).rgb
                     + texture2D(colortex0, coord + dir * (2.0 / 3.0 - 0.5)).rgb);
    vec3 rgbB = rgbA * 0.5 + 0.25 * (texture2D(colortex0, coord - dir * 0.5).rgb
                                   + texture2D(colortex0, coord + dir * 0.5).rgb);

    float lB = luma(rgbB);
    if (lB < lMin || lB > lMax) return rgbA;
    return rgbB;
}
#endif

void main() {
    #ifdef FXAA
        vec3 color = applyFxaa(uv, 1.0 / vec2(viewWidth, viewHeight));
    #else
        vec3 color = texture2D(colortex0, uv).rgb;
    #endif

    // Netteté adaptative : re-croque les textures après le FXAA
    #ifdef SHARPEN
    {
        vec2 pxS = 1.0 / vec2(viewWidth, viewHeight);
        vec3 blurS = (texture2D(colortex0, uv + vec2(0.0,  pxS.y)).rgb
                    + texture2D(colortex0, uv - vec2(0.0,  pxS.y)).rgb
                    + texture2D(colortex0, uv + vec2(pxS.x, 0.0)).rgb
                    + texture2D(colortex0, uv - vec2(pxS.x, 0.0)).rgb) * 0.25;
        color = clamp(color + (color - blurS) * 0.38, 0.0, 1.0);
    }
    #endif

    // ---- Vues de débogage (menu Debug, en bas à droite) ----
    #if DEBUG_VIEW > 0
        bool dbg = true;
        #ifdef DEBUG_SPLIT
            // Écran scindé : image finale à gauche, vue debug à droite
            dbg = uv.x > 0.5;
            if (abs(uv.x - 0.5) < 0.0015) color = vec3(1.0, 0.8, 0.0);
        #endif
        if (dbg) {
            #if DEBUG_VIEW == 1
                color = texture2D(colortex1, uv).rgb;                   // normales
            #elif DEBUG_VIEW == 2
                color = vec3(texture2D(colortex6, uv).r);               // SSAO
            #elif DEBUG_VIEW == 3
                color = texture2D(colortex4, uv).rgb * 0.25;            // vraies lumières
            #elif DEBUG_VIEW == 4
                float dd = texture2D(depthtex0, uv).r;
                color = vec3(pow(dd, 64.0));                            // profondeur
            #elif DEBUG_VIEW == 5
                float fl = texture2D(colortex2, uv).b;                  // matériaux
                color = vec3(0.0);
                if (fl > 0.9) color = vec3(0.1, 0.3, 1.0);              // eau
                else if (fl > 0.6) color = vec3(0.2, 1.0, 0.8);         // verre
                else if (fl > 0.4) color = vec3(1.0, 0.6, 0.1);         // émissif
            #elif DEBUG_VIEW == 6
                color = vec3(texture2D(colortex2, uv).rg, 0.0);         // lightmap
            #elif DEBUG_VIEW == 7
                color = texture2D(colortex5, uv).rgb;                   // albedo
            #elif DEBUG_VIEW == 8
                color = texture2D(colortex3, uv).rgb;                   // bloom
            #elif DEBUG_VIEW == 9
                color = vec3(texture2D(colortex2, uv).g);               // lumière du ciel
            #elif DEBUG_VIEW == 10
                color = vec3(texture2D(colortex2, uv).r) * vec3(1.0, 0.55, 0.2); // torche
            #elif DEBUG_VIEW == 11
                float dM = texture2D(depthtex0, uv).r;
                color = (dM >= 1.0) ? vec3(0.1, 0.2, 0.5) : vec3(0.05); // masque ciel
            #elif DEBUG_VIEW == 12
                color = vec3(luma(texture2D(colortex0, uv).rgb));       // luminance
            #endif
        }
    #endif

    vec2 vc = uv - 0.5;
    color *= 1.0 - dot(vc, vc) * VIGNETTE;

    gl_FragColor = vec4(color, 1.0);
}
