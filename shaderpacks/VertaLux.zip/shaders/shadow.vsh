#version 120
/* VeraLux — passe d'ombre : rendu de la scène depuis le soleil, avec distorsion */

#include "/lib/settings.glsl"
#include "/lib/distort.glsl"

varying vec2 texcoord;
varying vec4 glcolor;

void main() {
    gl_Position = ftransform();
    float f = getDistortFactor(gl_Position.xy);
    gl_Position.xyz = distortShadow(gl_Position.xyz, f);

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor = gl_Color;
}
