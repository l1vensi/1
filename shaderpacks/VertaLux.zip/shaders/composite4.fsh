#version 120
/*
    VeraLux — TAA (Temporal Anti-Aliasing).
    Reprojection du pixel vers la frame précédente, accumulation temporelle
    de l'image HDR → anti-aliasing naturel + stabilisation du bruit GI/SSAO.
    Neighborhood clamping (AABB de la 3×3 voisine) pour éviter les fantômes
    sur la géométrie en mouvement ou les nouvelles occultations.
    Le blend 88/12 lisse fortement sans flouter les détails fins.
    Si TAA est désactivé : simple pass-through, colortex7 = frame actuelle.
*/

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;

/*
const int   colortex7Format  = RGBA16F;
const bool  colortex7Clear   = false;
*/

uniform sampler2D colortex0;
uniform sampler2D colortex7;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferPreviousProjection;
uniform mat4 gbufferPreviousModelView;
uniform vec3 previousCameraPosition;
uniform float viewWidth;
uniform float viewHeight;

varying vec2 uv;

vec3 toView(vec2 coord, float depth) {
    vec4 ndc = vec4(coord, depth, 1.0) * 2.0 - 1.0;
    vec4 v = gbufferProjectionInverse * ndc;
    return v.xyz / v.w;
}

void main() {
    vec3 current = texture2D(colortex0, uv).rgb;
    vec3 result  = current;

#ifdef TAA
    float d0 = texture2D(depthtex0, uv).r;
    vec2 px = 1.0 / vec2(viewWidth, viewHeight);

    // ---- Reprojection : UV de ce pixel dans la frame précédente ----
    vec2 histUV = uv;
    float blendFactor = 0.12;

    if (d0 < 1.0) {
        vec3 viewPos = toView(uv, d0);
        vec3 wpos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;
        vec4 prevClip = gbufferPreviousProjection
                      * (gbufferPreviousModelView * vec4(wpos - previousCameraPosition, 1.0));
        if (prevClip.w > 0.001) {
            histUV = (prevClip.xy / prevClip.w) * 0.5 + 0.5;
            if (histUV.x < 0.0 || histUV.x > 1.0 || histUV.y < 0.0 || histUV.y > 1.0)
                blendFactor = 1.0;
        } else {
            blendFactor = 1.0;
        }
    }

    // ---- Neighborhood clamping (AABB 3×3) ----
    // Évite les fantômes : l'historique est clamped dans la plage de couleurs
    // des voisins immédiats — quand la géométrie se déplace, les fantômes
    // sont rejetés avant d'être blendés.
    vec3 cMin = current, cMax = current;
    for (int ox = -1; ox <= 1; ox++) {
        for (int oy = -1; oy <= 1; oy++) {
            if (ox == 0 && oy == 0) continue;
            vec3 nc = texture2D(colortex0, uv + vec2(float(ox), float(oy)) * px).rgb;
            cMin = min(cMin, nc);
            cMax = max(cMax, nc);
        }
    }
    // Légère relaxation de l'AABB pour ne pas rendre le TAA trop instable
    vec3 cMid = (cMin + cMax) * 0.5;
    cMin = mix(cMin, cMid, 0.10);
    cMax = mix(cMax, cMid, 0.10);

    vec3 history = clamp(texture2D(colortex7, histUV).rgb, cMin, cMax);
    result = mix(history, current, blendFactor);
#endif

    // DRAWBUFFERS unique : colortex0 (image composite) + colortex7 (historique)
    // Quand TAA est off, result == current → colortex7 = frame actuelle (innocuous)
/* DRAWBUFFERS:07 */
    gl_FragData[0] = vec4(result, 1.0);
    gl_FragData[1] = vec4(result, 1.0);
}
