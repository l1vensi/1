#version 120
/* VeraLux — terrain (vertex) : balancement du feuillage au vent */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

attribute vec4 mc_Entity;
attribute vec4 at_tangent;

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform float rainStrength;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec4 tangent;
varying vec3 viewPos;
varying float mat;

void main() {
    mat = mc_Entity.x;

    vec4 pos = gl_ModelViewMatrix * gl_Vertex;

    #ifdef WAVING_FOLIAGE
        // Le feuillage ondule doucement, plus fort sous la pluie
        if (mat > 9.5 && mat < 10.5) {
            vec4 wp = gbufferModelViewInverse * pos;
            vec3 absW = wp.xyz + cameraPosition;
            float aqua = step(absW.y, WATER_LEVEL - 0.2);  // 1 = plante aquatique
            bool doWave = true;
            #ifndef WAVING_WATER_PLANTS
                if (aqua > 0.5) doWave = false;            // plantes d'eau figées
            #endif
            if (doWave) {
                // Sous l'eau : balancement lent et ample ; au vent : plus vif
                float t = frameTimeCounter * WAVING_SPEED * (1.0 - 0.5 * aqua);
                float amp = 0.022 * WAVING_STRENGTH * (1.0 + rainStrength * 1.5)
                          * (1.0 + aqua * 1.8);
                wp.x += sin(absW.x * 0.6 + absW.y * 0.3 + t * 1.7)
                      * sin(absW.z * 0.5 + t * 1.3) * amp;
                wp.z += sin(absW.z * 0.7 + absW.y * 0.2 + t * 1.4) * amp * 0.7;
                pos = gbufferModelView * wp;
            }
        }
    #endif

    viewPos = pos.xyz;
    gl_Position = gl_ProjectionMatrix * pos;

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;
    normal   = normalize(gl_NormalMatrix * gl_Normal);
    tangent  = vec4(normalize(gl_NormalMatrix * at_tangent.xyz), at_tangent.w);
}
