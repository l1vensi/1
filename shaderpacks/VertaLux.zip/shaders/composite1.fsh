#version 120
/*
    VeraLux — passe d'atmosphère, d'eau et de verre :
    ciel physique + nuages multi-couches (devant le terrain lointain aussi),
    BROUILLARD VOLUMÉTRIQUE avec ombres (les montagnes et les builds creusent
    des puits d'ombre dans la brume), vraies lumières + SSAO,
    eau océanique, sous-l'eau cinématique (soleil visible à travers la
    surface, rayons divins sculptés par les vagues), verre.
*/

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/distort.glsl"
#include "/lib/lighting.glsl"
#include "/lib/atmosphere.glsl"
#include "/lib/water.glsl"
#include "/lib/sky.glsl"
#include "/lib/clouds.glsl"

/*
const int colortex0Format = RGBA16F;
const int colortex1Format = RGB16;
const int colortex2Format = RGBA8;
const int colortex3Format = RGB16F;
const int colortex4Format = RGBA16F;
const int colortex5Format = RGB8;
const int colortex6Format = RGBA8;
const bool colortex4Clear = false;
const bool colortex6Clear = false;
*/

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex4;
uniform sampler2D colortex5;
uniform sampler2D colortex6;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelView;
uniform float far;
uniform int isEyeInWater;
uniform ivec2 eyeBrightnessSmooth;
uniform vec4 lightningBoltPosition;

varying vec2 uv;

vec3 toView(vec2 coord, float depth) {
    vec4 ndc = vec4(coord, depth, 1.0) * 2.0 - 1.0;
    vec4 v = gbufferProjectionInverse * ndc;
    return v.xyz / v.w;
}

// Visibilité solaire en un échantillon (caustiques masquées dans l'ombre)
float shadowVis1(vec3 vPos) {
    vec3 sc = toShadowClip(vPos, vec3(0.0));
    float f = getDistortFactor(sc.xy);
    vec3 sp = distortShadow(sc, f) * 0.5 + 0.5;
    if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0) return 1.0;
    return step(sp.z - 0.001, texture2D(shadowtex1, sp.xy).r);
}

#ifdef SSR_ENABLED
// Raymarch en espace vue avec raffinement binaire ; hit = confiance (0 = raté)
vec2 ssrRay(vec3 origin, vec3 dir, float dither, out float hit) {
    hit = 0.0;
    vec3 p = origin + dir * (0.25 + dither * 0.25);
    float stepLen = 0.5;

    for (int i = 0; i < 24; i++) {
        vec3 prev = p;
        p += dir * stepLen;
        vec4 clip = gbufferProjection * vec4(p, 1.0);
        vec3 ndc = clip.xyz / clip.w;
        if (abs(ndc.x) > 1.0 || abs(ndc.y) > 1.0) return vec2(0.0);

        vec2 suv = ndc.xy * 0.5 + 0.5;
        float sd = texture2D(depthtex0, suv).r;
        if (sd < 1.0) {
            vec3 sview = toView(suv, sd);
            if (p.z < sview.z && p.z > sview.z - stepLen * 4.0 - 1.0) {
                vec3 lo = prev;
                vec3 hi = p;
                for (int k = 0; k < 4; k++) {
                    vec3 mid = (lo + hi) * 0.5;
                    vec4 mc = gbufferProjection * vec4(mid, 1.0);
                    vec2 muv = (mc.xy / mc.w) * 0.5 + 0.5;
                    float md = texture2D(depthtex0, muv).r;
                    if (mid.z < toView(muv, md).z) hi = mid; else lo = mid;
                }
                vec4 hc = gbufferProjection * vec4(hi, 1.0);
                vec2 huv = (hc.xy / hc.w) * 0.5 + 0.5;
                hit = smoothstep(1.0, 0.85, max(abs(hc.x / hc.w), abs(hc.y / hc.w)));
                return huv;
            }
        }
        stepLen *= 1.35;
    }
    return vec2(0.0);
}
#endif

void main() {
    float d0 = texture2D(depthtex0, uv).r;
    vec3 viewPos = toView(uv, d0);
    vec3 viewDir = normalize(viewPos);
    vec3 worldDir = mat3(gbufferModelViewInverse) * viewDir;
    vec3 sunW = normalize(mat3(gbufferModelViewInverse) * sunPosition);
    vec3 lightW = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);

    vec3 color = texture2D(colortex0, uv).rgb;
    float dither = bayer8(gl_FragCoord.xy);
    bool isSky = d0 >= 1.0;
    float dist = isSky ? far : length(viewPos);

    // Détecte si l'œil est dans une construction en verre submergée :
    // caméra sous le niveau d'eau + lumière de ciel présente (cave = 0) +
    // matériaux eau/verre visibles dans la scène.
    // La lumière de ciel filtre même à travers l'eau → eyeBrightnessSmooth.y > 0
    // dans du verre submergé mais ≈ 0 dans une cave sèche.
    bool inGlassUW = false;
    if (isEyeInWater == 0 && cameraPosition.y < WATER_LEVEL - 0.3) {
        float skyFr = float(eyeBrightnessSmooth.y) / 240.0;
        if (skyFr > 0.06) {
            // Sampler 5 points fixes — eau (b>0.88) ou verre (0.57<b<0.85)
            float b0 = texture2D(colortex2, vec2(0.50, 0.50)).b;
            float b1 = texture2D(colortex2, vec2(0.20, 0.50)).b;
            float b2 = texture2D(colortex2, vec2(0.80, 0.50)).b;
            float b3 = texture2D(colortex2, vec2(0.50, 0.20)).b;
            float b4 = texture2D(colortex2, vec2(0.50, 0.80)).b;
            float scoreWG = 0.0;
            scoreWG += max(step(0.88, b0), step(0.57, b0) * (1.0 - step(0.85, b0)));
            scoreWG += max(step(0.88, b1), step(0.57, b1) * (1.0 - step(0.85, b1)));
            scoreWG += max(step(0.88, b2), step(0.57, b2) * (1.0 - step(0.85, b2)));
            scoreWG += max(step(0.88, b3), step(0.57, b3) * (1.0 - step(0.85, b3)));
            scoreWG += max(step(0.88, b4), step(0.57, b4) * (1.0 - step(0.85, b4)));
            inGlassUW = scoreWG >= 2.0;
        }
    }

    if (isSky) {
        // Le ciel (atmosphère + nuages) est déjà peint dans la passe deferred,
        // AVANT les transparents : color le contient déjà.
    } else {
        vec4 data2 = texture2D(colortex2, uv);
        vec3 world0 = mat3(gbufferModelViewInverse) * viewPos + cameraPosition;
        float skyl = data2.g * data2.g;

        // ===================== EAU =====================
        if (data2.b > 0.95) {
            vec3 normalV = normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0);

            vec3 localLight = getAmbientColor() * skyl
                            + getLightColor() * 0.5 * skyl
                            + getTorchColor() * data2.r * data2.r * 1.5;
            #ifdef SS_LIGHTS
                localLight += texture2D(colortex4, uv).rgb;
            #endif

            vec3 vp1pre = toView(uv, texture2D(depthtex1, uv).r);
            float wdepth0 = max(distance(viewPos, vp1pre), 0.0);

            vec2 ruv = uv;
            #ifdef WATER_REFRACTION
                // Décalage de réfraction, beaucoup plus faible quand l'œil est
                // SOUS l'eau (sinon la surface vue d'en bas s'étire et bave)
                float refScale = (isEyeInWater == 1) ? 0.04 : 0.13;
                vec2 refOff = normalV.xy * (refScale / max(length(viewPos) * 0.5, 1.0))
                            * clamp(wdepth0 * 1.5, 0.0, 1.0) * REFRACTION_STRENGTH;
                ruv = clamp(uv + refOff, vec2(0.001), vec2(0.999));
                if (texture2D(depthtex0, ruv).r >= texture2D(depthtex1, ruv).r - 1e-6) ruv = uv;
                color = texture2D(colortex0, ruv).rgb;
            #endif

            vec3 vp1 = toView(ruv, texture2D(depthtex1, ruv).r);
            float wdepth = max(distance(viewPos, vp1), 0.0);
            vec3 world1 = mat3(gbufferModelViewInverse) * vp1 + cameraPosition;

            if (isEyeInWater == 0) {
                #ifdef WATER_CAUSTICS
                    // vdep = profondeur VERTICALE d'eau au-dessus du sol
                    // (c'est la vraie distance parcourue par la lumière, pas camera→sol)
                    float vdep = max(world0.y - world1.y, 0.0);
                    vec2 cpos = world1.xz + lightW.xz / max(lightW.y, 0.2) * vdep;
                    float cscaleU = 0.55 + 0.90 * vnoise(world1.xz * 0.13 + frameTimeCounter * 0.04);
                    // Flou physique : cônes de lumière s'élargissent avec la distance
                    // parcourue dans l'eau → 0 net en surface, flou total à ~5 blocs
                    float dbU = clamp((vdep - 0.3) * 0.24, 0.0, 1.0);
                    float bdR = dbU * 0.42;
                    vec2 bd1 =  vec2( bdR,  bdR * 0.55);
                    vec2 bd2 =  vec2(-bdR * 0.65,  bdR * 0.50);
                    vec3 caS = vec3(
                        waveCaustic(cpos + lightW.xz * 0.013, frameTimeCounter),
                        waveCaustic(cpos, frameTimeCounter),
                        waveCaustic(cpos - lightW.xz * 0.013, frameTimeCounter)
                    );
                    vec3 caF1 = vec3(
                        waveCaustic(cpos + bd1 + lightW.xz * 0.013, frameTimeCounter),
                        waveCaustic(cpos + bd1, frameTimeCounter),
                        waveCaustic(cpos + bd1 - lightW.xz * 0.013, frameTimeCounter)
                    );
                    vec3 caF2 = vec3(
                        waveCaustic(cpos + bd2 + lightW.xz * 0.013, frameTimeCounter),
                        waveCaustic(cpos + bd2, frameTimeCounter),
                        waveCaustic(cpos + bd2 - lightW.xz * 0.013, frameTimeCounter)
                    );
                    vec3 caV = mix(caS, (caS + caF1 + caF2) / 3.0, dbU) * cscaleU;
                    float sunF = smoothstep(-0.05, 0.2, lightHeight()) * (1.0 - rainStrength);
                    sunF *= shadowVis1(vp1);
                    // Absorption Beer-Lambert par canal (rouge absorbe 4× plus vite que bleu)
                    // → filet devient bleu-vert en profondeur, puis disparaît
                    vec3 beerLambert = exp(-vdep * vec3(0.70, 0.30, 0.14));
                    float caFade = (1.0 - dbU * 0.70);
                    color *= 1.0 + caV * CAUSTIC_STRENGTH * skyl * sunF * caFade * beerLambert;
                #endif

                // Eau du biome : la teinte vanilla (colortex5) pilote tout —
                // marais vert et trouble, océan bleu profond, eau chaude claire
                vec3 tintS = texture2D(colortex5, uv).rgb;
                float murk = 1.0 - luma(tintS);
                vec3 absorbCoeff = (vec3(0.028)
                                 + pow(vec3(1.0) - tintS, vec3(2.0)) * (0.22 + murk * 0.55)) * 1.0;
                vec3 absorb = exp(-wdepth * absorbCoeff / WATER_CLARITY);
                // Radiance remontante : l'océan vu de haut est SOMBRE
                // (bleu-vert profond), pas cyan laiteux
                vec3 scatter = toLinear(tintS)
                             * (localLight * 0.40 + getLightColor() * 0.06 * skyl);
                color = color * absorb + scatter * (1.0 - absorb);

                // Haze de profondeur verticale : la colonne d'eau au-dessus du fond
                // absorbe la lumière indépendamment de l'angle de vue.
                // Sans ça, le fond reste visible à grande profondeur vu depuis la surface.
                float vertColH = clamp(WATER_LEVEL - world1.y, 0.0, 22.0);
                float depthHaze = (1.0 - exp(-vertColH * 0.038)) * 0.68;
                color = mix(color, scatter, depthHaze);

                #ifdef WATER_FOAM
                    float foam = 1.0 - smoothstep(0.0, 0.32, wdepth0);
                    float fpat = fbm(world0.xz * 2.5 + frameTimeCounter * 0.15);
                    foam *= smoothstep(0.40, 0.78, fpat + foam * 0.3);
                    vec3 foamCol = vec3(0.9, 0.95, 1.0) * localLight * 0.85;
                    color = mix(color, foamCol, clamp(foam, 0.0, 1.0) * 0.8 * FOAM_AMOUNT);
                #endif
            }

            // --- Reflets : Fresnel + fenêtre de Snell + SSR + glint ---
            float fres = 0.02 + 0.98 * pow(1.0 - clamp(dot(normalV, -viewDir), 0.0, 1.0), 5.0);
            #ifdef UNDERWATER_FX
            if (isEyeInWater == 1) {
                // Fenêtre de Snell physique : angle critique eau→air = 48.6°
                // cos(48.6°)≈0.661 → transition nette, 2-3° seulement en réalité
                float window = smoothstep(0.63, 0.69, worldDir.y);
                // Hors fenêtre (regard oblique) : réflexion interne totale
                // Dans la fenêtre (regard vers le haut) : on voit à travers
                fres = mix(0.92, fres * 0.22, window);
                // Dispersion spectrale à l'arête : les longueurs d'onde se
                // séparent légèrement à l'angle critique → frange colorée
                float dispEdge = window * (1.0 - window) * 4.0;
                if (dispEdge > 0.02) {
                    vec2 dOff = normalV.xy * dispEdge * 0.006;
                    color.r = mix(color.r, texture2D(colortex0, clamp(ruv + dOff, vec2(0.001), vec2(0.999))).r, dispEdge * 0.50);
                    color.b = mix(color.b, texture2D(colortex0, clamp(ruv - dOff, vec2(0.001), vec2(0.999))).b, dispEdge * 0.50);
                }
            }
            #endif
            #ifdef SSR_ENABLED
                vec3 rdir2 = reflect(viewDir, normalV);
                vec3 rworld = normalize(mat3(gbufferModelViewInverse) * rdir2);
                vec3 refl = getSkyAll(rworld, sunW) * skyl;
                float hit;
                vec2 hituv = ssrRay(viewPos, rdir2, dither, hit);
                if (hit > 0.0) refl = mix(refl, texture2D(colortex0, hituv).rgb, hit);
                #ifdef UNDERWATER_FX
                if (isEyeInWater == 1 && hit < 0.5) {
                    // Réflexion interne totale : fallback = eau profonde, pas le ciel
                    float windowFB = smoothstep(0.63, 0.69, worldDir.y);
                    if (windowFB < 0.8) {
                        float camD = clamp((WATER_LEVEL - cameraPosition.y) / 10.0, 0.0, 1.0);
                        vec3 uwFB = mix(vec3(0.04, 0.28, 0.44), vec3(0.0008, 0.006, 0.016), camD * camD)
                                  * (getAmbientColor() * 0.35 + getLightColor() * 0.05 * skyl);
                        refl = mix(uwFB, refl, windowFB + hit * (1.0 - windowFB));
                    }
                }
                #endif
                color = mix(color, refl, clamp(fres, 0.0, 1.0) * 0.72 * WATER_REFLECTIVITY);
            #endif
            vec3 L = normalize(shadowLightPosition);
            vec3 H = normalize(L - viewDir);
            // Le reflet du soleil s'élargit au loin (rugosité apparente de la
            // houle) : pointe nette aux pieds, large sentier à l'horizon
            float specPow = mix(320.0, 36.0, clamp(dist / 160.0, 0.0, 1.0));
            float spec = pow(clamp(dot(normalV, H), 0.0, 1.0), specPow);
            color += getLightColor() * spec * fres * 1.15 * WATER_REFLECTIVITY * WATER_SUN_GLINT * smoothstep(0.7, 0.95, data2.g);

            // Sentier de soleil : reflet large qui s'étire sur la houle,
            // pailleté de micro-facettes scintillantes
            float ndh = clamp(dot(normalV, H), 0.0, 1.0);
            float trail = pow(ndh, 26.0) * 0.09 * WATER_REFLECTIVITY;
            float spark = 0.0;
            #ifdef WATER_SPARKLE
                float sparkN = vnoise(world0.xz * 2.2 + frameTimeCounter * 0.8);
                spark = smoothstep(0.70, 0.92, sparkN) * pow(ndh, 20.0)
                      * WATER_SPARKLE_AMOUNT;
            #endif
            color += getLightColor() * (trail + spark)
                   * smoothstep(0.7, 0.95, data2.g) * (1.0 - rainStrength);

            // Moutons d'écume sur les crêtes les plus hautes (plus par vent/pluie)
            #ifdef WHITECAPS
            {
                float hCrest = waveHeight(world0.xz, frameTimeCounter);
                float capThresh = 1.02 - rainStrength * 0.20;
                float cap = smoothstep(capThresh, capThresh + 0.25, hCrest);
                cap *= smoothstep(0.35, 0.7, fbm(world0.xz * 1.8 + frameTimeCounter * 0.2));
                vec3 capCol = vec3(0.92, 0.96, 1.0)
                            * (getAmbientColor() + getLightColor() * 0.5) * 0.85 * skyl;
                color = mix(color, capCol, clamp(cap, 0.0, 1.0) * 0.60 * FOAM_AMOUNT);
            }
            #endif

        // ===================== VERRE =====================
        } else if (data2.b > 0.6 && data2.b < 0.8) {
            #ifdef GLASS_EFFECTS
                vec3 normalV = normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0);

                vec2 guv = clamp(uv + normalV.xy * 0.006 * GLASS_REFRACTION,
                                 vec2(0.001), vec2(0.999));
                if (texture2D(depthtex0, guv).r >= texture2D(depthtex1, guv).r - 1e-6) guv = uv;
                color = texture2D(colortex0, guv).rgb;

                // Base sous-marine : vitre et fond sous le niveau de la mer →
                // l'eau entre les deux absorbe et diffuse (visible de l'intérieur)
                if (world0.y < WATER_LEVEL - 0.2 && isEyeInWater == 0) {
                    vec3 vpB = toView(guv, texture2D(depthtex1, guv).r);
                    vec3 worldB = mat3(gbufferModelViewInverse) * vpB + cameraPosition;
                    if (worldB.y < WATER_LEVEL - 0.1) {
                        float wd = max(distance(vpB, viewPos), 0.0);
                        float gateUw = smoothstep(0.08, 0.35, data2.g);
                        vec3 absorbG = exp(-wd * vec3(0.20, 0.09, 0.05) * 1.0);
                        vec3 scatG = vec3(0.05, 0.30, 0.42) * 1.25
                                   * (getAmbientColor() + getLightColor() * 0.2) * skyl;
                        vec3 fogged = color * absorbG + scatG * (1.0 - absorbG);
                        color = mix(color, fogged, gateUw);
                    }
                }

                float fres = 0.04 + 0.96 * pow(1.0 - clamp(dot(normalV, -viewDir), 0.0, 1.0), 5.0);
                // Verre submergé : reflets + spéculaire atténués et teintés eau
                float uwGlass = clamp((WATER_LEVEL - world0.y) / 4.0, 0.0, 1.0)
                              * float(isEyeInWater == 0);
                #ifdef SSR_ENABLED
                    vec3 rdir = reflect(viewDir, normalV);
                    vec3 rworld = normalize(mat3(gbufferModelViewInverse) * rdir);
                    // Fallback sous-marin : eau profonde au lieu du ciel dégagé
                    vec3 uwReflFB = vec3(0.04, 0.22, 0.38)
                                  * (getAmbientColor() * 0.45 + getLightColor() * 0.06);
                    vec3 refl = mix(getSkyAll(rworld, sunW) * skyl, uwReflFB, uwGlass * 0.80);
                    float hit;
                    vec2 hituv = ssrRay(viewPos, rdir, dither, hit);
                    if (hit > 0.0) refl = mix(refl, texture2D(colortex0, hituv).rgb, hit);
                    float ssrAmt = mix(0.85, 0.38, uwGlass);
                    color = mix(color, refl, clamp(fres, 0.0, 1.0) * ssrAmt);
                #endif

                vec3 L = normalize(shadowLightPosition);
                vec3 H = normalize(L - viewDir);
                float spec = pow(clamp(dot(normalV, H), 0.0, 1.0), 400.0);
                float specStr = mix(5.0, 1.0, uwGlass);
                color += getLightColor() * spec * fres * specStr * smoothstep(0.5, 0.9, data2.g);
            #endif

        // ============== SURFACES OPAQUES ==============
        } else {
            #ifdef AO
                float ao = texture2D(colortex6, uv).r;
                color *= mix(1.0, ao, 0.9);
            #endif

            #ifdef CONTACT_SHADOWS
            // Screen-Space Contact Shadows : court ray-march vers le soleil
            // en espace vue → rattrape les ombres portées entre blocs adjacents
            // que la shadow map 2k manque (un bloc qui cache son voisin immédiat).
            if (skyl > 0.08) {
                vec3 lightVS = normalize(shadowLightPosition);
                vec3 csPos = viewPos;
                float sscs = 1.0;
                for (int csi = 0; csi < 6; csi++) {
                    csPos += lightVS * (0.04 + float(csi) * 0.09);
                    vec4 clip = gbufferProjection * vec4(csPos, 1.0);
                    if (clip.w <= 0.0) break;
                    vec2 csUV = clip.xy / clip.w * 0.5 + 0.5;
                    if (csUV.x < 0.0 || csUV.x > 1.0 || csUV.y < 0.0 || csUV.y > 1.0) break;
                    float csD = texture2D(depthtex0, csUV).r;
                    if (csD >= 1.0) break;
                    vec3 csVP = toView(csUV, csD);
                    float diff = csPos.z - csVP.z;
                    if (diff > 0.04 && diff < 0.7) { sscs = 0.0; break; }
                }
                color *= mix(1.0, sscs, skyl * 0.48);
            }
            #endif

            #if defined RTGI || defined SS_LIGHTS
                // Lumière indirecte (rebond GI) réinjectée, teintée par l'albédo
                vec3 alb = toLinear(texture2D(colortex5, uv).rgb);
                color += texture2D(colortex4, uv).rgb * alb;
            #endif

            // ===== Reflets PBR : surfaces lisses du resource pack (labPBR) =====
            #if defined PBR_TEXTURES && defined PBR_REFLECTIONS && defined SSR_ENABLED
            {
                // On inhibe les reflets PBR quand data2.b est élevé (pixel alpha-blendé
                // avec l'eau : particule/entité devant l'eau qui hérite du flag eau)
                float smooth2 = data2.a * (1.0 - smoothstep(0.01, 0.12, data2.b));
                if (smooth2 > 0.04) {
                    vec3 nO = normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0);
                    float fres = 0.03 + 0.97 * pow(1.0 - clamp(dot(nO, -viewDir), 0.0, 1.0), 5.0);
                    vec3 rdir = reflect(viewDir, nO);
                    vec3 rworld = normalize(mat3(gbufferModelViewInverse) * rdir);
                    vec3 refl = getSkyAll(rworld, sunW) * skyl;       // repli : ciel
                    float hit;
                    vec2 huv = ssrRay(viewPos, rdir, dither, hit);
                    if (hit > 0.0) refl = mix(refl, texture2D(colortex0, huv).rgb, hit);
                    // métaux : reflet teinté par l'albédo ; diélectriques : neutre
                    vec3 alb2 = toLinear(texture2D(colortex5, uv).rgb);
                    vec3 tint = mix(vec3(1.0), alb2, smooth2 * smooth2 * 0.7);
                    float amt = smooth2 * smooth2 * fres * PBR_REFLECT_STRENGTH;
                    color = mix(color, refl * tint, clamp(amt, 0.0, 0.9));
                }
            }
            #endif

            // Rive mouillée : bande sombre et satinée au bord de l'eau
            #ifdef WET_SHORELINE
            if (isEyeInWater == 0 && world0.y > WATER_LEVEL - 0.8 && world0.y < WATER_LEVEL + 0.9 && skyl > 0.05) {
                float wn2 = 0.0;
                for (int i = 0; i < 4; i++) {
                    float aa = float(i) * 1.5708 + 0.785;
                    vec2 nuv2 = uv + vec2(cos(aa), sin(aa)) * 0.07;
                    if (nuv2.x > 0.0 && nuv2.x < 1.0 && nuv2.y > 0.0 && nuv2.y < 1.0) {
                        if (texture2D(colortex2, nuv2).b > 0.95) wn2 = 1.0;
                    }
                }
                if (wn2 > 0.5) {
                    float bandW = smoothstep(WATER_LEVEL + 0.9, WATER_LEVEL, world0.y);
                    color *= 1.0 - 0.20 * bandW;
                    vec3 nVs = normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0);
                    float fresS = 0.04 + 0.5 * pow(1.0 - clamp(dot(nVs, -viewDir), 0.0, 1.0), 5.0);
                    vec3 rws = normalize(mat3(gbufferModelViewInverse) * reflect(viewDir, nVs));
                    color += getSkyBase(rws, sunW) * skyl * fresS * bandW * 0.35;
                }
            }
            #endif

            // Minecraft supprime les faces d'eau collées au verre : un sol
            // immergé vu à travers une vitre arrive ici SANS eau devant.
            // On reconstitue l'absorption de la colonne d'eau traversée.
            if (isEyeInWater == 0 && world0.y < WATER_LEVEL - 0.2 && skyl > 0.05 && data2.b < 0.01) {
                float waterNear = 0.0;
                for (int i = 0; i < 16; i++) {
                    float aa = float(i) * 0.7853982;
                    float rr = (i < 8) ? 0.10 : 0.24;
                    vec2 nuv = uv + vec2(cos(aa), sin(aa)) * rr;
                    if (nuv.x > 0.0 && nuv.x < 1.0 && nuv.y > 0.0 && nuv.y < 1.0) {
                        if (texture2D(colortex2, nuv).b > 0.95) waterNear = 1.0;
                    }
                }
                if (waterNear > 0.5) {
                    float tCross = (cameraPosition.y > WATER_LEVEL - 0.1 && abs(worldDir.y) > 1e-4)
                                 ? max((WATER_LEVEL - 0.1 - cameraPosition.y) / worldDir.y, 0.0) : 0.0;
                    float wd = clamp(dist - tCross, 0.0, 48.0);
                    vec3 absorbU = exp(-wd * vec3(0.20, 0.09, 0.05) * 0.8 / WATER_CLARITY);
                    vec3 scatU = vec3(0.05, 0.30, 0.42)
                               * (getAmbientColor() + getLightColor() * 0.2) * skyl;
                    color = color * absorbU + scatU * (1.0 - absorbU);
                }
            }

            #ifdef RAIN_WET
                if (wetness > 0.01) {
                    vec3 nV = normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0);
                    vec3 nWup = mat3(gbufferModelViewInverse) * nV;
                    // smoothstep : sol sec sous abri (skyl<0.08), mouillé à l'air libre
                    float wet = wetness * smoothstep(0.08, 0.55, skyl) * clamp(nWup.y, 0.0, 1.0);
                    if (wet > 0.001) {
                        // Flaques ridées : les gouttes font onduler les reflets
                        if (rainStrength > 0.02) {
                            vec3 nWr = mat3(gbufferModelViewInverse) * nV;
                            vec2 cellR = floor(world0.xz * 1.5);
                            vec2 frR = fract(world0.xz * 1.5) - 0.5;
                            vec2 hitR = vec2(hash12(cellR + 3.7), hash12(cellR + 8.1)) - 0.5;
                            vec2 dxzR = frR - hitR * 0.5;
                            float rrR = length(dxzR);
                            float phR2 = fract(frameTimeCounter * 1.3 + hash12(cellR) * 9.0);
                            float ringR = cos((rrR - phR2 * 0.4) * 30.0)
                                        * exp(-pow((rrR - phR2 * 0.4) * 10.0, 2.0)) * (1.0 - phR2);
                            nWr.xz += (dxzR / max(rrR, 0.03)) * ringR * 0.7 * rainStrength * wet;
                            nV = normalize(mat3(gbufferModelView) * normalize(nWr));
                        }
                        // Sol sombre et brillant
                        color *= 1.0 - 0.22 * wet;
                        float fresW = 0.05 + 0.70 * pow(1.0 - clamp(dot(nV, -viewDir), 0.0, 1.0), 5.0);
                        vec3 rVS = reflect(viewDir, nV);
                        vec3 rwd = normalize(mat3(gbufferModelViewInverse) * rVS);
                        // Pendant la pluie : ciel couvert mais flaques bien visibles
                        float reflSky = max(skyl, rainStrength * 0.40);
                        #ifdef SSR_ENABLED
                        {
                            // SSR : cherche la géométrie voisine reflétée (bords de blocs, murs)
                            float ssrHit;
                            vec2 ssrUV = ssrRay(viewPos, rVS, dither, ssrHit);
                            if (ssrHit > 0.0) {
                                color += texture2D(colortex0, ssrUV).rgb * fresW * wet * 0.65 * ssrHit;
                                color += getSkyBase(rwd, sunW) * reflSky * fresW * wet * 0.80 * (1.0 - ssrHit);
                            } else {
                                color += getSkyBase(rwd, sunW) * reflSky * fresW * wet * 0.80;
                            }
                        }
                        #else
                            color += getSkyBase(rwd, sunW) * reflSky * fresW * wet * 0.80;
                        #endif
                        // Glint du soleil même sous la pluie
                        vec3 Hw = normalize(normalize(shadowLightPosition) - viewDir);
                        float gl2 = pow(clamp(dot(nV, Hw), 0.0, 1.0), 90.0);
                        color += getLightColor() * gl2 * wet * fresW * 2.5 * (0.20 + 0.80 * (1.0 - rainStrength));
                    }
                }
            #endif

            #ifdef WATER_CAUSTICS
            {
                // CAUSTIQUES PHYSIQUES : elles apparaissent là où le soleil
                // TRAVERSE de l'eau avant d'atteindre le sol — c'est-à-dire
                // dans l'OMBRE colorée de l'eau (détectée via la shadow map).
                // La lumière réfractée par les vagues se focalise → toile
                // lumineuse dansante. Plus de caustiques fantômes partout.
                float causticAmt = 0.0;
                vec3 waterTint = vec3(0.2, 0.6, 0.8);

                if (isEyeInWater == 0) {
                    // Au-dessus : on regarde si la lumière passe par de l'eau
                    vec3 sc = toShadowClip(viewPos, vec3(0.0, 1.0, 0.0));
                    float fdc = getDistortFactor(sc.xy);
                    vec3 sp = distortShadow(sc, fdc) * 0.5 + 0.5;
                    if (sp.x > 0.0 && sp.x < 1.0 && sp.y > 0.0 && sp.y < 1.0) {
                        float zb = sp.z - 0.0009;
                        float opaqueClear = step(zb, texture2D(shadowtex1, sp.xy).r);
                        float allClear    = step(zb, texture2D(shadowtex0, sp.xy).r);
                        // Lumière bloquée par un translucide (pas par l'opaque)
                        if (opaqueClear > 0.5 && allClear < 0.5) {
                            vec3 tcol = texture2D(shadowcolor0, sp.xy).rgb;
                            float waterness = clamp((tcol.b - tcol.r) + (tcol.g - tcol.r), 0.0, 1.0);
                            causticAmt = waterness;
                            if (waterness > 0.01) waterTint = tcol / max(luma(tcol), 0.1);
                        }
                    }
                }

                if (causticAmt > 0.01) {
                    // Profondeur réelle d'eau au-dessus du fragment (capped à 8 blocs)
                    float wdepAbove = clamp(WATER_LEVEL - world0.y, 0.5, 8.0);
                    vec2 cpos = world0.xz + lightW.xz / max(lightW.y, 0.15) * wdepAbove;
                    float cscaleS = 0.55 + 0.90 * vnoise(world0.xz * 0.13 + frameTimeCounter * 0.04);
                    float dbS = clamp((wdepAbove - 0.3) * 0.24, 0.0, 1.0);
                    float bdRS = dbS * 0.40;
                    vec2 bdS1 =  vec2( bdRS,  bdRS * 0.55);
                    vec2 bdS2 =  vec2(-bdRS * 0.65,  bdRS * 0.50);
                    vec3 caSharpS = vec3(
                        waveCaustic(cpos + lightW.xz * 0.013, frameTimeCounter),
                        waveCaustic(cpos, frameTimeCounter),
                        waveCaustic(cpos - lightW.xz * 0.013, frameTimeCounter)
                    );
                    vec3 caFS1 = vec3(
                        waveCaustic(cpos + bdS1 + lightW.xz * 0.013, frameTimeCounter),
                        waveCaustic(cpos + bdS1, frameTimeCounter),
                        waveCaustic(cpos + bdS1 - lightW.xz * 0.013, frameTimeCounter)
                    );
                    vec3 caFS2 = vec3(
                        waveCaustic(cpos + bdS2 + lightW.xz * 0.013, frameTimeCounter),
                        waveCaustic(cpos + bdS2, frameTimeCounter),
                        waveCaustic(cpos + bdS2 - lightW.xz * 0.013, frameTimeCounter)
                    );
                    vec3 caBlurS = (caSharpS + caFS1 + caFS2) / 3.0;
                    // Beer-Lambert couleur : rouge disparaît vite, bleu persiste
                    vec3 beerS = exp(-wdepAbove * vec3(0.65, 0.28, 0.12));
                    vec3 caV2 = clamp(
                        mix(caSharpS, caBlurS, dbS) - 0.35, 0.0, 1.0
                    ) * cscaleS * (1.0 - dbS * 0.65) * beerS;
                    float sunF = smoothstep(-0.05, 0.2, lightHeight()) * (1.0 - rainStrength);
                    color += getLightColor() * waterTint * caV2 * causticAmt
                           * CAUSTIC_STRENGTH * 0.18 * sunF;
                }
            }
            #endif
        }

        // Éclair d'orage : le paysage s'embrase autour du point d'impact
        #ifdef LIGHTNING_FX
        if (lightningBoltPosition.w > 0.5) {
            float ldist = distance(world0.xz, lightningBoltPosition.xz);
            float burst = 16.0 / (1.0 + ldist * ldist * 0.002);
            color += vec3(0.72, 0.80, 1.0) * burst * 0.13 * skyl;
        }
        #endif

        // --- Perspective aérienne légère (le volumétrique fait le reste) ---
        vec3 fogCol = getSkyBase(worldDir, sunW);
        // Atmosphère par biome : Minecraft fournit fogColor (chaude/tan au
        // désert, verte en marais, glacée en taïga…) — on teinte la brume
        #ifdef BIOME_ATMOSPHERE
            vec3 biomeFog = toLinear(fogColor) * 1.6;
            if (luma(fogColor) > 0.001) {
                fogCol = mix(fogCol, biomeFog * (0.4 + luma(fogCol)),
                             0.55 * BIOME_ATMO_STRENGTH * smoothstep(0.0, 0.4, skyl));
            }
        #endif
        float fogF = 1.0 - exp(-pow(dist / (far * 0.85), 2.5) * 0.75 * FOG_DENSITY);
        color = mix(color, fogCol, clamp(fogF, 0.0, 1.0));

        // --- Ambiance de grotte : brume colorée dans les zones sans ciel ---
        #ifdef CAVE_FOG
        if (isEyeInWater == 0) {
            float cave = (1.0 - skyl) * smoothstep(0.0, 0.35, 1.0 - data2.g);
            float depthCave = clamp((WATER_LEVEL - world0.y) / 64.0, 0.0, 1.0);
            float cf = (1.0 - exp(-dist * 0.018)) * cave * CAVE_FOG_STRENGTH;
            vec3 caveCol = mix(vec3(0.04, 0.06, 0.10), vec3(0.10, 0.05, 0.08), depthCave)
                         + getTorchColor() * data2.r * data2.r * 0.15;
            color = mix(color, caveCol, clamp(cf, 0.0, 0.7));
        }
        #endif
    }

    // --- Verre submergé : reproduit les effets eau à l'intérieur d'une structure ---
    if (inGlassUW) {
        float gwDepth = max(WATER_LEVEL - cameraPosition.y, 0.0);
        float gwDeep  = clamp(gwDepth / 10.0, 0.0, 1.0);
        float eyeSK   = float(eyeBrightnessSmooth.y) / 240.0;
        float d_gw    = max(gwDeep * gwDeep, 1.0 - eyeSK);
        vec3 gwShallow = vec3(0.04, 0.28, 0.44);
        vec3 gwDeepC   = vec3(0.0008, 0.006, 0.016);
        vec3 gwFogC = mix(gwShallow, gwDeepC, d_gw * d_gw)
                    * (getAmbientColor() * (0.38 - d_gw * 0.25) + getLightColor() * 0.09);
        // Densité augmentée pour une vraie ambiance sous-marine
        float gwFogDens = 0.055 + gwDeep * gwDeep * gwDeep * 0.22;
        color = mix(color, gwFogC, 1.0 - exp(-dist * gwFogDens * WATER_FOG_DENSITY));
        #ifdef UNDERWATER_FX
            float eyeSkyGW = float(eyeBrightnessSmooth.y) / 240.0;
            // Ambient isotrope de base
            color += getAmbientColor() * 0.032 * eyeSkyGW * (1.0 - gwDeep);
            // Halo bleu-vert filtré depuis l'eau au-dessus (disparaît avec la profondeur)
            color += vec3(0.05, 0.28, 0.46) * 0.024 * eyeSkyGW * (1.0 - gwDeep * gwDeep);
        #endif
    }

    // --- Cumulus volumétriques : aussi DEVANT le terrain lointain ---
    #ifdef VOLUMETRIC_CLOUDS
    {
        // Les pixels dont le fond est le ciel ont déjà leurs nuages (deferred,
        // sous les transparents). Ici : seulement les nuages qui passent
        // DEVANT du terrain opaque lointain.
        float d1c = texture2D(depthtex1, uv).r;
        if (isEyeInWater == 0 && d1c < 1.0) {
            float distO = length(toView(uv, d1c));
            vec3 cloudFog = getSkyBase(worldDir, sunW);
            vec4 vc = volumetricClouds(cameraPosition, worldDir, lightW, cloudFog,
                                       dither, frameTimeCounter, distO);
            color = mix(color, vc.rgb, vc.a);
        }
    }
    #endif

    // --- Sous l'eau : brouillard gradué + lueur du soleil + particules ---
    if (isEyeInWater == 1) {
        float deep = 1.0 - float(eyeBrightnessSmooth.y) / 240.0;
        float camDepth = max(WATER_LEVEL - cameraPosition.y, 0.0);
        float physDeep = clamp(camDepth / 12.0, 0.0, 1.0);
        // Absorber la lumière résiduelle MIN_LIGHT en profondeur.
        // Sans ça, le moteur de Minecraft maintient un éclairage minimal
        // visible même à 15m de fond — on l'écrase progressivement.
        color *= 1.0 - physDeep * physDeep * 0.84;
        float d = max(deep, physDeep * physDeep);
        // 3 stades de couleur comme en vrai :
        //   0-3m : bleu-vert clair  →  4-8m : bleu profond  →  >8m : quasi-noir
        vec3 shallowC = vec3(0.040, 0.280, 0.440);
        vec3 midC     = vec3(0.006, 0.040, 0.095);
        vec3 deepC    = vec3(0.0006, 0.004, 0.012);
        float midBlend  = smoothstep(0.0, 0.55, physDeep);
        float deepBlend = smoothstep(0.55, 1.0,  physDeep);
        vec3 fogBaseC = mix(mix(shallowC, midC, midBlend * midBlend),
                            deepC, deepBlend * deepBlend);
        vec3 wfogC = fogBaseC
                   * (getAmbientColor() * (0.38 - d * 0.30) + getLightColor() * 0.09);
        float fogDens = 0.038 + physDeep * physDeep * physDeep * 0.210;
        color = mix(color, wfogC, 1.0 - exp(-dist * fogDens * WATER_FOG_DENSITY));

        #ifdef UNDERWATER_FX
            // Ambient ISOTROPE basé sur eyeBrightness → pas de rayon vertical fictif
            // (les vrais god rays sont gérés par le VL, pas ici)
            float eyeSkyFr = float(eyeBrightnessSmooth.y) / 240.0;
            color += getAmbientColor() * 0.030 * eyeSkyFr * (1.0 - physDeep * physDeep);
            #ifdef UW_VIGNETTE
            float uvVig = dot(uv - 0.5, uv - 0.5);
            color *= 1.0 - uvVig * physDeep * physDeep * 3.0;
            #endif
        #endif

        #ifdef UW_PARTICLES
            // Marine snow / plancton : particules en suspension éclairées par le soleil
            float sunFP = smoothstep(-0.05, 0.2, lightHeight()) * (1.0 - rainStrength);
            for (int i = 0; i < 5; i++) {
                float fi = float(i);
                float pd = 1.5 + fi * 3.0;
                if (pd > dist) break;
                // Dérive lente (ascendance + courant latéral)
                vec3 drift = vec3(frameTimeCounter * 0.018, frameTimeCounter * (0.05 + fi * 0.009), frameTimeCounter * 0.013);
                vec3 wp = cameraPosition + worldDir * pd + drift;
                float n1 = vnoise3(wp * 5.5);
                float n2 = vnoise3(wp * 13.0 + 19.3);
                // Petites particules denses + rares grosses
                float sp = smoothstep(0.970, 0.999, n1 * 0.55 + n2 * 0.45)
                         + smoothstep(0.992, 1.000, n1) * 0.30;
                // Teinte bleu-vert, plus lumineuse là où la lumière vient d'en haut
                vec3 pCol = mix(vec3(0.28, 0.55, 0.70), vec3(0.50, 0.78, 0.90), n2)
                          * (0.10 + 0.22 * sunFP * max(lightW.y, 0.0));
                color += sp * pCol * exp(-pd * 0.11)
                       * (0.5 + 0.5 * (1.0 - physDeep)) * (1.0 - physDeep * 0.55);
            }
        #endif
    }

    /*
        --- BROUILLARD VOLUMÉTRIQUE UNIFIÉ ---
        Un seul raymarch : brume de hauteur (les vallées se remplissent, les
        builds émergent) + rayons de soleil dans l'air, le tout ombré par la
        shadow map → les montagnes creusent des puits d'ombre dans la brume.
        Sous l'eau : rayons divins sculptés par le champ de vagues.
    */
    #ifdef VOLUMETRIC_LIGHT
    {
        // On marche jusqu'au terrain OPAQUE (depthtex1), pas jusqu'au verre
        // ou la surface d'eau : les rayons et la brume traversent donc les
        // surfaces transparentes (bases sous-marines, baies vitrées).
        float d1v = texture2D(depthtex1, uv).r;
        float distVol = (d1v >= 1.0) ? far : length(toView(uv, d1v));
        float marchEnd = min(distVol, (isEyeInWater == 1) ? 48.0 : 160.0);
        float dt = marchEnd / float(VL_SAMPLES);
        vec3 stepV = viewDir * dt;
        vec3 p = stepV * dither;
        vec3 scat = vec3(0.0);
        float transF = 1.0;
        vec3 blockFog = vec3(0.0);

        float duskF = clamp(1.0 - abs(sunHeight()) * 4.0, 0.0, 1.0);
        float eyeSky = float(eyeBrightnessSmooth.y) / 240.0;
        float hfDens = 0.0;
        #ifdef HEIGHT_FOG
            hfDens = HEIGHT_FOG_DENSITY * (0.004 + duskF * 0.009 + rainStrength * 0.012)
                   * (0.35 + 0.65 * eyeSky);
        #endif
        float airDens = 0.0008 * VL_STRENGTH;

        float cosT = dot(viewDir, normalize(shadowLightPosition));
        // Sous l'eau : légèrement directionnel (l'eau diffuse vers l'avant ~gP 0.5–0.6)
        // → les faisceaux sont visibles sans être aussi laser que dans l'air
        float gP = (isEyeInWater == 1) ? 0.58 : 0.60;
        float phase = (1.0 - gP * gP) / (12.566 * pow(1.0 + gP * gP - 2.0 * gP * cosT, 1.5));
        vec3 lightC = getLightColor();
        lightC = max(lightC, vec3(0.10, 0.15, 0.26) * smoothstep(0.04, 0.30, lightHeight()));
        vec3 ambC = getAmbientColor();
        if (isEyeInWater == 1 || inGlassUW) {
            // Teinte bleu-vert saturée, assez lumineuse pour que les shafts soient visibles
            // (verre légèrement atténué via × 0.85 vs eau directe × 1.05)
            float uwMult = (isEyeInWater == 1) ? 1.05 : 0.85;
            lightC *= vec3(0.32, 0.68, 0.92) * uwMult;
            ambC *= vec3(0.08, 0.28, 0.48);
        }
        // Les rayons directionnels n'existent que si l'astre est levé : sinon
        // pas de "rayons de midi" la nuit ou sous terre
        float lightUp = smoothstep(-0.04, 0.14, lightHeight());

        for (int i = 0; i < VL_SAMPLES; i++) {
            p += stepV;
            vec3 wp = mat3(gbufferModelViewInverse) * p + cameraPosition;

            // Tronçon immergé : soit l'œil EST dans l'eau, soit ce point du
            // rayon est DERRIÈRE une surface d'eau vue de l'extérieur (on
            // projette le point à l'écran et on regarde s'il y a de l'eau
            // devant) → les rayons sont sculptés par les vagues dans les DEUX
            // cas (sous l'eau ET en regardant l'eau depuis la berge).
            float uw = (isEyeInWater == 1) ? 1.0 : 0.0;
            if (isEyeInWater == 0) {
                vec4 pc = gbufferProjection * vec4(p, 1.0);
                vec2 puv = (pc.xy / pc.w) * 0.5 + 0.5;
                if (puv.x > 0.0 && puv.x < 1.0 && puv.y > 0.0 && puv.y < 1.0) {
                    float matB = texture2D(colortex2, puv).b;
                    bool isWater = matB > 0.95;
                    bool isGlass = matB > 0.55 && matB < 0.85 && wp.y < WATER_LEVEL - 0.3;
                    if (isWater || isGlass) {
                        vec3 wsv = toView(puv, texture2D(depthtex0, puv).r);
                        if (p.z < wsv.z) uw = isWater ? 1.0 : 0.55;
                    }
                    // Verre submergé : toutes les zones sous le niveau d'eau reçoivent
                    // les shafts même quand on est à l'intérieur de la structure
                    if (inGlassUW && uw < 0.5 && wp.y < WATER_LEVEL - 0.2) uw = 0.60;
                }
            }
            float dens;
            if (isEyeInWater == 1 || (inGlassUW && uw > 0.4)) {
                dens = 0.026;
            } else {
                // Brume par NAPPES : bancs irréguliers qui dérivent
                float patchy = 0.45 + 1.10 * vnoise(wp.xz * 0.012 + frameTimeCounter * 0.015);
                dens = airDens + hfDens * exp(-max(wp.y - WATER_LEVEL, 0.0) * 0.025 / HEIGHT_FOG_FALLOFF) * patchy
                     + uw * 0.020;
                // Nappe de brume au ras de l'eau, à l'aube et au crépuscule
                dens += exp(-abs(wp.y - (WATER_LEVEL + 1.3)) * 0.55) * duskF * 0.012 * HEIGHT_FOG_DENSITY
                      * (0.3 + 0.7 * vnoise(wp.xz * 0.025 + frameTimeCounter * 0.02));
                // Précipitation : filaments de pluie animés vers le bas — visibles
                // dans les rayons volumétriques (les gouttes diffusent la lumière)
                #ifdef VL_RAIN
                if (rainStrength > 0.01) {
                    vec3 rp3 = vec3(wp.x * 3.5 + wp.z * 3.5,
                                    wp.y * 0.05 - frameTimeCounter * 5.0,
                                    wp.x * 2.1 - wp.z * 2.1);
                    float rn = vnoise3(rp3);
                    dens += rainStrength * smoothstep(0.80, 0.94, rn) * 0.0028;
                }
                #endif
            }

            // Visibilité du soleil (ombres portées dans la brume, vitraux colorés)
            vec3 vis = vec3(1.0);
            vec3 sc = toShadowClip(p, vec3(0.0));
            float f = getDistortFactor(sc.xy);
            vec3 sp = distortShadow(sc, f) * 0.5 + 0.5;
            if (sp.x > 0.0 && sp.x < 1.0 && sp.y > 0.0 && sp.y < 1.0) {
                float zb = sp.z - 0.0008;
                float s1 = step(zb, texture2D(shadowtex1, sp.xy).r);
                float s0 = step(zb, texture2D(shadowtex0, sp.xy).r);
                vec3 c = vec3(1.0);
                if (s0 < s1) c = texture2D(shadowcolor0, sp.xy).rgb;
                vis = vec3(s1) * mix(c, vec3(1.0), s0);
            }

            // Les nuages au-dessus ombrent la brume (cohérence ciel/sol)
            #ifdef VOLUMETRIC_CLOUDS
            #ifdef VC_GROUND_SHADOWS
                vis *= cloudShadow(wp, lightW);
            #endif
            #endif

            // Tronçon immergé (œil sous l'eau OU base vitrée) : rayons
            // sculptés par les vagues, inclinés le long du soleil.
            // Ils s'éteignent au-delà de ~10 blocs (réalisme + perfs) :
            // la lumière est vite absorbée par l'eau.
            // Note : pas de modulation caustic dans le VL.
            // Quand lightW.xz ≈ 0 (soleil haut), cpos est constant pour tous
            // les steps d'un rayon vertical → même cmod sur toute la colonne
            // → colonnes bleues fantômes sans rapport avec le soleil.
            // Les vrais shafts viennent des ombres du shadow map (vis ci-dessus) ;
            // les caustiques restent visibles sur les surfaces opaques.

            // Sous l'eau : ambient quasi nul — la lumière vient UNIQUEMENT de la surface
            // (c'est ce qui crée les shafts directionnels, pas une lueur isotrope)
            float ambM = (uw > 0.25) ? 0.008 : 0.22;
            vec3 S = lightC * vis * phase * lightUp + ambC * ambM;
            float a = exp(-dens * dt);
            scat += transF * S * (1.0 - a);
            transF *= a;

            // Halo thermique des blocs incandescents (lava, feu, torches) :
            // l'air environnant s'illumine d'une lueur orange-rouge chaude
            #ifdef LAVA_ANIMATE
            if (isEyeInWater == 0) {
                vec4 lvc = gbufferProjection * vec4(p, 1.0);
                vec2 lvuv = (lvc.xy / lvc.w) * 0.5 + 0.5;
                if (lvuv.x > 0.0 && lvuv.x < 1.0 && lvuv.y > 0.0 && lvuv.y < 1.0) {
                    float matB = texture2D(colortex2, lvuv).b;
                    if (matB > 0.45 && matB < 0.65) {
                        float lvd = texture2D(depthtex0, lvuv).r;
                        if (lvd < 1.0) {
                            float emDist = length(p - toView(lvuv, lvd));
                            scat += vec3(0.92, 0.36, 0.08) * exp(-emDist * 0.60)
                                   * 0.009 * LAVA_GLOW * transF;
                        }
                    }
                }
            }
            #endif

            #if defined VL_BLOCKLIGHT && (defined SS_LIGHTS || defined RTGI)
                vec4 fc = gbufferProjection * vec4(p, 1.0);
                vec2 fuv = (fc.xy / fc.w) * 0.5 + 0.5;
                if (fuv.x > 0.0 && fuv.x < 1.0 && fuv.y > 0.0 && fuv.y < 1.0) {
                    float fd = texture2D(depthtex0, fuv).r;
                    if (fd >= 1.0 || p.z > toView(fuv, fd).z) {
                        blockFog += texture2D(colortex4, fuv).rgb;
                    }
                }
            #endif
        }

        // Brume analytique pour le trajet au-delà de la marche
        #ifdef HEIGHT_FOG
        if (distVol > marchEnd + 1.0 && isEyeInWater == 0) {
            float rem = distVol - marchEnd;
            float y0 = cameraPosition.y + worldDir.y * marchEnd;
            float fall = 0.025 / HEIGHT_FOG_FALLOFF;
            float dy = worldDir.y;
            float fogAmt;
            if (abs(dy) < 0.01) {
                fogAmt = hfDens * exp(-max(y0 - WATER_LEVEL, 0.0) * fall) * rem;
            } else {
                fogAmt = hfDens / fall * exp(-max(y0 - WATER_LEVEL, 0.0) * fall)
                       * (1.0 - exp(-rem * dy * fall)) / dy;
            }
            fogAmt = 1.0 - exp(-max(fogAmt, 0.0));
            vec3 hcol = getSkyBase(worldDir, sunW) * 0.9
                      + getLightColor() * 0.20 * pow(clamp(cosT, 0.0, 1.0), 4.0);
            color = mix(color, hcol, clamp(fogAmt, 0.0, 0.9));
        }
        #endif

        color = color * transF + scat;

        #if defined VL_BLOCKLIGHT && (defined SS_LIGHTS || defined RTGI)
            blockFog /= float(VL_SAMPLES);
            color += blockFog * (1.0 - exp(-marchEnd * 0.04)) * 0.30 * VL_BLOCK_STRENGTH;
        #endif
    }
    #endif

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, 1.0);
}
