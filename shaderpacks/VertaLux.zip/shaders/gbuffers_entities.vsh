#version 120
/* VeraLux — entités (vertex) */

attribute vec4 at_tangent;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec4 tangent;
varying vec3 viewPos;

void main() {
    vec4 pos = gl_ModelViewMatrix * gl_Vertex;
    viewPos = pos.xyz;
    gl_Position = gl_ProjectionMatrix * pos;

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;
    normal   = normalize(gl_NormalMatrix * gl_Normal);
    tangent  = vec4(normalize(gl_NormalMatrix * at_tangent.xyz), at_tangent.w);
}
