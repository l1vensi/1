#version 120
/* VeraLux — finition image : bloom, auto-exposition, Purkinje, tonemap ACES,
   saturation, grain argentique, ondulation sous-marine.
   ACES filmic : courbe S calibrée sur la référence cinématique Academy.
   Purkinje lié à l'exposition scénique : s'active progressivement dans l'obscurité.
   Écrit l'image LDR avec sa luminance en alpha (pour le FXAA de la passe finale). */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjection;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform float rainStrength;
uniform float viewWidth;
uniform float viewHeight;
uniform float frameTimeCounter;
uniform float centerDepthSmooth;
uniform float near;
uniform float far;
uniform int isEyeInWater;
uniform int bossBattle;
uniform ivec2 eyeBrightnessSmooth;

varying vec2 uv;

// ACES approximation de Krzysztof Narkowicz (calibré sur la référence Academy)
// Noirs plus profonds, hautes lumières crémeuses, saturation naturelle aux midtones
vec3 aces(vec3 x) {
    const float a = 2.51;
    const float b = 0.03;
    const float c = 2.43;
    const float d = 0.59;
    const float e = 0.14;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

// Tonemap Uchimura (repli si ACES désactivé)
vec3 uchimura(vec3 x) {
    const float P = 1.0;
    const float a = 1.0;
    const float m = 0.22;
    const float l = 0.4;
    const float c = 1.33;
    float l0 = ((P - m) * l) / a;
    float S0 = m + l0;
    float S1 = m + a * l0;
    float C2 = (a * P) / (P - S1);
    float CP = -C2 / P;
    vec3 w0 = 1.0 - smoothstep(vec3(0.0), vec3(m), x);
    vec3 w2 = step(vec3(S0), x);
    vec3 w1 = 1.0 - w0 - w2;
    vec3 T = m * pow(x / m, vec3(c));
    vec3 S = P - (P - S1) * exp(CP * (x - S0));
    vec3 L = m + a * (x - m);
    return clamp(T * w0 + L * w1 + S * w2, 0.0, 1.0);
}

void main() {
    vec2 suv = uv;

    // Sous l'eau : ondulation triple-fréquence — vagues courtes + longues + micro-turbulence
    if (isEyeInWater == 1) {
        float rt = frameTimeCounter;
        float eyeB = float(eyeBrightnessSmooth.y) / 240.0;
        suv += vec2(
            sin(uv.y * 58.0 + rt * 2.2) * 0.55 + sin(uv.y * 33.0 + rt * 1.6) * 0.30
          + sin(uv.y * 12.0 + rt * 0.8) * 0.15,
            cos(uv.x * 58.0 + rt * 2.0) * 0.55 + cos(uv.x * 36.0 + rt * 1.4) * 0.30
          + cos(uv.x * 11.0 + rt * 0.7) * 0.15
        ) * (0.0010 + 0.0012 * eyeB);
    }
    // Dans la lave : forte ondulation visqueuse
    if (isEyeInWater == 2) {
        suv += vec2(sin(uv.y * 28.0 + frameTimeCounter * 1.4),
                    cos(uv.x * 26.0 + frameTimeCounter * 1.1)) * 0.006;
    }

    float emberMask = 0.0;
    #ifdef HEAT_SHIMMER
    {
        float heat = 0.0;
        for (int i = 1; i <= 3; i++) {
            vec2 q = suv + vec2(0.0, -0.022 * float(i));
            if (q.y > 0.0) {
                float fl = texture2D(colortex2, q).b;
                if (fl > 0.55 && fl < 0.62) heat += 1.0 / float(i);
            }
        }
        if (heat > 0.0) {
            heat = min(heat, 1.5);
            suv.x += sin(uv.y * 110.0 + frameTimeCounter * 6.0) * 0.0009 * heat;
            suv.y += cos(uv.x * 95.0 + frameTimeCounter * 5.0) * 0.0006 * heat;
            emberMask = heat;
        }
    }
    #endif

    float dropHi = 0.0;
    #ifdef CAMERA_DROPLETS
    {
        float exposed = float(eyeBrightnessSmooth.y) / 240.0;
        float dAmt = rainStrength * smoothstep(0.40, 0.85, exposed);
        if (dAmt > 0.01 && isEyeInWater == 0) {
            float aspect = viewWidth / viewHeight;

            // Petites gouttes : grille 12×8, position bornée → jamais à cheval sur un bord
            {
                vec2 gpS = uv * vec2(aspect, 1.0) * 12.0;
                vec2 cellS = floor(gpS);
                vec2 frS = fract(gpS);
                float hS = hash12(cellS);
                if (hS > 0.63) {
                    float phS = fract(frameTimeCounter * (0.05 + hS * 0.08) + hS * 17.0);
                    // [0.14, 0.86] × [0.14, 0.86] : rayon 0.08 reste entièrement dans la cellule
                    vec2 dposS = vec2(0.14 + 0.72 * hash12(cellS + 5.7),
                                      0.14 + 0.72 * (1.0 - phS));
                    vec2 ddS = frS - dposS;
                    float rS = length(vec2(ddS.x, ddS.y * 1.15));
                    float dropS = smoothstep(0.075, 0.012, rS) * dAmt;
                    suv += ddS * dropS * 0.25;
                    dropHi = max(dropHi, dropS * 0.48);
                }
            }

            // Grosses gouttes avec traînée : grille 4×3
            // La tête reste dans [0.14,0.86]×[0.16,0.76] → avec rayon 0.12, aucun débord.
            // La traînée s'atténue aux bords de cellule → pas de coupure visible.
            {
                vec2 gpL = uv * vec2(aspect, 1.0) * 4.0;
                vec2 cellL = floor(gpL);
                vec2 frL = fract(gpL);
                float hL = hash12(cellL);
                if (hL > 0.50) {
                    float speed = 0.10 + hL * 0.14;
                    float phL = fract(frameTimeCounter * speed + hL * 23.0);
                    float xL = 0.14 + 0.72 * hash12(cellL + 7.3);
                    vec2 headPos = vec2(xL, 0.16 + 0.60 * (1.0 - phL));
                    vec2 ddH = frL - headPos;
                    float rH = length(vec2(ddH.x * 1.1, ddH.y));
                    float headDrop = smoothstep(0.11, 0.016, rH);

                    float streakLen = 0.05 + hL * 0.10;
                    float trailY = frL.y - headPos.y - 0.025;
                    float trailX = abs(frL.x - xL);
                    // fade aux quatre bords de la cellule → jamais de coupure nette
                    float edgeFade = smoothstep(0.0, 0.05, frL.x) * smoothstep(1.0, 0.95, frL.x)
                                   * smoothstep(0.0, 0.05, frL.y) * smoothstep(1.0, 0.95, frL.y);
                    float trail = smoothstep(0.011, 0.002, trailX)
                                * smoothstep(streakLen, 0.0, trailY)
                                * step(0.0, trailY)
                                * smoothstep(0.0, 0.18, 1.0 - phL)
                                * edgeFade * dAmt;

                    suv += ddH * headDrop * dAmt * 0.38;
                    suv.y -= trail * 0.012;
                    dropHi = max(dropHi, headDrop * dAmt + trail * 0.28);
                }
            }
        }
    }
    #endif

    vec3 color;

    #ifdef DOF
    {
        float dHere = texture2D(depthtex0, suv).r;
        float ld = 2.0 * near * far / (far + near - (dHere * 2.0 - 1.0) * (far - near));
        float lc = 2.0 * near * far / (far + near - (centerDepthSmooth * 2.0 - 1.0) * (far - near));
        float coc = clamp(abs(ld - lc) / max(lc, 2.0), 0.0, 1.0) * 7.0 * DOF_STRENGTH;
        if (coc > 0.8) {
            vec2 pxd = coc / vec2(viewWidth, viewHeight);
            vec3 acc = vec3(0.0);
            for (int i = 0; i < 8; i++) {
                float aa = float(i) * 2.39996;
                float rr = sqrt((float(i) + 0.5) / 8.0);
                acc += texture2D(colortex0, suv + vec2(cos(aa), sin(aa)) * rr * pxd).rgb;
            }
            color = acc * 0.125;
        } else {
            color = texture2D(colortex0, suv).rgb;
        }
    }
    #else
        color = texture2D(colortex0, suv).rgb;
    #endif

    #ifdef CHROMATIC_ABERRATION
    {
        vec2 rc = uv - 0.5;
        vec2 ca = rc * dot(rc, rc) * 0.010;
        color.r = texture2D(colortex0, suv + ca).r;
        color.b = texture2D(colortex0, suv - ca).b;
    }
    #endif

    #ifdef BLOOM
        color += texture2D(colortex3, suv).rgb * 0.26 * BLOOM_STRENGTH;
    #endif

    float exposure = EXPOSURE;
    #ifdef AUTO_EXPOSURE
        float eyeB = float(max(eyeBrightnessSmooth.x, eyeBrightnessSmooth.y)) / 240.0;
        // Courbe exponentielle : les yeux s'adaptent plus vite dans le noir
        // qu'ils ne se resserrent dans la lumière (réponse pupillaire réelle)
        float adaptK = mix(3.2, 1.0, smoothstep(0.03, 0.65, eyeB));
        exposure *= adaptK;
    #endif
    color *= exposure;

    #ifdef LAVA_OVERLAY
    if (isEyeInWater == 2) {
        vec3 lavaView = vec3(2.2, 0.55, 0.06);
        float vig = 1.0 - dot(uv - 0.5, uv - 0.5) * 1.2;
        color = mix(color * vec3(1.6, 0.5, 0.2), lavaView, 0.72)
              * (0.7 + 0.5 * vig) * (0.85 + 0.15 * sin(frameTimeCounter * 5.0));
    }
    #endif

    #ifdef HEAT_SHIMMER
    if (emberMask > 0.0) {
        for (int e = 0; e < 3; e++) {
            float fe = float(e);
            vec2 gp = uv * vec2(viewWidth / viewHeight, 1.0) * (18.0 + fe * 7.0);
            vec2 cell = floor(gp);
            float h = hash12(cell + fe * 5.3);
            if (h > 0.6) {
                vec2 fr = fract(gp) - vec2(0.5 + 0.4 * sin(frameTimeCounter * 1.5 + h * 30.0),
                                           fract(0.5 - frameTimeCounter * (0.15 + h * 0.2) + h));
                float d = length(fr * vec2(2.0, 1.0));
                float gl = exp(-d * d * 40.0);
                color += vec3(2.5, 0.9, 0.25) * gl * emberMask * (0.5 + 0.5 * h);
            }
        }
    }
    #endif

    // ---- Balance des blancs ----
    color *= vec3(1.0 + WB_TEMPERATURE, 1.0 + WB_TINT * 0.5, 1.0 - WB_TEMPERATURE);

    // ---- Tonemap ----
    #ifdef ACES_TONEMAP
        color = aces(color * 0.6);   // ×0.6 : ACES est plus contrasté, ajuste le pivot
    #else
        color = uchimura(color);
    #endif
    color = toSrgb(color);

    // Courbe de contraste filmique (légère S)
    color = mix(color, color * color * (3.0 - 2.0 * color), 0.18 * TONEMAP_CONTRAST);

    // Vibrance
    float l = luma(color);
    float satC = clamp(length(color - vec3(l)) * 2.2, 0.0, 1.0);
    color = mix(vec3(l), color, SATURATION + (1.0 - satC) * 0.10 * VIBRANCE);

    // ---- Effet Purkinje amélioré ----
    // Lié à l'exposition de la scène (eyeBrightness) : s'active progressivement
    // quand l'environnement s'assombrit — comme la pupille humaine qui se dilate
    #ifdef PURKINJE
    {
        float eyeS = float(eyeBrightnessSmooth.y) / 240.0;
        float sceneD = clamp(1.0 - eyeS * 2.0, 0.0, 1.0);   // 0 = plein jour, 1 = noir absolu
        float localD = clamp(1.0 - luma(color) * 6.0, 0.0, 1.0);
        float pk = sceneD * localD;
        if (pk > 0.01) {
            vec3 nightSight = vec3(0.42, 0.62, 1.12) * luma(color) * 1.10;
            color = mix(color, nightSight, pk * 0.60);
        }
    }
    #endif

    // Rayons crépusculaires (screen-space, depuis le centre du soleil)
    // Désactivé sous l'eau : le VL génère déjà les vrais god rays directionnels,
    // et cet effet screen-space pointerait vers le soleil en haut de l'écran
    // → créerait des "rayons verticaux" quand le soleil est au zénith.
    #ifdef GODRAYS
    if (isEyeInWater == 0) {
        float sunHg = dot(normalize(sunPosition), normalize(upPosition));
        vec4 clipG = gbufferProjection * vec4(sunPosition, 1.0);
        if (sunHg > -0.05 && clipG.w > 0.0) {
            vec2 suvG = (clipG.xy / clipG.w) * 0.5 + 0.5;
            if (suvG.x > -0.4 && suvG.x < 1.4 && suvG.y > -0.4 && suvG.y < 1.4) {
                vec2 stepG = (suvG - uv) / 12.0;
                vec2 q = uv;
                float decay = 1.0;
                float acc = 0.0;
                for (int i = 0; i < 12; i++) {
                    q += stepG;
                    if (q.x < 0.0 || q.x > 1.0 || q.y < 0.0 || q.y > 1.0) break;
                    acc += smoothstep(1.3, 4.5, luma(texture2D(colortex0, q).rgb)) * decay;
                    decay *= 0.86;
                }
                color += vec3(1.0, 0.88, 0.70) * acc * 0.045 * GODRAY_STRENGTH
                       * smoothstep(-0.05, 0.1, sunHg) * (1.0 - rainStrength * 0.7);
            }
        }
    }
    #endif

    #ifdef LENS_FLARE
    {
        float sunH = dot(normalize(sunPosition), normalize(upPosition));
        vec4 clipS = gbufferProjection * vec4(sunPosition, 1.0);
        if (sunH > 0.0 && clipS.w > 0.0) {
            vec2 suvS = (clipS.xy / clipS.w) * 0.5 + 0.5;
            if (suvS.x > -0.2 && suvS.x < 1.2 && suvS.y > -0.2 && suvS.y < 1.2) {
                float occ = 0.0;
                for (int i = 0; i < 5; i++) {
                    vec2 o = vec2(cos(float(i) * 1.2566), sin(float(i) * 1.2566)) * 0.012;
                    vec2 q = clamp(suvS + o, vec2(0.001), vec2(0.999));
                    occ += step(1.0, texture2D(depthtex0, q).r);
                }
                float vis = occ * 0.2 * smoothstep(0.0, 0.15, sunH) * (1.0 - rainStrength);
                if (vis > 0.001) {
                    float aspect = viewWidth / viewHeight;
                    vec2 toC = vec2(0.5) - suvS;
                    vec2 dS = (uv - suvS) * vec2(aspect, 1.0);
                    vec3 fl = vec3(1.0, 0.85, 0.60) * exp(-dot(dS, dS) * 60.0) * 0.30;
                    for (int g = 1; g <= 4; g++) {
                        vec2 gpos = suvS + toC * (float(g) * 0.5);
                        vec2 dg = (uv - gpos) * vec2(aspect, 1.0);
                        float sz = 200.0 + float(g) * 250.0;
                        vec3 gc = (g == 1) ? vec3(0.90, 0.55, 0.30)
                                : (g == 2) ? vec3(0.35, 0.70, 0.50)
                                : (g == 3) ? vec3(0.40, 0.45, 0.90)
                                           : vec3(0.70, 0.40, 0.70);
                        fl += gc * exp(-dot(dg, dg) * sz) * 0.10;
                    }
                    color += fl * vis * LENS_FLARE_STRENGTH;
                }
            }
        }
    }
    #endif

    #ifdef CAMERA_DROPLETS
        // Micro-reflet dans les gouttes : teinte eau-gris, pas blanc pur, très discret
        color += vec3(0.55, 0.65, 0.75) * dropHi * dropHi * 0.09;
    #endif

    // Effet combat de boss : vignette pulsée violette
    #ifdef BOSS_FX
    if (bossBattle > 0) {
        float bpulse = 0.5 + 0.5 * sin(frameTimeCounter * 2.8);
        float bvig = dot(uv - 0.5, uv - 0.5) * 3.5;
        color = mix(color, color * vec3(0.55, 0.25, 0.80), bvig * 0.25 * bpulse);
    }
    #endif

    #ifdef FILM_GRAIN
        float grain = hash12(gl_FragCoord.xy + fract(frameTimeCounter) * 113.0) - 0.5;
        color += grain * 0.012;
    #endif

    float vig = dot(uv - 0.5, uv - 0.5);
    color *= 1.0 - vig * VIGNETTE * 2.2;

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, luma(color));
}
