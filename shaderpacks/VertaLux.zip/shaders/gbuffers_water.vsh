#version 120
/* VeraLux — translucides : eau, verre (vertex).
   La surface de l'eau est déplacée verticalement par les vagues. */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/water.glsl"

attribute vec4 mc_Entity;

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 viewPos;
varying vec3 worldPos;
varying float mat;

void main() {
    mat = mc_Entity.x;

    vec4 pos = gl_ModelViewMatrix * gl_Vertex;
    vec4 wp = gbufferModelViewInverse * pos;
    vec3 absW = wp.xyz + cameraPosition;

    #ifdef WATER_WAVES
    #ifdef WATER_DISPLACEMENT
        // Seule la nappe supérieure du bloc d'eau ondule (pas le fond du bloc)
        if (mat > 7.5 && mat < 8.5 && fract(absW.y - 0.01) > 0.7) {
            float h = waveHeight(absW.xz, frameTimeCounter);
            wp.y += clamp((h - 0.45) * 0.25 * WAVE_STRENGTH, -0.18, 0.11);
            pos = gbufferModelView * wp;
        }
    #endif
    #endif

    viewPos = pos.xyz;
    worldPos = wp.xyz + cameraPosition;
    gl_Position = gl_ProjectionMatrix * pos;

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;
    normal   = normalize(gl_NormalMatrix * gl_Normal);
}
