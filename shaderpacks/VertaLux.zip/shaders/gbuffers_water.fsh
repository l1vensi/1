#version 120
/* VeraLux — translucides : eau quasi transparente avec vagues, verre avec
   micro-relief (vitres légèrement irrégulières, comme du vrai verre).
   La couleur finale (absorption, caustiques, reflets, réfraction) est
   construite dans composite1 ; ici on pose teinte, normale et flag matériau.
   Flags (colortex2.b) : 0 = autre, 0.5 = émissif, 0.7 = verre, 1.0 = eau. */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/distort.glsl"
#include "/lib/lighting.glsl"
#include "/lib/water.glsl"

uniform sampler2D gtexture;
uniform mat4 gbufferModelView;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 viewPos;
varying vec3 worldPos;
varying float mat;

void main() {
    bool isWater = (mat > 7.5 && mat < 8.5);
    bool isGlass = (mat > 29.5 && mat < 30.5);

    vec3 albedo;
    float alpha;
    if (isWater) {
        // Quasi transparente : le fond reste visible, composite1 fait le reste
        albedo = toLinear(glcolor.rgb) * 0.18;
        alpha = 0.25;
    } else {
        vec4 col = texture2D(gtexture, texcoord) * glcolor;
        if (isGlass && col.a < 0.05) {
            // Vitre claire : on garde une surface quasi invisible pour
            // qu'elle puisse accrocher reflets et lumière (resource packs ok)
            albedo = vec3(0.03);
            alpha = 0.15;
        } else {
            if (col.a < 0.05) discard;
            albedo = toLinear(col.rgb);
            alpha = col.a;
        }
    }

    vec3 normalV = normalize(normal);
    float fallFoam = 0.0;
    #ifdef WATER_WAVES
        vec3 wn = mat3(gbufferModelViewInverse) * normalV;
        if (isWater && wn.y > 0.5) {
            float dist = length(viewPos);
            // Eaux troubles (marais) = calmes et huileuses ; océans = houle pleine
            float murkW = 1.0 - luma(glcolor.rgb);
            float chopFade = 1.0 / (1.0 + dist * 0.04);
            chopFade *= mix(1.0, 0.45, murkW);
            vec3 wnorm = waveNormalWorld(worldPos.xz, frameTimeCounter,
                                         WAVE_STRENGTH * mix(1.0, 0.6, murkW), chopFade);

            #ifdef WATER_RIPPLES
                // Rides du joueur : anneaux concentriques quand on marche/nage
                vec2 toP = worldPos.xz - cameraPosition.xz;
                float pdR = length(toP);
                float feetY = cameraPosition.y - 1.62;
                if (pdR > 0.05 && pdR < 6.0 && abs(worldPos.y - feetY) < 2.0) {
                    float ring = sin(pdR * 9.0 - frameTimeCounter * 7.0) * exp(-pdR * 0.7);
                    wnorm.xz += (toP / pdR) * ring * 0.30;
                }
                // Rides de pluie : impacts de gouttes, anneaux qui s'étendent
                if (rainStrength > 0.01) {
                    vec2 cell = floor(worldPos.xz);
                    vec2 fr = fract(worldPos.xz) - 0.5;
                    vec2 hit = vec2(hash12(cell + 13.1), hash12(cell + 31.7)) - 0.5;
                    vec2 dxz = fr - hit * 0.6;
                    float rr = length(dxz);
                    float ph = fract(frameTimeCounter * 1.1 + hash12(cell) * 7.0);
                    float ring = cos((rr - ph * 0.45) * 34.0)
                               * exp(-pow((rr - ph * 0.45) * 9.0, 2.0)) * (1.0 - ph);
                    wnorm.xz += (dxz / max(rr, 0.03)) * ring * 0.45 * rainStrength;
                }
                wnorm = normalize(wnorm);
            #endif

            normalV = normalize(mat3(gbufferModelView) * wnorm);
        } else if (isWater && wn.y < -0.5) {
            // Face inférieure (vue de dessous) : vagues mirrorées
            // → se ride comme le dessus mais normale pointant vers le bas
            float dist2 = length(viewPos);
            float murkW2 = 1.0 - luma(glcolor.rgb);
            float cf2 = 1.0 / (1.0 + dist2 * 0.06) * mix(1.0, 0.40, murkW2);
            vec3 wnorm2 = waveNormalWorld(worldPos.xz, frameTimeCounter,
                                          WAVE_STRENGTH * 0.55 * mix(1.0, 0.50, murkW2), cf2);
            // Normale opposée : même vague, face vue de dessous
            normalV = normalize(mat3(gbufferModelView) * vec3(-wnorm2.x, -wnorm2.y, -wnorm2.z));
        } else if (isWater) {
            // Eau verticale (cascades) : stries qui dévalent + écume
            vec3 tdir = normalize(vec3(wn.z, 0.0, -wn.x) + vec3(1e-4));
            float u = dot(worldPos.xz, tdir.xz);
            float streak = vnoise(vec2(u * 3.0, worldPos.y * 1.2 - frameTimeCounter * 3.5))
                         + vnoise(vec2(u * 6.5, worldPos.y * 2.6 - frameTimeCounter * 5.5)) * 0.5;
            vec3 nW2 = normalize(wn + vec3(0.0, 1.0, 0.0) * (streak - 0.75) * 0.55
                               + tdir * (vnoise(vec2(u * 4.2, worldPos.y * 2.0 - frameTimeCounter * 4.5)) - 0.5) * 0.30);
            normalV = normalize(mat3(gbufferModelView) * nW2);
            fallFoam = smoothstep(0.95, 1.25, streak);
            alpha = max(alpha, 0.45 + fallFoam * 0.3);
        }
    #endif
    #ifdef GLASS_EFFECTS
        if (isGlass && GLASS_DISTORTION > 0.01) {
            // Micro-relief du verre : reflets et réfraction subtilement irréguliers
            vec2 gn = vec2(vnoise(worldPos.yz * 2.3 + worldPos.x),
                           vnoise(worldPos.xy * 2.3 + worldPos.z)) - 0.5;
            normalV = normalize(normalV + vec3(gn * 0.06 * GLASS_DISTORTION, 0.0));
        }
    #endif

    float dither = bayer8(gl_FragCoord.xy);
    vec3 color = shadeSurface(albedo, normalV, lmcoord, viewPos, dither, 0.0);

    // Écume blanche des cascades, éclairée localement
    if (fallFoam > 0.0) {
        color += (getAmbientColor() + getLightColor() * 0.4)
               * fallFoam * 0.45 * (lmcoord.y * lmcoord.y * 0.92 + 0.08);
    }

    if (isWater) {
        // L'eau doit être belle PAR ELLE-MÊME (visible derrière le verre,
        // où la passe composite ne peut pas l'habiller) : reflet du ciel
        // en Fresnel + opacité qui monte en angle rasant
        float ndv = clamp(dot(normalV, -normalize(viewPos)), 0.0, 1.0);
        float fresG = 0.02 + 0.98 * pow(1.0 - ndv, 5.0);
        float skyl2 = lmcoord.y * lmcoord.y;
        #ifdef WATER_SKY_REFLECT
        color += (getAmbientColor() * 0.65 + getLightColor() * 0.03) * fresG * skyl2;
        #endif
        alpha = mix(0.50, 0.85, fresG);
    }

    float flag = isWater ? 1.0 : (isGlass ? 0.7 : 0.0);

/* DRAWBUFFERS:0125 */
    gl_FragData[0] = vec4(color, alpha);
    gl_FragData[1] = vec4(normalV * 0.5 + 0.5, 1.0);
    gl_FragData[2] = vec4(lmcoord, flag, 1.0);
    // Teinte d'eau du biome (alpha 0 pour le verre : ne pas écraser l'albedo)
    gl_FragData[3] = vec4(glcolor.rgb, isWater ? 1.0 : 0.0);
}
