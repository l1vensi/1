/*
    VeraLux — distorsion de la shadow map.
    Concentre la résolution de la shadow map près du joueur :
    les ombres proches sont nettes, les lointaines restent correctes.
*/

const float SHADOW_DISTORTION = 0.85;

float getDistortFactor(vec2 v) {
    float d = pow(abs(v.x * v.x * v.x) + abs(v.y * v.y * v.y), 1.0 / 3.0);
    return d * SHADOW_DISTORTION + (1.0 - SHADOW_DISTORTION);
}

vec3 distortShadow(vec3 pos, float factor) {
    return vec3(pos.xy / factor, pos.z * 0.5);
}
