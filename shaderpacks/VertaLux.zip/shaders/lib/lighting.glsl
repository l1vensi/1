/*
    VeraLux — moteur d'éclairage.
    Ombres PCSS (pénombre variable), ombres colorées (vitraux), ombres des
    nuages qui défilent sur le terrain, ambiance ciel, lumière minimale de
    grotte bleutée, lumière tenue en main.
    Tout est calculé en espace linéaire (HDR).
*/

uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform mat4 gbufferModelViewInverse;
uniform vec3 shadowLightPosition;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform vec3 cameraPosition;
uniform float rainStrength;
uniform float wetness;
uniform int moonPhase;
uniform int worldTime;
uniform float frameTimeCounter;
uniform int heldBlockLightValue;
uniform vec3 fogColor;

float sunHeight() {
    return dot(normalize(sunPosition), normalize(upPosition));
}

// Hauteur de la lumière ACTIVE (soleil le jour, lune la nuit — Iris bascule
// shadowLightPosition automatiquement). Sert aux rayons et caustiques.
float lightHeight() {
    return dot(normalize(shadowLightPosition), normalize(upPosition));
}

// Couleur de la lumière directe (soleil le jour, lune la nuit)
vec3 getLightColor() {
    float sh = sunHeight();
    float dayF  = smoothstep(-0.03, 0.2, sh);
    float duskF = clamp(1.0 - abs(sh) * 5.0, 0.0, 1.0);

    vec3 day   = vec3(1.0, 0.97 / SUN_TINT_TEMP, 0.90 / (SUN_TINT_TEMP * SUN_TINT_TEMP)) * 4.6 * SUN_INTENSITY;
    vec3 dusk  = vec3(1.0, 0.45, 0.15) * 2.2 * SUN_INTENSITY;
    vec3 night = vec3(0.12, 0.18, 0.35) * 0.24 * MOON_INTENSITY;

    vec3 c = mix(night, day, dayF);
    c = mix(c, dusk, duskF);
    return c * (1.0 - 0.85 * rainStrength);
}

// Couleur de la lumière ambiante venant du ciel
vec3 getAmbientColor() {
    float sh = sunHeight();
    float dayF  = smoothstep(-0.05, 0.2, sh);
    float duskF = clamp(1.0 - abs(sh) * 4.0, 0.0, 1.0);

    vec3 day   = vec3(0.55, 0.72, 1.00) * 0.72;
    vec3 dusk  = vec3(0.75, 0.55, 0.45) * 0.42;
    vec3 night = vec3(0.08, 0.12, 0.22) * 0.38;

    vec3 c = mix(night, day, dayF);
    c = mix(c, dusk, duskF * 0.7);
    return c * (1.0 - 0.45 * rainStrength) * AMBIENT_INTENSITY;
}

vec3 getTorchColor() {
    return vec3(1.0, 0.52, 0.18);
}

/*
    Ombre 2D des nuages sur le sol : proxy bon marché du champ de nuages
    volumétriques (mêmes coordonnées, mêmes octaves de tête), pour que les
    ombres défilent sous les nuages.
*/
#ifdef VOLUMETRIC_CLOUDS
#ifdef VC_GROUND_SHADOWS
float cloudShadow(vec3 wp, vec3 lightDirW) {
    if (lightDirW.y < 0.05) return 1.0;
    vec2 cp = wp.xz + lightDirW.xz / lightDirW.y * (VC_BASE + VC_THICK * 0.35 - wp.y);
    vec2 wind = frameTimeCounter * vec2(7.0, 2.4) * VC_WIND;
    float cov = clamp(VC_COVERAGE + rainStrength * 0.30, 0.0, 1.0);
    float covL = cov * smoothstep(0.20, 0.70, vnoise((cp + wind * 0.6) * 0.0010)) * 1.5;
    float base = fbm3((cp + wind) * 0.0060);
    float d = clamp((base - (1.0 - covL) * 0.52 - 0.08) * 3.5, 0.0, 1.0);
    return 1.0 - d * 0.75;
}
#endif
#endif

// Position d'un point (espace vue) dans l'espace clip de la shadow map,
// avec un décalage le long de la normale pour éviter le shadow acne.
vec3 toShadowClip(vec3 viewPos, vec3 viewNormal) {
    vec4 wpos = gbufferModelViewInverse * vec4(viewPos, 1.0);
    vec3 wnorm = mat3(gbufferModelViewInverse) * viewNormal;
    wpos.xyz += wnorm * (0.03 + length(viewPos) * 0.004);
    vec4 spos = shadowProjection * (shadowModelView * wpos);
    return spos.xyz;
}

/*
    Ombres PCSS : recherche des bloqueurs pour estimer la taille de la
    pénombre (plus l'objet qui bloque est loin de la surface, plus l'ombre
    est diffuse — comme un vrai soleil), puis PCF en disque de Vogel.
    Renvoie une visibilité RGB (les vitraux teintent la lumière).
*/
vec3 sampleShadowPCF(vec3 shadowClip, float dither) {
    float f = getDistortFactor(shadowClip.xy);
    vec3 sp = distortShadow(shadowClip, f) * 0.5 + 0.5;

    if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0) return vec3(1.0);

    float bias = 0.0004 + 0.0002 * f;
    float z = sp.z - bias;
    float texel = 1.0 / float(shadowMapResolution) / f;

    float radius;
    #ifdef PCSS
        // Recherche de bloqueurs : 5 échantillons
        float searchR = 12.0 * texel;
        float blockerSum = 0.0;
        float blockerCnt = 0.0;
        for (int i = 0; i < 5; i++) {
            float a = float(i) * 2.4 + dither * 6.2831853;
            float r = sqrt((float(i) + 0.5) / 5.0);
            vec2 o = vec2(cos(a), sin(a)) * r * searchR;
            float zb = texture2D(shadowtex1, sp.xy + o).r;
            if (zb < z) { blockerSum += zb; blockerCnt += 1.0; }
        }
        float penumbra = 0.8;
        if (blockerCnt > 0.5) {
            float zb = blockerSum / blockerCnt;
            penumbra += clamp((z - zb) * 60.0 * LIGHT_SIZE * float(shadowMapResolution) * 0.001, 0.0, 10.0);
        }
        radius = penumbra * texel * SHADOW_SOFTNESS * 1.2;
    #else
        radius = SHADOW_SOFTNESS * 2.5 * texel;
    #endif

    vec3 shadow = vec3(0.0);
    for (int i = 0; i < SHADOW_SAMPLES; i++) {
        float a = float(i) * 2.4 + dither * 6.2831853;
        float r = sqrt((float(i) + 0.5) / float(SHADOW_SAMPLES));
        vec2 o = vec2(cos(a), sin(a)) * r * radius;

        float s0 = step(z, texture2D(shadowtex0, sp.xy + o).r); // tout
        float s1 = step(z, texture2D(shadowtex1, sp.xy + o).r); // opaque seulement

        vec3 col = vec3(1.0);
        if (s0 < s1) col = texture2D(shadowcolor0, sp.xy + o).rgb;
        // accentue la teinte des ombres colorées (eau bleue, vitraux)
        col = mix(vec3(luma(col)), col, 1.4);
        shadow += s1 * mix(col, vec3(1.0), s0);
    }
    return shadow / float(SHADOW_SAMPLES);
}

vec3 getShadow(vec3 viewPos, vec3 viewNormal, float dither) {
    return sampleShadowPCF(toShadowClip(viewPos, viewNormal), dither);
}

/*
    Éclairage complet d'une surface.
    subsurface > 0 : diffusion sous-surface approximée (feuillage).
*/
vec3 shadeSurface(vec3 albedo, vec3 normal, vec2 lm, vec3 viewPos, float dither, float subsurface) {
    vec3 L = normalize(shadowLightPosition);
    float NdotL = clamp(dot(normal, L), 0.0, 1.0);
    float diff = mix(NdotL, 0.6 + 0.4 * NdotL, subsurface);

    vec3 shadow = vec3(0.0);
    if (diff > 0.001) {
        shadow = getShadow(viewPos, normal, dither);
        // Au-delà de la shadow map : on estime par la lightmap du ciel
        float sfade = smoothstep(0.85, 1.0, length(viewPos) / shadowDistance);
        shadow = mix(shadow, vec3(lm.y * lm.y), sfade);
    }
    vec3 direct = getLightColor() * diff * shadow;

    // Contre-jour du feuillage : la lumière transmise à travers les feuilles
    if (subsurface > 0.0) {
        float backlit = pow(clamp(dot(normalize(viewPos), L), 0.0, 1.0), 6.0);
        direct += getLightColor() * shadow * backlit * subsurface * 0.85 * SUBSURFACE_STRENGTH;
    }

    // Les nuages qui passent devant le soleil assombrissent le sol
    #ifdef VOLUMETRIC_CLOUDS
    #ifdef VC_GROUND_SHADOWS
        vec3 wp = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;
        vec3 lightDirW = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
        direct *= cloudShadow(wp, lightDirW);
    #endif
    #endif

    float skyl = lm.y * lm.y;
    // Ambiance ciel : strictement proportionnelle à l'exposition — 0 en grotte
    vec3 ambient = getAmbientColor() * skyl;
    #ifdef RTGI
        ambient *= mix(1.0, RTGI_BOUNCE_AMBIENT, skyl);
    #endif
    // Ambiance dimensionnelle : Nether/End gardent leur atmosphère, les grottes
    // overworld reçoivent très peu (fogColor y est quasi-noir).
    // Multiplié par 0.35 au lieu de 1.4 : assombrit grottes, Nether reste chaud.
    ambient += toLinear(fogColor) * 0.35 * (1.0 - skyl) + getTorchColor() * 0.006 * (1.0 - skyl);

    float torch = lm.x * lm.x * lm.x * 2.0 + lm.x * 0.08;
    #ifdef VANILLA_BLOCKLIGHT
        torch *= VANILLA_TORCH;
    #else
        torch = 0.0;   // lumière de bloc vanilla totalement coupée (GI/émissif only)
    #endif
    float held = float(heldBlockLightValue) / 15.0;
    torch += held * held * 2.5 * HELD_LIGHT_STRENGTH / (1.0 + dot(viewPos, viewPos) * 0.05);

    // Plancher minimal : 0.5 % en grotte profonde → torche obligatoire
    vec3 caveFloor = vec3(0.8, 0.95, 1.3) * MIN_LIGHT * max(skyl * skyl, 0.005);

    return albedo * (direct + ambient + getTorchColor() * torch + caveFloor);
}
