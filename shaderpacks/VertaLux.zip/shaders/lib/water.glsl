/*
    VeraLux — océanographie procédurale v4, méthode "Seascape".
    Chaque octave : domaine DÉFORMÉ par du bruit (fronts de vagues courbes
    et irréguliers — aucun motif en losange possible), profil choppy
    1-|sin| mixé (crêtes vives, creux amples), DEUX champs contre-propagatifs
    (la mer respire au lieu de défiler), et rotation du domaine entre les
    octaves (aucune direction privilégiée).
    Requiert lib/common.glsl inclus avant.
*/

// Une octave de mer : vagues choppy au domaine déformé
float seaOctave(vec2 uv, float choppy) {
    uv += vnoise(uv) * 2.0 - 1.0;
    vec2 wv = 1.0 - abs(sin(uv));
    vec2 swv = abs(cos(uv));
    wv = mix(wv, swv, wv);
    return pow(1.0 - pow(wv.x * wv.y, 0.65), choppy);
}

// Hauteur de mer, niveau de détail variable (oct = 3 loin … 5 près)
float waveHeightLOD(vec2 p, float t, int oct) {
    float freq = 0.14;
    float amp = 0.62;
    float choppy = 4.0;
    vec2 uv = p;
    uv.x *= 0.75;
    float tt = 1.0 + t * 0.8 * WAVE_SPEED;

    float h = 0.0;
    for (int i = 0; i < 5; i++) {
        if (i >= oct) break;
        float d = seaOctave((uv + tt) * freq, choppy)
                + seaOctave((uv - tt * 0.8) * freq, choppy);
        h += d * amp;
        uv = mat2(1.6, 1.2, -1.2, 1.6) * uv;
        freq *= 1.9;
        amp *= 0.22;
        choppy = mix(choppy, 1.0, 0.2);
    }
    return h;
}

float waveHeight(vec2 p, float t) {
    return waveHeightLOD(p, t, 5);
}

// Normale monde par différences finies, détail dégressif avec la distance
vec3 waveNormalWorld(vec2 p, float t, float strength, float chopFade) {
    int oct = (chopFade > 0.5) ? 5 : ((chopFade > 0.15) ? 4 : 3);
    float e = 0.12;
    float h0 = waveHeightLOD(p, t, oct);
    float hx = waveHeightLOD(p + vec2(e, 0.0), t, oct);
    float hz = waveHeightLOD(p + vec2(0.0, e), t, oct);
    return normalize(vec3((h0 - hx) / e * strength * 1.2, 1.0,
                          (h0 - hz) / e * strength * 1.2));
}

// Arêtes de Voronoï animées (points de cellule qui dansent)
float voroEdge(vec2 p, float t) {
    vec2 ip = floor(p);
    vec2 fp = fract(p);
    float f1 = 8.0;
    float f2 = 8.0;
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            vec2 g = vec2(float(x), float(y));
            vec2 o = vec2(hash12(ip + g), hash12(ip + g + 19.7));
            o = 0.5 + 0.42 * sin(t * 0.7 + o * 6.2831853);
            float d = length(g + o - fp);
            if (d < f1) { f2 = f1; f1 = d; }
            else if (d < f2) { f2 = d; }
        }
    }
    return f2 - f1;
}

/*
    Caustiques : VRAIE toile lumineuse (réseau de Voronoï) — les arêtes entre
    cellules forment le filet connecté des photos de fonds marins.
    Deux nappes en contre-dérive, intersections plus brillantes.
*/
float waveCaustic(vec2 p, float t) {
    p *= CAUSTIC_SCALE;
    t *= CAUSTIC_SPEED;
    // Fréquences 3× plus élevées → cellules de ~0.4 bloc (réaliste)
    // Seuil réduit → lignes fines et nettes comme les vraies photos de fonds marins
    float w1 = 1.0 - smoothstep(0.0, 0.07, voroEdge(p * 1.80 + vec2(t * 0.060, t * 0.045), t));
    float w2 = 1.0 - smoothstep(0.0, 0.09, voroEdge(p * 2.75 - vec2(t * 0.050, t * 0.030), t * 1.3));
    return (w1 * 0.65 + w1 * w2 * 1.15) * 1.3;
}
