/*
    VeraLux — nuages multi-couches, façon "mer de nuages alpine" :
    couche basse (~140 blocs), cellules petites et serrées en moutonnement,
    dômes bourgeonnants, fort contraste lumineux. Bancs et éclaircies par
    champ de couverture basse fréquence. + altocumulus et cirrus au-dessus.
    Requiert common.glsl et lighting.glsl inclus avant.
*/

// Bancs de nuages ↔ éclaircies
float cloudPatch(vec2 xz, float t) {
    vec2 wind = t * vec2(7.0, 2.4) * VC_WIND;
    return vnoise((xz + wind * 0.6) * 0.0010);
}

// Rayon de courbure (blocs) : assez grand pour rester subtil mais visible
// à l'horizon — les nuages au loin descendent et se courbent.
float cloudDensity(vec3 wp, float t) {
    // Courbure : un point loin du joueur "tombe" de d²/(2R) → la nappe
    // épouse la rondeur de la planète au lieu d'un plafond plat infini
    float yEff = wp.y;
    #ifdef CLOUD_CURVATURE
        vec2 dxz = wp.xz - cameraPosition.xz;
        // Depuis au-dessus de la couche le terme additif dépasse les bornes → écrêtage.
        // On atténue progressivement la courbure dès la moitié haute de la nappe.
        float curvFade = 1.0 - clamp((cameraPosition.y - VC_BASE - VC_THICK * 0.5) / (VC_THICK * 0.5), 0.0, 1.0);
        yEff += dot(dxz, dxz) / (2.0 * PLANET_RADIUS) * curvFade;
    #endif
    float h = (yEff - VC_BASE) / VC_THICK;
    if (h < 0.0 || h > 1.0) return 0.0;

    float cov = clamp(VC_COVERAGE + rainStrength * 0.30, 0.0, 1.0);
    // Le seuil bas de cloudPatch s'abaisse avec la couverture : à VC_COVERAGE=1.0
    // pratiquement toutes les cellules contribuent → ciel bouché complet possible.
    float covLo = max(0.20 - (cov - 0.45) * 0.44, 0.0);
    float covL = cov * smoothstep(covLo, 0.70, cloudPatch(wp.xz, t)) * 1.5;
    if (covL < max(0.03 * (1.0 - cov * 0.9), 0.003)) return 0.0;

    vec2 wind = t * vec2(7.0, 2.4) * VC_WIND;
    vec2 pp = wp.xz + wind;
    // Cellules petites et serrées (moutonnement)
    float base = fbm(pp * 0.0060);

    // Les cellules les plus denses montent en dôme
    float colH = clamp(base * 1.7 - 0.50, 0.18, 1.0);
    // Sommet légèrement plus marqué (0.55 au lieu de 0.45) : meilleur rendu depuis le dessus
    float profile = smoothstep(0.0, 0.07, h) * smoothstep(colH, colH * 0.55, h);

    float d = base * profile - (1.0 - covL) * 0.52;
    if (d <= 0.0) return 0.0;

    // Érosion 3D billowy : bords en chou-fleur
    vec3 dp = vec3(pp.x, wp.y * 2.4, pp.y);
    float ero = vnoise3(dp * 0.030) * 0.65 + vnoise3(dp * 0.085) * 0.35;
    ero = 1.0 - abs(ero * 2.0 - 1.0);
    d -= (1.0 - ero) * 0.13 * (1.0 - clamp(d * 5.0, 0.0, 1.0));

    return clamp(d * 6.0, 0.0, 1.0) * VC_DENSITY;
}

// Marche secondaire vers la lumière : auto-ombrage du nuage (loi de Beer)
float cloudLightMarch(vec3 wp, vec3 lightDir, float t) {
    float acc = 0.0;
    float st = VC_THICK / 4.0;
    vec3 p = wp;
    for (int j = 0; j < 4; j++) {
        p += lightDir * st;
        acc += cloudDensity(p, t);
    }
    return exp(-acc * st * 0.032 * min(VC_OPACITY * 0.75, 4.0));
}

float hgPhase(float c, float g) {
    return (1.0 - g * g) / (12.566 * pow(1.0 + g * g - 2.0 * g * c, 1.5));
}

/*
    Raymarch principal des cumulus. Renvoie (couleur, alpha).
    maxDist : les nuages passent DEVANT le terrain lointain et se survolent.
*/
vec4 volumetricClouds(vec3 camPos, vec3 dir, vec3 lightDirW, vec3 fogCol, float dither, float t, float maxDist) {
    float top = VC_BASE + VC_THICK;
    float t0;
    float t1;
    if (abs(dir.y) < 1e-3) {
        if (camPos.y < VC_BASE || camPos.y > top) return vec4(0.0);
        t0 = 0.0;
        // Distance réduite en vue horizontale depuis l'intérieur :
        // 24 samples sur 900 blocs = pas de 37 blocs → bien meilleure densité
        // qu'un pas de 83 blocs sur 2000 blocs (nuages qui "disparaissent")
        t1 = 900.0;
    } else {
        float ta = (VC_BASE - camPos.y) / dir.y;
        float tb = (top - camPos.y) / dir.y;
        t0 = max(min(ta, tb), 0.0);
        t1 = max(ta, tb);
        if (t1 <= 0.0) return vec4(0.0);
        // Vue rasante vers l'horizon : la courbure ramène des nuages très
        // loin dans le champ — on prolonge la marche
        if (dir.y < 0.18) t1 = max(t1, VC_RENDER_DISTANCE);
    }
    t1 = min(min(t1, t0 + VC_RENDER_DISTANCE), maxDist);
    if (t1 <= t0 + 0.01) return vec4(0.0);

    float dt = (t1 - t0) / float(VC_SAMPLES);
    // Depuis au-dessus le motif Bayer 8×8 crée des points violets : le décalage
    // de ±dt blocs entre pixels adjacents fait alterner hit/miss sur les détails
    // fins du nuage. On centre le jitter à 0.5 (mi-pas fixe) pour supprimer le bruit.
    float jitter = (camPos.y > top) ? 0.5 : dither;
    float tt = t0 + dt * jitter;

    float cosT = dot(dir, lightDirW);
    float phase = hgPhase(cosT, 0.60) * 1.0 + hgPhase(cosT, -0.20) * 0.30 + 0.035;

    float duskC = clamp(1.0 - abs(sunHeight()) * 4.0, 0.0, 1.0);
    vec3 sunC = getLightColor() * 2.2 * CLOUD_BRIGHTNESS;
    vec3 ambT = getAmbientColor() * 0.90 + getLightColor() * 0.08;
    // Golden hour : le ventre des nuages s'embrase, lumière rasante
    vec3 ambB = getAmbientColor() * 0.35 + getLightColor() * duskC * 0.55;

    vec3 acc = vec3(0.0);
    float trans = 1.0;

    for (int i = 0; i < VC_SAMPLES; i++) {
        vec3 wp = camPos + dir * tt;
        float d = cloudDensity(wp, t);
        if (d > 0.002) {
            float lt = cloudLightMarch(wp, lightDirW, t);
            float h = clamp((wp.y - VC_BASE) / VC_THICK, 0.0, 1.0);
            float powder = 1.0 - exp(-d * 3.5);
            // Depuis au-dessus : les sommets reçoivent plus de lumière zénithale
            float zenith = (camPos.y > top) ? h * h * 0.45 : 0.0;
            vec3 S = sunC * lt * phase * (0.6 + powder * 0.7) + mix(ambB, ambT * (1.0 + zenith), h) * 0.50;

            float a = exp(-d * 0.05 * dt * VC_OPACITY);
            acc += trans * S * (1.0 - a);
            trans *= a;
            if (trans < 0.01) break;
        }
        tt += dt;
    }

    float alpha = 1.0 - trans;
    if (alpha < 1e-4) return vec4(0.0);

    // Fondu des nuages lointains dans la brume de l'horizon
    // Coefficient réduit : nuages plus visibles à distance (horizon + 5km)
    float fogT = 1.0 - exp(-t0 * 0.00038);
    vec3 col = acc / alpha;
    col = mix(col, fogCol, fogT);
    // Alpha fade réduit : nuages plus opaques à l'horizon
    alpha *= 1.0 - fogT * 0.50;

    return vec4(col, alpha);
}

/*
    Couches hautes (2D, ancrées dans le monde) : altocumulus + cirrus.
    Composées DERRIÈRE les cumulus volumétriques.
*/
vec4 highClouds(vec3 camPos, vec3 dir, vec3 sunDir, float t) {
    vec3 col = vec3(0.0);
    float alpha = 0.0;
    float horizF = smoothstep(0.015, 0.10, abs(dir.y));

    // --- Cirrus, ~520 blocs : filaments étirés par le vent ---
    #ifdef CLOUD_LAYER_CIRRUS
    {
        float tc = (CLOUD_CIRRUS_HEIGHT - camPos.y) / dir.y;
        if (tc > 0.0) {
            vec2 p = camPos.xz + dir.xz * tc + t * vec2(18.0, 6.0) * VC_WIND;
            float n = fbm(vec2(p.x * 0.0011, p.y * 0.0040));
            float cm = pow(smoothstep(0.45, 0.85, n), 1.5) * 0.38;
            cm *= horizF * (1.0 - rainStrength * 0.6);
            vec3 cc = getLightColor() * 0.40 + getAmbientColor() * 0.90;
            col = cc;
            alpha = cm;
        }
    }
    #endif

    // --- Altocumulus, ~320 blocs : moutonnement régulier ---
    #ifdef CLOUD_LAYER_ALTO
    {
        float ta = (CLOUD_ALTO_HEIGHT - camPos.y) / dir.y;
        if (ta > 0.0) {
            vec2 p = camPos.xz + dir.xz * ta + t * vec2(11.0, 4.0) * VC_WIND;
            float n = vnoise(p * 0.0050) * 0.55 + vnoise(p * 0.016) * 0.30 + vnoise(p * 0.045) * 0.15;
            vec2 so = normalize(sunDir.xz + vec2(1e-4)) * 22.0;
            float n2 = vnoise((p + so) * 0.0050) * 0.55 + vnoise((p + so) * 0.016) * 0.30;
            float shade = clamp((n - n2) * 5.0 + 0.5, 0.0, 1.0);

            float am = smoothstep(0.56, 0.72, n) * 0.5;
            am *= horizF * (1.0 - rainStrength * 0.4);
            vec3 bright = getLightColor() * 0.35 + getAmbientColor() * 0.85;
            vec3 dark   = getAmbientColor() * 0.55;
            vec3 ac = mix(bright, dark, shade * 0.6);

            col = mix(col, ac, am);
            alpha = alpha + am * (1.0 - alpha);
        }
    }
    #endif

    return vec4(col, clamp(alpha, 0.0, 1.0));
}
