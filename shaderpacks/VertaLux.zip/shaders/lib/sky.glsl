/*
    VeraLux — ciel.
    getSkyPhysical : atmosphère simulée (Rayleigh+Mie) avec altitude réelle —
    monte assez haut et le ciel devient noir, les étoiles sortent, l'horizon
    n'est plus qu'un liseré bleu. Couchers de soleil rouges automatiques.
    getSkyBase : dégradé analytique bon marché (brouillard, reflets).
    getSkyAll : version reflets/verre avec nuages 2D.
    Requiert common.glsl, lighting.glsl (et atmosphere.glsl si PHYSICAL_SKY).
*/

// Dégradé atmosphérique analytique (brouillard, reflets — bon marché)
vec3 getSkyBase(vec3 dir, vec3 sunDir) {
    float sh = sunDir.y;
    float dayF  = smoothstep(-0.05, 0.25, sh);
    float duskF = clamp(1.0 - abs(sh) * 4.0, 0.0, 1.0);
    float horiz = pow(1.0 - clamp(dir.y, 0.0, 1.0), 3.0);

    vec3 dayZen = vec3(0.13, 0.40, 0.92);
    vec3 dayHor = vec3(0.62, 0.80, 0.98);
    vec3 ngtZen = vec3(0.004, 0.007, 0.018);
    vec3 ngtHor = vec3(0.012, 0.018, 0.040);

    vec3 sky = mix(mix(ngtZen, dayZen, dayF), mix(ngtHor, dayHor, dayF), horiz);

    float sunAmt = pow(clamp(dot(dir, sunDir) * 0.5 + 0.5, 0.0, 1.0), 3.0);
    sky = mix(sky, vec3(1.0, 0.40, 0.12), clamp(duskF * sunAmt * horiz * 1.2, 0.0, 1.0));

    float glow = pow(clamp(dot(dir, sunDir), 0.0, 1.0), 8.0);
    sky += vec3(1.0, 0.80, 0.50) * glow * 0.22 * dayF;
    sky += vec3(1.0, 0.45, 0.15) * glow * 0.60 * duskF;

    sky = mix(sky, vec3(luma(sky)) * vec3(0.8, 0.85, 0.95), rainStrength * 0.85);

    return sky * 1.22;
}

// Nuages 2D procéduraux (reflets, verre, mode léger)
vec4 getClouds(vec3 dir, vec3 sunDir) {
    if (dir.y < 0.02) return vec4(0.0);

    vec2 p = dir.xz / dir.y * 2.4;
    p += frameTimeCounter * vec2(0.012, 0.004);

    float n = fbm(p * 0.7);
    float cov = smoothstep(0.50 - 0.25 * rainStrength, 0.80, n);
    if (cov <= 0.0) return vec4(0.0);

    vec2 sunOff = normalize(sunDir.xz + vec2(1e-4)) * 0.25;
    float n2 = fbm((p + sunOff) * 0.7);
    float shade = clamp((n - n2) * 4.0 + 0.5, 0.0, 1.0);

    vec3 bright = getLightColor() * 0.42 + getAmbientColor() * 0.75;
    vec3 dark   = getAmbientColor() * 0.55;
    vec3 col = mix(bright, dark, clamp(shade * 0.7 + cov * 0.3, 0.0, 1.0));

    float a = cov * smoothstep(0.02, 0.12, dir.y) * 0.9;
    return vec4(col, a);
}

// Disque céleste carré (style vanilla) ou rond (réaliste), selon SQUARE_SUN
float celestialDisc(vec3 dir, vec3 bodyDir, float size) {
    float dd = dot(dir, bodyDir);
    if (dd < 0.5) return 0.0;
    #ifdef SQUARE_SUN
        vec3 axis = (abs(bodyDir.y) > 0.95) ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
        vec3 right = normalize(cross(bodyDir, axis));
        vec3 up2 = cross(right, bodyDir);
        vec2 ang = vec2(dot(dir, right), dot(dir, up2)) / dd;
        float sq = max(abs(ang.x), abs(ang.y));
        return 1.0 - smoothstep(size * 0.92, size, sq);
    #else
        // Réfraction atmosphérique : près de l'horizon le disque grossit
        // et s'aplatit verticalement, comme les couchers de soleil réels
        vec3 axisR = (abs(bodyDir.y) > 0.95) ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
        vec3 rightR = normalize(cross(bodyDir, axisR));
        vec3 upR = cross(rightR, bodyDir);
        float horizS = 1.0 - clamp(abs(bodyDir.y) * 4.0, 0.0, 1.0);
        vec2 angR = vec2(dot(dir, rightR), dot(dir, upR)) / max(dd, 0.5);
        angR.y *= 1.0 + horizS * 0.50;
        float sizeR = size * (1.0 + horizS * 0.30);
        return 1.0 - smoothstep(sizeR * 0.90, sizeR, length(angR));
    #endif
}

#ifdef AURORA
/*
    Aurores boréales : rideaux verticaux fins qui ondulent et serpentent.
    Construction : on projette le ciel sur un plan ; des "plis" verticaux
    (le bord du rideau) sont définis par une ligne sinueuse animée. Plusieurs
    couches superposées à des phases différentes donnent l'épaisseur et le
    fourmillement caractéristiques. Dégradé vert (bas) → cyan → magenta (haut).
*/
vec3 aurora(vec3 dir, float t, float nightF) {
    if (dir.y < 0.04 || nightF <= 0.0) return vec3(0.0);
    // Disparaît en vue "espace" (caméra > 350 blocs) : depuis l'orbite,
    // l'aurore serait invisible sous l'atmosphère, pas tout autour de soi
    float highFade = 1.0 - clamp((cameraPosition.y - 350.0) / 300.0, 0.0, 1.0);
    if (highFade <= 0.0) return vec3(0.0);
    // Activité variable : certaines nuits flamboient, d'autres rien
    float act = smoothstep(0.30, 0.70, vnoise(vec2(t * 0.0035, 3.7)));
    if (act <= 0.001) return vec3(0.0);

    // Projection : x = azimut, la hauteur module l'intensité
    vec2 p = dir.xz / (dir.y + 0.25);
    float hgrad = clamp((dir.y - 0.05) * 1.6, 0.0, 1.0);

    vec3 acc = vec3(0.0);
    // 5 rideaux superposés, chacun sa sinuosité et sa couleur
    for (int i = 0; i < 5; i++) {
        float fi = float(i);
        // Ligne serpentine du rideau (somme de sinus animés)
        float wob = sin(p.x * 1.3 + t * 0.25 + fi * 1.7) * 0.55
                  + sin(p.x * 3.1 - t * 0.40 + fi * 4.2) * 0.22
                  + sin(p.x * 6.7 + t * 0.15 + fi) * 0.10;
        float curtainX = p.x * 0.5 + wob + fi * 0.6;
        // Distance au pli → bord lumineux fin
        float edge = exp(-pow(fract(curtainX) - 0.5, 2.0) * 60.0);
        // Stries verticales qui scintillent le long du rideau
        float ray = 0.55 + 0.45 * sin(p.x * 24.0 + t * 0.8 + fi * 10.0
                                      + sin(p.x * 5.0 - t) * 3.0);
        // Couleur selon la hauteur : vert profond → cyan → magenta
        vec3 cc = mix(vec3(0.10, 1.00, 0.42),
                      mix(vec3(0.15, 0.85, 0.95), vec3(0.85, 0.25, 0.95), hgrad),
                      smoothstep(0.0, 0.7, hgrad));
        acc += cc * edge * ray * (0.5 + 0.5 * hash12(vec2(fi, floor(curtainX))));
    }
    // Atténuation : faible à l'horizon, max à mi-hauteur, fond vers le zénith
    float vfade = smoothstep(0.04, 0.22, dir.y) * smoothstep(1.0, 0.45, dir.y);
    return acc * 0.085 * act * nightF * vfade * AURORA_BRIGHTNESS * highFade;
}
#endif

// Étoile ponctuelle dans une cellule 3D : point net + halo doux
vec3 starInCell(vec3 cube, float scale, float thresh) {
    vec3 g = cube * scale;
    vec3 cell = floor(g);
    float s = hash13(cell);
    if (s < thresh) return vec3(0.0);
    // Position sub-cellule aléatoire de l'étoile
    vec3 off = vec3(hash13(cell + 1.3), hash13(cell + 2.7), hash13(cell + 4.1));
    float d = length(fract(g) - off);
    float h2 = hash13(cell + 17.3);
    float mag = (s - thresh) / (1.0 - thresh);          // brillance ∝ rareté
    float core = exp(-d * d * 900.0) + exp(-d * d * 120.0) * 0.35; // point + halo
    float tw = 0.55 + 0.45 * sin(frameTimeCounter * (1.5 + h2 * 4.0) + h2 * 50.0);
    vec3 tint = mix(vec3(0.60, 0.74, 1.35), vec3(1.35, 0.92, 0.58), h2 * h2);
    return tint * core * tw * (0.25 + mag * mag * 2.2);
}

// Ciel profond : étoiles multi-échelles, Voie lactée riche, étoiles filantes
vec3 skyStars(vec3 dir, float visibility) {
    if (visibility <= 0.0) return vec3(0.0);

    // Rotation de la voûte autour de l'axe nord
    float rotA = float(worldTime) * 0.000262;
    mat3 spin = mat3(cos(rotA), 0.0, sin(rotA), 0.0, 1.0, 0.0, -sin(rotA), 0.0, cos(rotA));
    vec3 sd = spin * dir;

    // --- Champ d'étoiles : 3 densités (grosses rares, moyennes, fines) ---
    vec3 col = (starInCell(sd, 26.0, 0.94)
             + starInCell(sd, 55.0, 0.96) * 0.7
             + starInCell(sd, 110.0, 0.975) * 0.4) * STAR_BRIGHTNESS;

    // --- Voie lactée : axe galactique, plan projeté ---
    vec3 mwN = normalize(vec3(0.36, 0.28, 0.89));
    float dN = dot(sd, mwN);
    float band = exp(-dN * dN * 5.5);                // bande gaussienne large
    vec3 mwU = normalize(cross(mwN, vec3(0.0, 1.0, 0.0)));
    vec3 mwV = cross(mwN, mwU);
    vec2 mwp = vec2(dot(sd, mwU), dot(sd, mwV));

    // Structure nuageuse multi-octave (le long de la bande)
    vec2 q = vec2(mwp.x * 1.2, mwp.y * 5.0);
    float neb = fbm(q * 1.5 + 7.0) * 0.6 + fbm(q * 4.0 - 3.0) * 0.3 + fbm(q * 9.0) * 0.1;
    // Bandes de poussière sombres qui zèbrent la bande
    float dust = smoothstep(0.40, 0.72, fbm(q * 2.2 + vec2(0.0, 4.0)));
    // Bulbe galactique : renflement chaud près du centre
    float core = exp(-dot(mwp, mwp) * 1.4);
    float mw = band * smoothstep(0.25, 0.85, neb) * (1.0 - dust * 0.7);
    // Teinte : bleu-violet des bras → crème dorée du cœur
    vec3 mwCol = mix(vec3(0.42, 0.50, 0.95), vec3(1.10, 0.90, 0.68), core);
    col += (mwCol * mw * 0.5 + mwCol * core * band * 0.35) * MILKYWAY_BRIGHTNESS;
    // Myriade d'étoiles plus dense DANS la bande galactique
    col += starInCell(sd, 150.0, 0.965) * band * 1.6 * STAR_BRIGHTNESS;

    #ifdef SHOOTING_STARS
        // Étoile filante : tête brillante + traînée qui s'efface derrière
        vec2 sp = sd.xz / (abs(sd.y) + 0.4);
        float sB = floor(frameTimeCounter * 0.14);
        if (hash12(vec2(sB, 11.3)) > 0.55) {
            float ph = fract(frameTimeCounter * 0.14);
            vec2 a0 = vec2(hash12(vec2(sB, 5.1)), hash12(vec2(sB, 9.7))) * 2.4 - 1.2;
            vec2 dirM = normalize(vec2(hash12(vec2(sB, 3.3)) - 0.5,
                                       hash12(vec2(sB, 7.7)) - 0.5) + vec2(1e-3));
            vec2 head = a0 + dirM * (ph - 0.3) * 1.6;
            vec2 rel = sp - head;
            float along = dot(rel, -dirM);             // >0 derrière la tête
            float perp = dot(rel, vec2(-dirM.y, dirM.x));
            float fade = sin(clamp(ph, 0.0, 1.0) * 3.14159);
            // Traînée effilée
            float trail = exp(-perp * perp * 900.0) * exp(-max(along, 0.0) * 9.0)
                        * step(0.0, along) * step(along, 0.4);
            // Tête : point vif et son halo
            float headG = exp(-dot(rel, rel) * 1400.0) + exp(-dot(rel, rel) * 200.0) * 0.4;
            col += vec3(0.95, 0.97, 1.15) * (trail * 1.2 + headG * 2.5) * fade;
        }
    #endif

    return col * visibility * smoothstep(-0.06, 0.12, sd.y);
}

/*
    Lune réaliste : disque sphérique avec mers lunaires procédurales,
    assombrissement du limbe, et VRAIES PHASES (le terminateur suit
    moonPhase : pleine lune, quartiers, croissants, nouvelle lune).
    En mode SQUARE_SUN, reste carrée façon vanilla.
*/
vec3 moonSurface(vec3 dir, vec3 moonDir, float size) {
    float dd = dot(dir, moonDir);
    // Halo doux autour de la lune
    vec3 glow = vec3(0.55, 0.65, 0.90) * pow(clamp(dd, 0.0, 1.0), 900.0) * 0.75;
    #ifdef MOON_HALO
        // Halo de 22° : anneau de glace les nuits humides
        float ring = exp(-pow((dd - 0.927) * 55.0, 2.0));
        glow += vec3(0.55, 0.62, 0.85) * ring * 0.05
              * (0.25 + 0.75 * clamp(wetness + rainStrength * 0.5, 0.0, 1.0));
    #endif
    if (dd < 0.5) return vec3(0.0);

    #ifdef SQUARE_SUN
        return glow + vec3(0.75, 0.82, 1.0) * celestialDisc(dir, moonDir, size) * 1.4;
    #else
        vec3 axis = (abs(moonDir.y) > 0.95) ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
        vec3 right = normalize(cross(moonDir, axis));
        vec3 up2 = cross(right, moonDir);
        vec2 ang = vec2(dot(dir, right), dot(dir, up2)) / dd / size;
        float r2 = dot(ang, ang);
        float disc = 1.0 - smoothstep(0.80, 1.0, r2);
        if (disc <= 0.0) return glow;

        // Le disque est une sphère : normale locale + direction du soleil
        // tournant avec la phase → terminateur correct
        vec3 n = vec3(ang, sqrt(max(1.0 - r2, 0.0)));
        float pa = float(moonPhase) * 0.7853982;
        vec3 Lm = vec3(sin(pa), 0.0, cos(pa));
        float lit = smoothstep(-0.05, 0.20, dot(n, Lm));

        // Mers lunaires (taches sombres) + limbe assombri
        float maria = vnoise(ang * 3.5 + 7.3) * 0.45 + vnoise(ang * 8.0 + 2.1) * 0.25;
        vec3 surf = vec3(0.85, 0.88, 0.97) * (0.85 - maria * 0.45);
        surf *= 0.75 + 0.25 * n.z;

        return glow + surf * lit * disc * 2.4;
    #endif
}

// Atmosphère analytique + étoiles + soleil/lune (SANS nuages) — repli léger
vec3 getSkyCelestial(vec3 dir, vec3 sunDir) {
    vec3 sky = getSkyBase(dir, sunDir);
    float dayF = smoothstep(-0.05, 0.25, sunDir.y);

    sky += skyStars(dir, (1.0 - dayF) * (1.0 - rainStrength) * 0.85);

    float sunDisc = celestialDisc(dir, sunDir, SUN_SIZE);
    sky += vec3(1.0, 0.93, 0.82) * sunDisc * 25.0 * dayF * (1.0 - rainStrength * 0.9);

    sky += moonSurface(dir, -sunDir, SUN_SIZE * 0.8)
         * (1.0 - dayF * 0.8) * (1.0 - rainStrength * 0.9);

    #ifdef AURORA
        sky += aurora(dir, frameTimeCounter, (1.0 - dayF) * (1.0 - rainStrength));
    #endif

    return sky;
}

#ifdef PHYSICAL_SKY
// Ciel physique complet : Rayleigh+Mie, altitude réelle, étoiles, disques
vec3 getSkyPhysical(vec3 dir, vec3 sunDir) {
    float camH = atmCameraHeight(cameraPosition.y);

    vec3 trans;
    vec3 sky = atmScatter(dir, sunDir, camH, trans) * ATMO_INTENSITY;

    // Clair de lune : seconde passe, faible et froide, au crépuscule/la nuit
    float sh = sunDir.y;
    if (sh < 0.15) {
        vec3 mtrans;
        sky += atmScatter(dir, -sunDir, camH, mtrans)
             * vec3(0.55, 0.75, 1.0) * 0.035 * ATMO_INTENSITY;
    }

    // Étoiles : visibles quand l'air laisse passer (nuit… ou altitude)
    float skyGlow = luma(sky);
    float starVis = luma(trans) * clamp(1.0 - skyGlow * 6.0, 0.0, 1.0) * (1.0 - rainStrength);
    sky += skyStars(dir, starVis * 1.1);

    // Soleil : atténué par l'air traversé → rouge au couchant, net en altitude
    float sunDisc = celestialDisc(dir, sunDir, SUN_SIZE);
    sky += vec3(1.0, 0.98, 0.94) * sunDisc * 40.0 * trans;

    sky += moonSurface(dir, -sunDir, SUN_SIZE * 0.8) * trans * 1.6;

    #ifdef AURORA
        float nightFA = (1.0 - smoothstep(-0.10, 0.10, sh)) * (1.0 - rainStrength);
        sky += aurora(dir, frameTimeCounter, nightFA);
    #endif

    // Pluie : ciel gris
    sky = mix(sky, vec3(luma(sky)) * vec3(0.8, 0.85, 0.95), rainStrength * 0.85);

    return sky;
}
#endif

// Ciel complet avec nuages 2D (utilisé pour les reflets et le verre)
vec3 getSkyAll(vec3 dir, vec3 sunDir) {
    vec3 sky = getSkyCelestial(dir, sunDir);

    #ifdef CLOUDS_2D
        vec4 cl = getClouds(dir, sunDir);
        sky = mix(sky, cl.rgb, cl.a);
    #endif

    return sky;
}
