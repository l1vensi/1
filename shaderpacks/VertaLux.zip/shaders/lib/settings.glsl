/*
    VeraLux 3.0 "Realis" — réglages globaux
    Options rangées par catégories dans l'écran "Shader Options".
*/

// ============ OMBRES ============
// Contact Shadows (SSCS) : micro-ombres portées entre blocs adjacents.
// Améliore le réalisme des coins et arêtes — désactivé par défaut (coût GPU).
//#define CONTACT_SHADOWS

const int   shadowMapResolution     = 4096;  // [1024 2048 4096 8192]
const float shadowDistance          = 128.0; // [96.0 128.0 192.0 256.0]
const float shadowDistanceRenderMul = 1.0;
const float sunPathRotation         = -35.0; // [-50.0 -40.0 -35.0 -25.0 0.0]

#define SHADOW_SOFTNESS 1.0 // [0.25 0.5 1.0 1.5 2.0 3.0]
#define SHADOW_SAMPLES 12 // [8 12 16 24]
#define PCSS
#define LIGHT_SIZE 1.0 // [0.5 0.75 1.0 1.5 2.0]

// ============ OCCLUSION AMBIANTE (SSAO) ============
#define AO
#define AO_STRENGTH 1.0 // [0.5 0.75 1.0 1.25 1.5]
#define AO_RADIUS 0.75 // [0.5 0.75 1.0 1.5]
#define AO_SAMPLES 8 // [4 8 12 16]

// ============ GLOBAL ILLUMINATION TEMPS RÉEL (SSGI) ============
//#define RTGI
#define RTGI_STRENGTH 1.5 // [0.0 0.5 0.75 1.0 1.25 1.5 2.0 3.0 4.0]
#define RTGI_RADIUS 8.0 // [4.0 6.0 8.0 12.0 16.0]
#define RTGI_ACCUM 0.92 // [0.80 0.85 0.90 0.92 0.95 0.97]
#define RTGI_BOUNCE_AMBIENT 0.35 // [0.0 0.2 0.3 0.35 0.45 0.6 0.8 1.0]
//#define RSM_GI
#define RSM_STRENGTH 1.0 // [0.0 0.5 0.75 1.0 1.5 2.0 3.0 4.0]
#define RSM_RADIUS 10.0 // [6.0 8.0 10.0 14.0 20.0]
#define RSM_SAMPLES 12 // [8 12 16 24 32]

// ============ VRAIES LUMIÈRES (sources émissives — mode hérité) ============
//#define SS_LIGHTS
#define SS_LIGHT_STRENGTH 1.0 // [0.5 0.75 1.0 1.5 2.0 3.0]
#define SS_LIGHT_RADIUS 16.0 // [8.0 12.0 16.0 24.0]
#define GI_SAMPLES 8 // [4 8 12 16]
#define EMISSIVE_BOOST 8.0 // [2.0 4.0 6.0 8.0 10.0 12.0 16.0 24.0 32.0]
#define LAVA_GLOW 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0]
#define LAVA_ANIMATE
#define EMISSIVE_FLICKER
#define VANILLA_BLOCKLIGHT
#define VANILLA_TORCH 1.0 // [0.0 0.1 0.25 0.5 0.75 1.0 1.25 1.5]
#define HELD_LIGHT_STRENGTH 1.0 // [0.0 0.5 1.0 1.5 2.0]

#define SUN_INTENSITY 1.0 // [0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define MOON_INTENSITY 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define AMBIENT_INTENSITY 1.0 // [0.25 0.5 0.75 1.0 1.25 1.5 2.0]
#define SUN_TINT_TEMP 1.0 // [0.6 0.8 0.9 1.0 1.1 1.25 1.5]

// ============ LUMIÈRE VOLUMÉTRIQUE ============
// VL_RAIN : précipitation visible dans les rayons de lumière (filaments de pluie)
#define VL_RAIN
#define VOLUMETRIC_LIGHT
#define VL_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define VL_SAMPLES 20 // [12 20 32]
#define VL_BLOCKLIGHT
#define VL_BLOCK_STRENGTH 1.0 // [0.25 0.5 1.0 1.5 2.0]

// ============ BROUILLARD DE HAUTEUR (style cinématique) ============
#define HEIGHT_FOG
#define HEIGHT_FOG_DENSITY 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define HEIGHT_FOG_FALLOFF 1.0 // [0.5 0.75 1.0 1.5 2.0 3.0]

// ============ EAU ============
#define WATER_WAVES
#define WAVE_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define WAVE_SPEED 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define WATER_DISPLACEMENT
#define SSR_ENABLED
#define WATER_REFRACTION
#define REFRACTION_STRENGTH 1.0 // [0.25 0.5 0.75 1.0 1.5]
#define WATER_CAUSTICS
#define CAUSTIC_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define CAUSTIC_SCALE 1.0 // [0.5 0.75 1.0 1.5 2.0]
#define CAUSTIC_SPEED 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define WATER_FOAM
#define WHITECAPS
//#define WATER_RIPPLES
#define WATER_REFLECTIVITY 1.0 // [0.0 0.25 0.5 0.65 0.8 1.0 1.25 1.5]
#define WATER_SUN_GLINT 1.0 // [0.0 0.5 0.75 1.0 1.5 2.0 3.0]
//#define WATER_SPARKLE
#define WATER_SPARKLE_AMOUNT 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0]
#define WATER_SKY_REFLECT
#define WATER_NORMAL_STRENGTH 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define FOAM_AMOUNT 1.0 // [0.0 0.5 0.75 1.0 1.5]
#define WATER_CLARITY 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0 4.0 6.0]
#define WATER_FOG_DENSITY 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define UNDERWATER_FX
//#define UW_VIGNETTE
#define UW_PARTICLES
#define WATER_LEVEL 63.0 // [8.0 16.0 24.0 32.0 48.0 63.0 96.0 128.0]
#define UW_RAY_DISTANCE 20.0 // [6.0 8.0 12.0 16.0 24.0]

// ============ VERRE ============
#define GLASS_EFFECTS
#define GLASS_REFRACTION 1.0 // [0.5 1.0 1.5 2.0]
#define GLASS_DISTORTION 1.0 // [0.0 0.5 1.0 2.0]

// ============ PLANÈTE ============
#define PLANET_RADIUS 9000.0 // [3000.0 5000.0 9000.0 15000.0 30000.0 1000000.0]
//#define CLOUD_CURVATURE

// ============ NUAGES ============
#define VOLUMETRIC_CLOUDS
#define VC_SAMPLES 24 // [16 24 32 48]
// VC_COVERAGE : fraction du ciel couverte. 0.70 = ciel bien nuageux.
// 1.00 = couverture totale (overcast). 0.20 = quelques nuages épars.
#define VC_COVERAGE 0.70 // [0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 0.95 1.00]
// VC_OPACITY : opacité du matériau nuageux. 1.0 = semi-transparent (léger).
// 3.0 = nuages bien solides. 8.0 = complètement opaques (orageux).
#define VC_OPACITY 2.0 // [0.5 1.0 1.5 2.0 3.0 5.0 8.0 12.0]
// VC_RENDER_DISTANCE : distance d'affichage des nuages en blocs.
#define VC_RENDER_DISTANCE 5000.0 // [1000.0 2000.0 3000.0 5000.0 8000.0 12000.0 20000.0]
#define VC_BASE 140.0 // [120.0 140.0 160.0 192.0 256.0]
#define VC_THICK 90.0 // [60.0 90.0 120.0 160.0]
#define VC_DENSITY 1.0 // [0.3 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define VC_WIND 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 4.0 6.0]
#define VC_GROUND_SHADOWS
#define CLOUD_BRIGHTNESS 1.0 // [0.5 0.75 1.0 1.25 1.5 2.0]
#define CLOUD_ALTO_HEIGHT 280.0 // [220.0 280.0 340.0 420.0]
#define CLOUD_CIRRUS_HEIGHT 460.0 // [380.0 460.0 560.0 700.0]
//#define CLOUD_LAYER_ALTO
//#define CLOUD_LAYER_CIRRUS
//#define CLOUDS_2D

// ============ MÉTÉO ============
#define RAIN_WET
//#define WET_SHORELINE

// ============ BIOMES & GROTTES ============
#define BIOME_ATMOSPHERE
#define BIOME_ATMO_STRENGTH 1.0 // [0.0 0.5 1.0 1.5 2.0]
//#define CAVE_FOG
#define CAVE_FOG_STRENGTH 1.0 // [0.0 0.5 1.0 1.5 2.0]

// ============ ATMOSPHÈRE ============
//#define PHYSICAL_SKY
#define ATMO_INTENSITY 1.0 // [0.25 0.5 0.75 1.0 1.25 1.5 2.0]
#define RAYLEIGH_STRENGTH 1.0 // [0.5 0.75 1.0 1.25 1.5 2.0]
#define MIE_STRENGTH 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define ATMO_ALTITUDE_BOOST 1.0 // [0.0 0.5 1.0 2.0 4.0]
#define FOG_DENSITY 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 4.0]
//#define SQUARE_SUN
#define SUN_SIZE 0.04 // [0.03 0.04 0.06 0.08 0.10]

// ============ ANTI-ALIASING TEMPOREL ============
// TAA : accumulation frame-à-frame → edges lisses + GI stabilisé
//#define TAA

// ============ POST-PROCESS ============
#define BLOOM
#define BLOOM_STRENGTH 1.2 // [0.0 0.25 0.5 0.75 1.0 1.2 1.5 2.0 3.0]
#define BLOOM_THRESHOLD 1.5 // [0.8 1.0 1.2 1.5 1.8 2.2 3.0]
#define EXPOSURE 0.85 // [0.4 0.6 0.7 0.8 0.85 0.9 1.0 1.1 1.2 1.35 1.5 1.75 2.0]
#define AUTO_EXPOSURE
#define SATURATION 1.05 // [0.7 0.8 0.9 1.0 1.05 1.1 1.15 1.25 1.4 1.6]
#define VIGNETTE 0.15 // [0.0 0.05 0.1 0.15 0.2 0.25 0.35 0.5]
#define TONEMAP_CONTRAST 1.0 // [0.0 0.5 0.75 1.0 1.5 2.0]
#define VIBRANCE 1.0 // [0.0 0.5 0.75 1.0 1.5 2.0]
#define WB_TEMPERATURE 0.0 // [-0.15 -0.10 -0.05 0.0 0.05 0.10 0.15]
#define WB_TINT 0.0 // [-0.10 -0.05 0.0 0.05 0.10]
//#define FXAA
#define PURKINJE
#define FILM_GRAIN

// ============ TEXTURES PBR (labPBR : Patrix, Vanilla PBR…) ============
#define PBR_TEXTURES
#define NORMAL_STRENGTH 1.0 // [0.5 0.75 1.0 1.5 2.0]
#define PBR_EMISSIVE 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define PBR_REFLECTIONS
#define PBR_REFLECT_STRENGTH 1.0 // [0.0 0.5 0.75 1.0 1.5 2.0]
//#define PBR_POM
#define POM_DEPTH 0.15 // [0.05 0.10 0.15 0.25 0.35 0.50]
#define POM_SAMPLES 16 // [8 16 24 32]

// ============ TONEMAP ============
// ACES filmic : noirs profonds, hautes lumières crémeuses, couleurs cinématiques
#define ACES_TONEMAP

// ============ EXTRAS CINÉMATIQUES ============
#define LENS_FLARE
#define LENS_FLARE_STRENGTH 1.0 // [0.5 0.75 1.0 1.5]
//#define AURORA
#define AURORA_BRIGHTNESS 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define STAR_BRIGHTNESS 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define MILKYWAY_BRIGHTNESS 0.0 // [0.0 0.5 0.75 1.0 1.5 2.0 3.0]
//#define SHOOTING_STARS
#define CAMERA_DROPLETS
//#define DOF
#define DOF_STRENGTH 1.0 // [0.5 1.0 1.5 2.0]
#define CHROMATIC_ABERRATION
#define RAINBOW
#define GODRAYS
#define GODRAY_STRENGTH 1.0 // [0.5 1.0 1.5 2.0]
//#define HEAT_SHIMMER
#define LIGHTNING_FX
#define BOSS_FX
#define LAVA_OVERLAY
#define MOON_HALO
//#define SHARPEN
const float centerDepthHalflife = 1.0;

// ============ DEBUG ============
#define DEBUG_VIEW 0 // [0 1 2 3 4 5 6 7 8 9 10 11 12]
//#define DEBUG_SPLIT

// ============ DIVERS ============
#define MIN_LIGHT 0.03 // [0.01 0.03 0.05 0.08 0.12]
#define WAVING_FOLIAGE
#define WAVING_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define WAVING_SPEED 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define WAVING_WATER_PLANTS
#define SUBSURFACE_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
