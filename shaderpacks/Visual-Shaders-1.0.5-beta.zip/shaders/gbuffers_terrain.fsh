#version 120

// VISUAL SHADERS - Terrain Fragment (Refined Ore Glow)
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glColor;
varying vec3 normal;
varying float blockId;

uniform sampler2D texture;
uniform sampler2D specular;
uniform sampler2D normals;

uniform float frameTimeCounter;

varying vec3 tangent;
varying vec3 binormal;

// Quality setting
#ifndef QUALITY
  #define QUALITY 2
#endif

/* DRAWBUFFERS:01235 */

// ═══════════════════════════════════════════════════════════════════════════
// LIGHT SOURCE COLOR SYSTEM
// Maps block IDs to unique light colors (RenderPearl-inspired)
// ═══════════════════════════════════════════════════════════════════════════

vec3 getLightSourceColor(float id) {
    // Torch (10030) - Warm Orange
    if (abs(id - 10030.0) < 0.5) return vec3(1.0, 0.6, 0.3);
    // Soul Torch (10031) - Cyan/Teal
    if (abs(id - 10031.0) < 0.5) return vec3(0.3, 0.8, 0.9);
    // Glowstone (10032) - Warm Yellow
    if (abs(id - 10032.0) < 0.5) return vec3(1.0, 0.85, 0.6);
    // Sea Lantern (10033) - Cool White-Blue
    if (abs(id - 10033.0) < 0.5) return vec3(0.6, 0.85, 1.0);
    // Redstone Lamp (10034) - Warm Red
    if (abs(id - 10034.0) < 0.5) return vec3(1.0, 0.35, 0.2);
    // Glow Berries (10035) - Warm Amber
    if (abs(id - 10035.0) < 0.5) return vec3(1.0, 0.7, 0.3);
    // Lava (10036) - Orange-Red
    if (abs(id - 10036.0) < 0.5) return vec3(1.0, 0.45, 0.15);
    // Campfire (10037) - Orange
    if (abs(id - 10037.0) < 0.5) return vec3(1.0, 0.55, 0.25);
    // Soul Campfire (10038) - Teal
    if (abs(id - 10038.0) < 0.5) return vec3(0.2, 0.7, 0.8);
    // Lantern / Candles (10039) - Warm Yellow
    if (abs(id - 10039.0) < 0.5) return vec3(1.0, 0.75, 0.4);
    // Amethyst (10040) - Purple
    if (abs(id - 10040.0) < 0.5) return vec3(0.7, 0.4, 1.0);
    // Shroomlight (10041) - Warm Orange
    if (abs(id - 10041.0) < 0.5) return vec3(1.0, 0.6, 0.3);
    // Glow Lichen (10042) - Green-Yellow
    if (abs(id - 10042.0) < 0.5) return vec3(0.6, 0.8, 0.3);
    // End Rod (10043) - White-Cream
    if (abs(id - 10043.0) < 0.5) return vec3(1.0, 0.95, 0.8);
    // Beacon (10044) - White
    if (abs(id - 10044.0) < 0.5) return vec3(0.9, 0.95, 1.0);
    // Jack o'Lantern (10045) - Warm Orange
    if (abs(id - 10045.0) < 0.5) return vec3(1.0, 0.6, 0.3);
    // Crying Obsidian (10046) - Purple-Magenta
    if (abs(id - 10046.0) < 0.5) return vec3(0.6, 0.2, 0.9);
    // Respawn Anchor (10047) - Dark Purple
    if (abs(id - 10047.0) < 0.5) return vec3(0.5, 0.15, 0.8);
    // Sculk Catalyst (10048) - Dark Cyan
    if (abs(id - 10048.0) < 0.5) return vec3(0.15, 0.5, 0.6);
    // Froglights (10049) - Warm Peach
    if (abs(id - 10049.0) < 0.5) return vec3(1.0, 0.8, 0.5);
    // Soul Lantern (10050) - Cyan-Teal
    if (abs(id - 10050.0) < 0.5) return vec3(0.25, 0.7, 0.85);
    // Redstone Materials (Torch, Dust, Block) (10051) - Red
    if (abs(id - 10051.0) < 0.5) return vec3(1.0, 0.1, 0.1);
    // Oxidized Copper Lantern/Bulb (10052) - Green
    if (abs(id - 10052.0) < 0.5) return vec3(0.2, 0.8, 0.5);
    // Unoxidized Copper Lantern/Bulb (10053) - Orange
    if (abs(id - 10053.0) < 0.5) return vec3(1.0, 0.6, 0.3);
    
    return vec3(0.0); // Not a light source
}

// Strict emissive light color detection (for texture-based detection)
vec3 getEmissiveLightColor(vec3 texColor, float blockLight) {
    // 1. ORE GLOW COLORS (Refined - Soft & Natural)
    if (blockId > 10000.5 && blockId < 10010.5) {
        // Diamond (10001) - Soft Ice Blue
        if (abs(blockId - 10001.0) < 0.1) return vec3(0.4, 0.8, 0.9);
        // Emerald (10002) - Deep Forest Green
        if (abs(blockId - 10002.0) < 0.1) return vec3(0.2, 0.7, 0.3);
        // Gold (10003) - Warm Amber
        if (abs(blockId - 10003.0) < 0.1) return vec3(1.0, 0.65, 0.2);
        // Iron (10004) - Warm Beige/Peach
        if (abs(blockId - 10004.0) < 0.1) return vec3(0.9, 0.7, 0.5);
        // Copper (10005) - Soft Orange
        if (abs(blockId - 10005.0) < 0.1) return vec3(0.9, 0.5, 0.3);
        // Redstone (10006) - Deep Ruby Red
        if (abs(blockId - 10006.0) < 0.1) return vec3(0.8, 0.15, 0.15);
        // Lapis (10007) - Royal Blue
        if (abs(blockId - 10007.0) < 0.1) return vec3(0.2, 0.4, 0.9);
        // Coal (10008) - Skip
        if (abs(blockId - 10008.0) < 0.1) return vec3(0.0);
        // Quartz (10009) - Soft White
        if (abs(blockId - 10009.0) < 0.1) return vec3(0.9, 0.9, 0.9);
        // Ancient Debris (10010) - Warm Brown
        if (abs(blockId - 10010.0) < 0.1) return vec3(0.8, 0.5, 0.3);
    }

    // 2. TEXTURE-BASED DETECTION (Torches, etc.)
    if (blockLight < 0.95) return vec3(0.0);
    
    float brightness = max(texColor.r, max(texColor.g, texColor.b));
    if (brightness < 0.55) return vec3(0.0);
    
    vec3 normColor = texColor / (brightness + 0.001);
    
    if (normColor.b > 0.45 && normColor.b > normColor.r * 1.4 && normColor.b > normColor.g) return vec3(0.35, 0.7, 1.0);
    if (normColor.r > 0.75 && normColor.g < 0.3 && normColor.b < 0.3) return vec3(1.0, 0.15, 0.1);
    if (brightness > 0.8 && normColor.r > 0.36 && normColor.b > 0.36 && normColor.g > 0.28 && normColor.g < 0.8) return vec3(1.0, 0.88, 0.95);
    if (brightness < 0.45 && normColor.b > normColor.r * 1.6 && normColor.g > normColor.r * 1.3) return vec3(0.15, 0.7, 0.85);
    if (normColor.r > 0.35 && normColor.b > 0.42 && normColor.g < 0.28) return vec3(0.7, 0.45, 1.0);
    
    return vec3(1.0, 0.65, 0.35);
}

// Function to isolate pixels that are "ore" and not "stone"
float getOreEmissiveFactor(vec3 albedo, float blockId) {
    float maxC = max(albedo.r, max(albedo.g, albedo.b));
    float minC = min(albedo.r, min(albedo.g, albedo.b));
    float sat = maxC - minC;
    float lum = dot(albedo, vec3(0.2126, 0.7152, 0.0722));
    
    // Default threshold for separating colorful ore from grey stone
    float satThreshold = 0.2; // Stricter threshold
    
    // Special handling per ore
    
    // Iron (10004) - Weak saturation (beige), needs careful check
    if (abs(blockId - 10004.0) < 0.1) {
        // Stone is ~0.5 lum, Iron is usually lighter/beige
        if (lum > 0.6 && sat > 0.05) return 1.0;
        return 0.0;
    }
    
    // Copper (10005) - Orange/Greenish
    if (abs(blockId - 10005.0) < 0.1) {
        satThreshold = 0.15;
    }
    
    // Redstone (10006) - Red
    if (abs(blockId - 10006.0) < 0.1) {
        satThreshold = 0.3; // Very distinct red
    }
    
    // Lapis (10007) - Blue
    if (abs(blockId - 10007.0) < 0.1) {
        satThreshold = 0.3; // Very distinct blue
    }
    
    // Coal (10008) - Dark spots
    if (abs(blockId - 10008.0) < 0.1) {
        return (lum < 0.15) ? 0.6 : 0.0; // Faint glow for coal spots
    }
    
    // Quartz (10009)
    if (abs(blockId - 10009.0) < 0.1) {
        return (lum > 0.7) ? 0.8 : 0.0;
    }

    // Standard high-saturation gems (Diamond, Emerald, Gold)
    if (sat > satThreshold) {
        // Soften the edge between ore and stone
        return smoothstep(satThreshold, satThreshold + 0.1, sat);
    }
    
    return 0.0;
}

void main() {
    vec4 albedo = texture2D(texture, texcoord) * glColor;
    if (albedo.a < 0.1) discard;
    
    vec3 N = normalize(normal);
    float blockLight = lmcoord.x;
    float skyLight = lmcoord.y;
    
    bool isOre = (blockId > 10000.5 && blockId < 10010.5);
    bool isLightSource = (blockId > 10029.5 && blockId < 10060.5);
    
    float brightness = max(albedo.r, max(albedo.g, albedo.b));
    
    // Mask out dark parts of light sources (like lantern frames)
    if (isLightSource && brightness < 0.45) {
        isLightSource = false;
    }
    
    float oreGlow = 0.0;
    #if QUALITY >= 2
    if (isOre) {
        oreGlow = getOreEmissiveFactor(albedo.rgb, blockId);
    }
    #endif
    
    // STRICT emissive for regular blocks
    bool isStandardEmissive = (blockLight > 0.95 && brightness > 0.55);
    
    bool isEmissive = isStandardEmissive || (oreGlow > 0.1) || isLightSource;
    float emissive = isEmissive ? 1.0 : 0.0;
    
    vec3 lightColor = vec3(0.0);
    
    // Light source blocks: use getLightSourceColor() for exact per-block color
    if (isLightSource) {
        lightColor = getLightSourceColor(blockId);
    } else if (isEmissive) {
        if (isOre) {
            lightColor = getEmissiveLightColor(albedo.rgb, 1.0);
            
            // PLEASANT GLOW: Pulse animation (quality-dependent intensity)
            #if QUALITY == 3
                float pulse = sin(frameTimeCounter * 1.8) * 0.15 + 0.85;
                vec3 glowRGB = mix(albedo.rgb, lightColor, 0.4);
                glowRGB *= 1.4 * pulse;
            #else
                float pulse = sin(frameTimeCounter * 1.5) * 0.1 + 0.9;
                vec3 glowRGB = mix(albedo.rgb, lightColor, 0.3);
                glowRGB *= 1.15 * pulse;
            #endif
            
            // Apply ONLY to ore pixels
            albedo.rgb = mix(albedo.rgb, glowRGB, oreGlow);
            
        } else {
            lightColor = getEmissiveLightColor(albedo.rgb, blockLight);
        }
    }
    
    // LabPBR Support
    vec3 worldNormal = N;
    float smoothness = 0.0;
    float metalness = 0.0;
    float pbrEmissive = 0.0;
    
    vec4 specData = texture2D(specular, texcoord);
    smoothness = specData.r;
    metalness = specData.g;
    pbrEmissive = specData.b;
    
    // ═══════════════════════════════════════════════════════════════════════
    // AUTO-PBR (If no PBR texture is found)
    // ═══════════════════════════════════════════════════════════════════════
    if (smoothness < 0.01 && metalness < 0.01) {
        // === METALLIC BLOCKS ===
        bool isIron = abs(blockId - 10011.0) < 0.1;
        bool isGold = abs(blockId - 10012.0) < 0.1;
        bool isCopper = abs(blockId - 10013.0) < 0.1;
        
        if (isIron) {
            metalness = 1.0;
            smoothness = 0.85;
        } else if (isGold) {
            metalness = 1.0;
            smoothness = 0.85;
        } else if (isCopper) {
            metalness = 0.9;
            smoothness = 0.75;
        }
        
        // === SMOOTH/POLISHED BLOCKS (non-metal reflections) ===
        // Quartz (10014) - Very smooth, strong reflection
        else if (abs(blockId - 10014.0) < 0.1) {
            smoothness = 0.75;
            metalness = 0.0;
        }
        // Polished Andesite (10015) - Moderate reflection
        else if (abs(blockId - 10015.0) < 0.1) {
            smoothness = 0.45;
            metalness = 0.0;
        }
        // Polished Granite (10016) - Moderate-strong reflection
        else if (abs(blockId - 10016.0) < 0.1) {
            smoothness = 0.55;
            metalness = 0.0;
        }
        // Polished Diorite (10017) - Moderate reflection
        else if (abs(blockId - 10017.0) < 0.1) {
            smoothness = 0.50;
            metalness = 0.0;
        }
        // Polished Blackstone (10018) - Strong, dark reflection
        else if (abs(blockId - 10018.0) < 0.1) {
            smoothness = 0.65;
            metalness = 0.0;
        }
        // Polished Deepslate (10019) - Strong, dark reflection
        else if (abs(blockId - 10019.0) < 0.1) {
            smoothness = 0.60;
            metalness = 0.0;
        }
        
        // === VALUABLE/GEM BLOCKS ===
        // Diamond Block (10024) - Very strong, crystalline reflection
        else if (abs(blockId - 10024.0) < 0.1) {
            smoothness = 0.92;
            metalness = 0.3;
        }
        // Emerald Block (10025) - Strong gem reflection
        else if (abs(blockId - 10025.0) < 0.1) {
            smoothness = 0.88;
            metalness = 0.25;
        }
        // Lapis Block (10026) - Moderate gem reflection
        else if (abs(blockId - 10026.0) < 0.1) {
            smoothness = 0.70;
            metalness = 0.15;
        }
        // Amethyst Block (10027) - Crystalline, slightly rough
        else if (abs(blockId - 10027.0) < 0.1) {
            smoothness = 0.80;
            metalness = 0.2;
        }
        // Netherite Block (10028) - Dark metallic
        else if (abs(blockId - 10028.0) < 0.1) {
            smoothness = 0.70;
            metalness = 0.95;
        }
        // Obsidian (10029) - Volcanic glass, very smooth and dark
        else if (abs(blockId - 10029.0) < 0.1) {
            smoothness = 0.85;
            metalness = 0.0;
        }
    }
    // ═══════════════════════════════════════════════════════════════════════
    
    vec4 normData = texture2D(normals, texcoord);
    if (length(normData.rgb) > 0.01) {
        vec3 normalMap = normData.rgb * 2.0 - 1.0;
        mat3 TBN = mat3(tangent, binormal, N);
        worldNormal = normalize(TBN * normalMap);
    }
    
    gl_FragData[0] = albedo;
    gl_FragData[1] = vec4(worldNormal * 0.5 + 0.5, skyLight);
    
    // For ores, fake block light for glow, weighted by ore factor
    float outputBlockLight = isOre ? mix(blockLight, 1.0, oreGlow) : blockLight;
    gl_FragData[2] = vec4(outputBlockLight, emissive, 0.0, 1.0);
    
    gl_FragData[3] = vec4(lightColor, 1.0);
    gl_FragData[4] = vec4(smoothness, metalness, pbrEmissive, 1.0); // colortex5
}
