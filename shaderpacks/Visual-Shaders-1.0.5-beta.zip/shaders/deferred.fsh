#version 120

// VISUAL SHADERS - Deferred Pass: Light Color Flood Fill
// Spreads light source colors from colortex3 outward so that
// illuminated surfaces receive the correct light color.
// Writes blurred result to colortex6 (read by composite).

varying vec2 texcoord;

uniform sampler2D colortex3;   // Raw light colors (only light source pixels have data)
uniform sampler2D colortex2;   // Block light (R channel)
uniform float viewWidth;
uniform float viewHeight;

#ifndef QUALITY
  #define QUALITY 2
#endif

/* DRAWBUFFERS:6 */

void main() {
    vec2 uv = texcoord;
    vec2 texel = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    
    // Check if this pixel IS a light source — keep exact color
    vec3 centerColor = texture2D(colortex3, uv).rgb;
    if (length(centerColor) > 0.1) {
        gl_FragData[0] = vec4(centerColor, 1.0);
        return;
    }
    
    // Check block light — skip search for completely unlit pixels
    float blockLight = texture2D(colortex2, uv).r;
    if (blockLight < 0.03) {
        gl_FragData[0] = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }
    
    // Golden angle spiral search — find nearby light source colors
    // This dedicated pass can afford more samples than inline search
    vec3 accum = vec3(0.0);
    float totalWeight = 0.0;
    
    float goldenAngle = 2.39996322;
    
    #if QUALITY >= 3
      int numSamples = 48;
      float maxRadius = 200.0;
    #elif QUALITY >= 2
      int numSamples = 32;
      float maxRadius = 160.0;
    #else
      int numSamples = 20;
      float maxRadius = 100.0;
    #endif
    
    for (int i = 0; i < numSamples; i++) {
        float r = sqrt(float(i + 1) / float(numSamples)) * maxRadius;
        float angle = float(i) * goldenAngle;
        vec2 offset = vec2(cos(angle), sin(angle)) * r * texel;
        
        vec3 sampleColor = texture2D(colortex3, uv + offset).rgb;
        if (length(sampleColor) > 0.1) {
            // Inverse-distance weighting: closer sources dominate
            float w = 1.0 / (r * r * 0.001 + 1.0);
            accum += sampleColor * w;
            totalWeight += w;
        }
    }
    
    vec3 result = vec3(0.0);
    if (totalWeight > 0.0) {
        result = accum / totalWeight;
    }
    
    gl_FragData[0] = vec4(result, 1.0);
}
