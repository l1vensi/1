#version 120

// VISUAL SHADERS - Deferred Pass (Light Color Blur)
varying vec2 texcoord;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
}
