#version 120

// VISUAL SHADERS - Advanced Shadow Vertex Shader
// Features: Shadow Distortion, Transparency Support, Colored Shadows

varying vec2 texcoord;
varying vec4 glColor;
varying float blockId;

attribute float mc_Entity;

// Shadow distortion constant (higher = more quality near player, less far)
#define SHADOW_DISTORT_FACTOR 0.10

// Shadow distortion function
vec3 distort(vec3 shadowPos) {
    float distortFactor = length(shadowPos.xy) + SHADOW_DISTORT_FACTOR;
    shadowPos.xy /= distortFactor;
    shadowPos.z *= 0.5; // Reduce Z range for better depth precision
    return shadowPos;
}

void main() {
    // Standard shadow transformation
    gl_Position = ftransform();
    
    // Apply shadow distortion
    gl_Position.xyz = distort(gl_Position.xyz);
    
    // Pass texture coordinates, vertex color, and block ID
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
    glColor = gl_Color;
    blockId = mc_Entity;
}
