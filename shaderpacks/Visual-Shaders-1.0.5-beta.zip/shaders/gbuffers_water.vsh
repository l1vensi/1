#version 120

// VISUAL SHADERS - Water/Glass Vertex Shader
// Procedural ocean waves based on afl_ext algorithm (Shadertoy: MdXyzX)

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glColor;
varying vec3 normal;
varying vec3 worldPos;
varying vec3 viewPos;

attribute float mc_Entity;
varying float blockId;

attribute vec4 at_tangent;
varying vec3 tangent;
varying vec3 binormal;

// Varying for wave normal computation in fragment shader
varying vec3 feetPlayerPos;

uniform vec3 cameraPosition;
uniform float frameTimeCounter;

// Quality setting
#ifndef QUALITY
  #define QUALITY 2
#endif

// Wave parameters
#define PI 3.14159265
#define DRAG_MULT 0.38

#ifndef WATER_WAVE_DEPTH
  #define WATER_WAVE_DEPTH 0.3
#endif
#ifndef WATER_WAVE_SPEED
  #define WATER_WAVE_SPEED 1.0
#endif
#define WAVE_DEPTH WATER_WAVE_DEPTH

// ═══════════════════════════════════════════════════════════════════════════
// PROCEDURAL WAVE FUNCTIONS (afl_ext - MIT License)
// ═══════════════════════════════════════════════════════════════════════════

// Returns vec2(wave value, derivative) for gradient computation
vec2 wavedx(vec2 position, vec2 direction, float frequency, float timeshift) {
    float x = dot(direction, position) * frequency + timeshift;
    x = mod(x, 2.0 * PI);
    float wave = exp(sin(x) - 1.0) * 0.5;
    float dx = wave * cos(x);
    return vec2(wave, -dx);
}

// Compute wave height at a world XZ position using 16 octaves
float waveHeight(vec2 position) {
    float wavePhaseShift = length(position) * 0.1;
    float iter = 0.0;
    float frequency = 1.0;
    float timeMultiplier = 2.0;
    float weight = 1.0;
    float sumOfValues = 0.0;
    float sumOfWeights = 0.0;
    
    // Quality-dependent octave count
    #if QUALITY == 1
    const int WAVE_OCTAVES = 8;
    #elif QUALITY == 3
    const int WAVE_OCTAVES = 16;
    #else
    const int WAVE_OCTAVES = 12;
    #endif
    
    for (int i = 0; i < WAVE_OCTAVES; i++) {
        // Direction from iteration (pseudo-random angle)
        float angle = mod(iter, 2.0 * PI);
        vec2 p = vec2(sin(angle), cos(angle));
        
        vec2 res = wavedx(position, p, frequency, frameTimeCounter * WATER_WAVE_SPEED * timeMultiplier + wavePhaseShift);
        
        // Shift position along wave direction (domain warping)
        position += p * res.y * weight * DRAG_MULT;
        
        // Accumulate weighted result
        sumOfValues += res.x * weight;
        sumOfWeights += weight;
        
        // Modify parameters for next octave
        weight = mix(weight, 0.0, 0.2);
        frequency *= 1.18;
        timeMultiplier *= 1.07;
        iter += 1232.399963;
    }
    
    return sumOfValues / sumOfWeights;
}

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glColor = gl_Color;
    normal = normalize(gl_NormalMatrix * gl_Normal);
    tangent = normalize(gl_NormalMatrix * at_tangent.xyz);
    binormal = cross(normal, tangent) * at_tangent.w;
    blockId = mc_Entity;
    
    // Compute feet-player-space position (world-relative to camera)
    vec4 localVertex = gl_Vertex;
    feetPlayerPos = localVertex.xyz;
    
    // Check if this is water
    bool isWater = mc_Entity > 9999.5 && mc_Entity < 10000.5;
    
    // Apply procedural wave displacement to water vertices
    if (isWater && gl_Normal.y > 0.5) {
        vec2 worldXZ = feetPlayerPos.xz + cameraPosition.xz;
        float waveH = waveHeight(worldXZ);
        
        // Displace vertices at the top face of water
        localVertex.y += (waveH - 0.5) * WAVE_DEPTH;
        
        // Update feetPlayerPos with displaced position
        feetPlayerPos = localVertex.xyz;
    }
    
    viewPos = (gl_ModelViewMatrix * localVertex).xyz;
    worldPos = localVertex.xyz + cameraPosition;
    
    gl_Position = gl_ModelViewProjectionMatrix * localVertex;
}
