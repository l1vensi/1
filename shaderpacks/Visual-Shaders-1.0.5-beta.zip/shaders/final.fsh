#version 120

// VISUAL SHADERS - Final Pass (Quality-dependent post-processing)
varying vec2 texcoord;

uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;

// Quality setting
#ifndef QUALITY
  #define QUALITY 2
#endif

// ACES tone mapping
vec3 ACESFilm(vec3 x) {
    float a = 2.51;
    float b = 0.03;
    float c = 2.43;
    float d = 0.59;
    float e = 0.14;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

// Simple Reinhard tonemapping (for Min quality)
vec3 ReinhardTonemap(vec3 x) {
    return x / (x + vec3(1.0));
}

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;
    
#if QUALITY == 1
    // ═══════════════════════════════════════════════════════════════════
    // MINIMUM — no bloom, simple tonemapping, no vignette
    // ═══════════════════════════════════════════════════════════════════
    
    color *= 0.85;
    color = ReinhardTonemap(color);
    color = pow(color, vec3(1.0 / 2.2));

#elif QUALITY == 3
    // ═══════════════════════════════════════════════════════════════════
    // ULTRA — full bloom, ACES, color grading, vignette, saturation
    // ═══════════════════════════════════════════════════════════════════
    
    // High-quality 13-tap bloom
    vec2 texelSize = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    vec3 bloom = vec3(0.0);
    float totalWeight = 0.0;
    
    // 13-tap Gaussian-like kernel (cross + diagonals)
    // Center
    bloom += texture2D(colortex0, texcoord).rgb * 4.0;
    totalWeight += 4.0;
    
    // Cross (4 samples)
    bloom += texture2D(colortex0, texcoord + vec2( 1.0, 0.0) * texelSize * 2.0).rgb * 2.0;
    bloom += texture2D(colortex0, texcoord + vec2(-1.0, 0.0) * texelSize * 2.0).rgb * 2.0;
    bloom += texture2D(colortex0, texcoord + vec2( 0.0, 1.0) * texelSize * 2.0).rgb * 2.0;
    bloom += texture2D(colortex0, texcoord + vec2( 0.0,-1.0) * texelSize * 2.0).rgb * 2.0;
    totalWeight += 8.0;
    
    // Diagonals (4 samples)
    bloom += texture2D(colortex0, texcoord + vec2( 1.0, 1.0) * texelSize * 2.0).rgb * 1.0;
    bloom += texture2D(colortex0, texcoord + vec2(-1.0, 1.0) * texelSize * 2.0).rgb * 1.0;
    bloom += texture2D(colortex0, texcoord + vec2( 1.0,-1.0) * texelSize * 2.0).rgb * 1.0;
    bloom += texture2D(colortex0, texcoord + vec2(-1.0,-1.0) * texelSize * 2.0).rgb * 1.0;
    totalWeight += 4.0;
    
    // Wide samples (4 samples) — для более широкого glow
    bloom += texture2D(colortex0, texcoord + vec2( 2.0, 0.0) * texelSize * 4.0).rgb * 0.5;
    bloom += texture2D(colortex0, texcoord + vec2(-2.0, 0.0) * texelSize * 4.0).rgb * 0.5;
    bloom += texture2D(colortex0, texcoord + vec2( 0.0, 2.0) * texelSize * 4.0).rgb * 0.5;
    bloom += texture2D(colortex0, texcoord + vec2( 0.0,-2.0) * texelSize * 4.0).rgb * 0.5;
    totalWeight += 2.0;
    
    bloom /= totalWeight;
    
    // Extract bright parts for bloom contribution
    float bloomBrightness = max(bloom.r, max(bloom.g, bloom.b));
    vec3 bloomContrib = bloom * smoothstep(0.3, 1.0, bloomBrightness);
    
    // Mix bloom with scene
    color = color + bloomContrib * 0.35;
    
    // Exposure
    color *= 0.85;
    
    // ACES tone mapping
    color = ACESFilm(color);
    
    // Gamma correction
    color = pow(color, vec3(1.0 / 2.2));
    
    // Color grading — warm highlights, cool shadows
    float luminance = dot(color, vec3(0.2126, 0.7152, 0.0722));
    vec3 warmShift = vec3(1.02, 1.0, 0.97); // warm highlights
    vec3 coolShift = vec3(0.97, 0.99, 1.04); // cool shadows
    vec3 grading = mix(coolShift, warmShift, luminance);
    color *= grading;
    
    // Saturation boost (+15%)
    vec3 grey = vec3(luminance);
    color = mix(grey, color, 1.15);
    
    // Vignette (stronger on Ultra)
    vec2 center = texcoord - 0.5;
    float vignette = 1.0 - dot(center, center) * 0.4;
    color *= vignette;

#else
    // ═══════════════════════════════════════════════════════════════════
    // MEDIUM — light bloom, ACES, light vignette, slight saturation
    // ═══════════════════════════════════════════════════════════════════
    
    // 5-tap bloom (fast)
    vec2 texelSize = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    vec3 bloom = color * 2.0;
    bloom += texture2D(colortex0, texcoord + vec2( 1.5, 0.0) * texelSize).rgb;
    bloom += texture2D(colortex0, texcoord + vec2(-1.5, 0.0) * texelSize).rgb;
    bloom += texture2D(colortex0, texcoord + vec2( 0.0, 1.5) * texelSize).rgb;
    bloom += texture2D(colortex0, texcoord + vec2( 0.0,-1.5) * texelSize).rgb;
    bloom /= 6.0;
    
    float bloomBrightness = max(bloom.r, max(bloom.g, bloom.b));
    vec3 bloomContrib = bloom * smoothstep(0.4, 1.2, bloomBrightness);
    
    color = color + bloomContrib * 0.15;
    
    // Exposure
    color *= 0.85;
    
    // ACES tone mapping
    color = ACESFilm(color);
    
    // Gamma correction
    color = pow(color, vec3(1.0 / 2.2));
    
    // Slight saturation boost (+8%)
    float luminance = dot(color, vec3(0.2126, 0.7152, 0.0722));
    vec3 grey = vec3(luminance);
    color = mix(grey, color, 1.08);
    
    // Light vignette
    vec2 center = texcoord - 0.5;
    float vignette = 1.0 - dot(center, center) * 0.25;
    color *= vignette;

#endif
    
    gl_FragColor = vec4(color, 1.0);
}
