#version 120

// VISUAL SHADERS - Water/Glass Fragment Shader (G-Buffer Output)
// Procedural wave normals for water, PBR material output
// Reflections and refraction are handled in composite1.fsh

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glColor;
varying vec3 normal;
varying vec3 worldPos;
varying vec3 viewPos;
varying float blockId;
varying vec3 feetPlayerPos;

uniform sampler2D texture;
uniform sampler2D specular;
uniform sampler2D normals;

uniform int isEyeInWater;
uniform float frameTimeCounter;
uniform vec3 cameraPosition;

varying vec3 tangent;
varying vec3 binormal;

// Quality setting
#ifndef QUALITY
  #define QUALITY 2
#endif

/* DRAWBUFFERS:01235 */

// ═══════════════════════════════════════════════════════════════════════════
// CONSTANTS
// ═══════════════════════════════════════════════════════════════════════════

#define PI 3.14159265
#define DRAG_MULT 0.38
#define WAVE_E 0.01

#ifndef WATER_WAVE_DEPTH
  #define WATER_WAVE_DEPTH 0.3
#endif
#ifndef WATER_WAVE_SPEED
  #define WATER_WAVE_SPEED 1.0
#endif
#define WAVE_DEPTH WATER_WAVE_DEPTH

#define WATER_TINT vec3(0.05, 0.15, 0.25)

// ═══════════════════════════════════════════════════════════════════════════
// PROCEDURAL WAVE FUNCTIONS (same algorithm as vertex shader)
// Needed here for normal computation via finite differences
// ═══════════════════════════════════════════════════════════════════════════

vec2 wavedx(vec2 position, vec2 direction, float frequency, float timeshift) {
    float x = dot(direction, position) * frequency + timeshift;
    x = mod(x, 2.0 * PI);
    float wave = exp(sin(x) - 1.0) * 0.5;
    float dx = wave * cos(x);
    return vec2(wave, -dx);
}

float waveHeight(vec2 position) {
    float wavePhaseShift = length(position) * 0.1;
    float iter = 0.0;
    float frequency = 1.0;
    float timeMultiplier = 2.0;
    float weight = 1.0;
    float sumOfValues = 0.0;
    float sumOfWeights = 0.0;
    
    #if QUALITY == 1
    const int WAVE_OCTAVES = 8;
    #elif QUALITY == 3
    const int WAVE_OCTAVES = 16;
    #else
    const int WAVE_OCTAVES = 12;
    #endif
    
    for (int i = 0; i < WAVE_OCTAVES; i++) {
        float angle = mod(iter, 2.0 * PI);
        vec2 p = vec2(sin(angle), cos(angle));
        
        vec2 res = wavedx(position, p, frequency, frameTimeCounter * WATER_WAVE_SPEED * timeMultiplier + wavePhaseShift);
        
        position += p * res.y * weight * DRAG_MULT;
        
        sumOfValues += res.x * weight;
        sumOfWeights += weight;
        
        weight = mix(weight, 0.0, 0.2);
        frequency *= 1.18;
        timeMultiplier *= 1.07;
        iter += 1232.399963;
    }
    
    return sumOfValues / sumOfWeights;
}

// Compute wave normal via finite differences (3-point gradient)
vec3 computeWaveNormal(vec2 pos, vec3 worldFaceNormal) {
    // Only compute for upward-facing surfaces
    if (dot(worldFaceNormal, vec3(0.0, 1.0, 0.0)) <= 0.1) {
        return worldFaceNormal;
    }
    
    // Sample height at 3 points
    vec2 ex = vec2(WAVE_E, 0.0);
    float H  = waveHeight(pos) * WAVE_DEPTH;
    float Hx = waveHeight(pos - ex.xy) * WAVE_DEPTH;
    float Hz = waveHeight(pos + ex.yx) * WAVE_DEPTH;
    
    // Construct gradient vectors
    vec3 a = vec3(pos.x, H, pos.y);
    vec3 b = vec3(pos.x - WAVE_E, Hx, pos.y);
    vec3 c = vec3(pos.x, Hz, pos.y + WAVE_E);
    
    vec3 waveN = normalize(cross(a - b, a - c));
    
    // Blend with face normal for smooth transition
    // The wave normal is already in "world" space (Y-up), so we can use it directly
    return normalize(waveN);
}

// ═══════════════════════════════════════════════════════════════════════════
// MAIN
// ═══════════════════════════════════════════════════════════════════════════

void main() {
    // Material detection
    bool isWater = blockId > 9999.5 && blockId < 10000.5;
    bool isGlass = abs(blockId - 10020.0) < 0.5;
    bool isStainedGlass = abs(blockId - 10021.0) < 0.5;
    bool isIce = abs(blockId - 10022.0) < 0.5;
    bool isPortal = abs(blockId - 10023.0) < 0.5;
    
    // Base color from texture
    vec4 albedo = texture2D(texture, texcoord) * glColor;
    
    // Alpha test
    if (albedo.a < 0.01) discard;
    
    vec3 N = normalize(normal);
    
    // ═══════════════════════════════════════════════════════════════════════
    // WATER: Procedural wave normals
    // ═══════════════════════════════════════════════════════════════════════
    
    vec3 waveNormal = N;
    
    if (isWater) {
        // Compute world XZ position for wave sampling
        vec2 worldXZ = feetPlayerPos.xz + cameraPosition.xz;
        
        // Get face normal in world space (view->world transform via inverse model-view)
        // Since N is in view space (from gl_NormalMatrix), we need the world face normal
        // For water, the face normal is typically (0,1,0) in world space
        vec3 worldFaceNormal = vec3(0.0, 1.0, 0.0);
        
        // Compute procedural wave normal
        waveNormal = computeWaveNormal(worldXZ, worldFaceNormal);
        
        // Transform wave normal from world space back to view space for G-buffer output
        // gl_NormalMatrix transforms object->view, for world->view we use it directly
        // since in Minecraft, object space ≈ world space (after camera offset)
        waveNormal = normalize(gl_NormalMatrix * waveNormal);
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // MATERIAL OUTPUT
    // ═══════════════════════════════════════════════════════════════════════
    
    vec3 finalColor;
    float finalAlpha;
    
    // Material ID for composite1 to identify material type:
    // 0.8 = water, 0.85 = glass, 0.9 = stained glass, 0.95 = ice, 0.75 = portal
    float materialId = 0.0;
    
    if (isWater) {
        vec3 tint = WATER_TINT * lmcoord.y;
        finalColor = tint;
        finalAlpha = 0.1; // Mostly transparent so composite1 can do physical volumetric murkiness
        materialId = 0.8;
    } else if (isPortal) {
        // Nether portal: vibrant purple with pulsing glow
        vec3 portalColor = albedo.rgb;
        float pulse = sin(frameTimeCounter * 2.0) * 0.15 + 0.85;
        portalColor = max(portalColor, vec3(0.3, 0.05, 0.5)) * pulse;
        finalColor = portalColor;
        finalAlpha = 0.8;
        materialId = 0.75;
    } else if (isStainedGlass) {
        finalColor = albedo.rgb;
        finalAlpha = albedo.a * 0.9;
        materialId = 0.9;
    } else if (isIce) {
        vec3 iceTint = vec3(0.85, 0.92, 1.0);
        finalColor = albedo.rgb * iceTint;
        finalAlpha = 0.92;
        materialId = 0.95;
    } else if (isGlass) {
        finalColor = albedo.rgb;
        finalAlpha = 0.3;
        materialId = 0.85;
    } else {
        // Unknown translucent blocks — render normally (don't discard!)
        finalColor = albedo.rgb;
        finalAlpha = albedo.a;
        materialId = 0.0;
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // PBR / NORMAL OUTPUT
    // ═══════════════════════════════════════════════════════════════════════
    
    // Use wave normal for water, standard normal for others
    vec3 worldNormal = isWater ? waveNormal : N;
    float smoothness = 0.0;
    float metalness = 0.0;
    float pbrEmissive = 0.0;
    
    if (isWater) {
        // Water PBR: perfectly smooth, non-metallic (like waterMaterial in docs)
        smoothness = 1.0;
        metalness = 0.0;
    } else {
        // LabPBR Support for non-water materials
        vec4 specData = texture2D(specular, texcoord);
        smoothness = specData.r;
        metalness = specData.g;
        pbrEmissive = specData.b;
        
        vec4 normData = texture2D(normals, texcoord);
        if (length(normData.rgb) > 0.01) {
            vec3 normalMap = normData.rgb * 2.0 - 1.0;
            mat3 TBN = mat3(tangent, binormal, N);
            worldNormal = normalize(TBN * normalMap);
        }
    }
    
    // Stained glass: output its color as a light source to colortex3
    vec3 glassLightColor = vec3(0.0);
    if (isStainedGlass) {
        vec3 raw = albedo.rgb;
        float maxC = max(raw.r, max(raw.g, raw.b));
        float minC = min(raw.r, min(raw.g, raw.b));
        float sat = maxC - minC;
        if (sat > 0.05 && maxC > 0.1) {
            glassLightColor = (raw / (maxC + 0.001)) * 1.2;
        }
    } else if (isPortal) {
        glassLightColor = vec3(0.5, 0.1, 0.9); // Purple glow
    }
    
    // Output to G-buffers
    gl_FragData[0] = vec4(finalColor, finalAlpha);                // colortex0: Albedo + alpha
    gl_FragData[1] = vec4(worldNormal * 0.5 + 0.5, lmcoord.y);   // colortex1: Normal + skylight
    gl_FragData[2] = vec4(lmcoord.x, materialId, 0.0, 1.0);      // colortex2: blockLight + materialId
    gl_FragData[3] = vec4(glassLightColor, 1.0);                  // colortex3: Light Color
    gl_FragData[4] = vec4(smoothness, metalness, pbrEmissive, 1.0); // colortex5: PBR Data
}
