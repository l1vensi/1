#version 430 compatibility
#define DIMENSION_OVERWORLD

#include "/program/composite14.fsh"
