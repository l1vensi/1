#version 430 compatibility
#define DIMENSION_OVERWORLD

#include "/program/gbuffers_armor_glint.fsh"