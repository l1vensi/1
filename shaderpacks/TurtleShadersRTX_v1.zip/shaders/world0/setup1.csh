#version 430 compatibility
#define DIMENSION_OVERWORLD

#include "/program/setup1.csh"