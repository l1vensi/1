#version 430 compatibility
#define DIMENSION_OVERWORLD

#include "/program/dh_water.vsh"