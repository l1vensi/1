#version 430 compatibility
#define DIMENSION_OVERWORLD

#include "/program/composite3.fsh"