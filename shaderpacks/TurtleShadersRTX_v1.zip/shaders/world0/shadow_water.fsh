#version 430 compatibility
#define DIMENSION_OVERWORLD

#include "/program/shadow_water.fsh"