#version 430 compatibility
#define DIMENSION_OVERWORLD

#include "/program/composite1.vsh"
