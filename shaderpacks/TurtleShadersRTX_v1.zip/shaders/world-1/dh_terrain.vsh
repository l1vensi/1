#version 430 compatibility
#define DIMENSION_NETHER

#include "/program/dh_terrain.vsh"