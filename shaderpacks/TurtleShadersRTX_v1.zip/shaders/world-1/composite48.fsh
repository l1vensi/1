#version 430 compatibility
#define DIMENSION_NETHER

#include "/program/composite48.fsh"