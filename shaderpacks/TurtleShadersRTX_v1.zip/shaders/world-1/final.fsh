#version 430 compatibility
#define DIMENSION_NETHER

#include "/program/final.fsh"
