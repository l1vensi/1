#version 430 compatibility
#define DIMENSION_NETHER

#include "/program/gbuffers_particles_translucent.fsh"
