#version 430 compatibility
#define DIMENSION_NETHER

#include "/program/gbuffers_hand.fsh"
