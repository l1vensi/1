#version 430 compatibility
#define DIMENSION_NETHER

#include "/program/shadow_water.vsh"