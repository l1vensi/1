#version 430 compatibility
#define DIMENSION_NETHER

#include "/program/composite50.vsh"