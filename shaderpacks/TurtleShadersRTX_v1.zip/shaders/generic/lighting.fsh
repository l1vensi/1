#include "/generic/gtao.glsl"

vec3 calc_lighting(Positions Pos, bool IsDH, vec2 texcoord, vec3 Color, float Material, float PackSSS, float Emissiveness, vec2 Lightmap,
    vec3 Normal, vec3 FlatNormal, bool IsHand, out vec4 ShadowBuf) {

    #ifdef LIGHT_BLOCK_GLOW
    bool IsLightBlock = int(Material) == MATERIAL_EMISSIVE;
    if (IsLightBlock) {
        Emissiveness = max(Emissiveness, LIGHT_BLOCK_EMISSIVENESS);
    }
    #endif

    Color += Color * Emissiveness * 2.0 * float(Emissiveness < 1.0);

    #ifdef LIGHT_BLOCK_GLOW
    if (IsLightBlock) {
        vec3 warmGlow = mix(TorchlightColor, Color, 0.55);
        Color += Color * LIGHT_BLOCK_GLOW_STRENGTH;
        Color += warmGlow * LIGHT_BLOCK_GLOW_STRENGTH * 0.35;
    }
    #endif

    if (Material >= MATERIAL_TALL_PLANT_LOWER && Material <= MATERIAL_SHORT_PLANT) {
        Normal = gbufferModelView[1].xyz; // upDirection
    }
    float NdotL = dot(sLightPosN, Normal);

    #ifdef LIGHT_BLOCK_GLOW
    Lightmap = IsLightBlock ? pow(Lightmap, vec2(1.5)) : pow4(Lightmap);
    #else
    Lightmap = pow4(Lightmap);
    #endif

    if (IsHand) {
        // Prevents a strange rare lightleak
        NdotL *= Lightmap.y;
    }

    #ifdef DIMENSION_OVERWORLD
    vec3 SunA = dataBuf.AmbientColor; // Value written in prepare, in the data buffer
    
    SunA = mix(MinLight, SunA, Lightmap.y);
    #elif defined DIMENSION_NETHER
    // Fake lighting, to make things look less flat
    float NdotU = dot(Normal, gbufferModelView[1].xyz);
    vec3 FakeLavaLight = TorchlightColor * 0.05 * (-NdotU * 0.5 + 0.5);
    vec3 FakeAmbientLight = fogColor.rgb * 0.15 * (NdotU * 0.5 + 0.5);
    vec3 SunA = MinLight + FakeAmbientLight + FakeLavaLight;
    #else
    vec3 SunA = vec3(1);
    #endif

    float BlockLight = Lightmap.x;
    #ifdef LIGHT_BLOCK_GLOW
    if (IsLightBlock) BlockLight = max(BlockLight, LIGHT_BLOCK_MIN_BLOCK_LIGHT);
    #endif
    vec3 OutColor = Color * (SunA + BlockLight * TorchlightColor);

    float SSSS = PackSSS;
    if (PackSSS > 64.0 / 255.0 || PackSSS == 0) {
        if (Material == MATERIAL_SSS_WEAK) SSSS = SSS_STRENGTH_WEAK;
        else if (Material >= MATERIAL_SSS_STRONG && Material <= MATERIAL_LEAVES) SSSS = SSS_STRENGTH_STRONG;
        else SSSS = 0;
    }
    bool DoSSS = SSSS > 0;

    vec3 SunDirect = vec3(0);
    bool IsMetal, IsHardcodedMetal;
    vec3 Shadow = vec3(0);
    mat2x3 F0 = get_reflectance(texcoord, Material, Color, IsMetal, IsHardcodedMetal);
    if (NdotL > 0 || DoSSS) {
        Shadow = get_shadow(Pos.Player, Pos.View, IsDH, FlatNormal, Lightmap.y, DoSSS, ivec2(gl_FragCoord.xy));

        if (Shadow != vec3(0)) {
            vec3 LightColor;
            if (sunAngle < 0.5)
                LightColor = dataBuf.SunColor;
            else
                LightColor = dataBuf.MoonColor;

            float LHeight = sin(sunAngle * TAU); // to_player_pos(sunPosN).y;
            LightColor *= smoothstep(0, 0.05, abs(LHeight));

            SunDirect = Color / PI * max(0.1, float(!IsMetal));
            SunDirect *= LightColor * max(NdotL, 0);

            if (DoSSS) {
                SSSS = (1 - SSSS) * 5;

                float SSS = exp(-SSSS * abs(NdotL));
                float Phase = max(ISOTROPIC_PHASE, cs_phase(dot(Pos.ViewN, sLightPosN), 0.6));
                SunDirect += Color.rgb * LightColor * SSS * Phase;
            }
        }
    }
    #ifdef LIGHT_BLOCK_GLOW
    if (IsLightBlock) {
        Shadow = max(Shadow, vec3(LIGHT_BLOCK_SHADOW_MIN));
    }
    #endif

    OutColor = OutColor + SunDirect * Shadow;

    #ifdef LIGHT_BLOCK_GLOW
    if (IsLightBlock) {
        OutColor = max(OutColor, Color * LIGHT_BLOCK_MIN_BRIGHTNESS);
    }
    #endif

    ShadowBuf.r = get_luminance(Shadow);
    ShadowBuf.gba = vec3(0);

    return OutColor * max(0.33, float(!IsMetal));
}
