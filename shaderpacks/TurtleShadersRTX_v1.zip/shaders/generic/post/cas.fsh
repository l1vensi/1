vec3 CAS(sampler2D Sampler, vec2 Coords) {
    // fetch a 3x3 neighborhood around the pixel 'e',
    vec3 e = texture(Sampler, Coords).rgb;
    vec3 a = textureOffset(Sampler, Coords, ivec2(-1, -1)).rgb;
    vec3 b = textureOffset(Sampler, Coords, ivec2(0, -1)).rgb;
    vec3 c = textureOffset(Sampler, Coords, ivec2(1, -1)).rgb;
    vec3 d = textureOffset(Sampler, Coords, ivec2(-1, 0)).rgb;
    vec3 f = textureOffset(Sampler, Coords, ivec2(1, 0)).rgb;
    vec3 g = textureOffset(Sampler, Coords, ivec2(-1, 1)).rgb;
    vec3 h = textureOffset(Sampler, Coords, ivec2(0, 1)).rgb;
    vec3 i = textureOffset(Sampler, Coords, ivec2(1, 1)).rgb;

    // Soft min and max.
    vec3 mnRGB = min(min(min(d, e), min(f, b)), h);
    vec3 mnRGB2 = min(min(min(mnRGB, a), min(g, c)), i);
    mnRGB += mnRGB2;

    vec3 mxRGB = max(max(max(d, e), max(f, b)), h);
    vec3 mxRGB2 = max(max(max(mxRGB, a), max(g, c)), i);
    mxRGB += mxRGB2;

    // Smooth minimum distance to signal limit divided by smooth max.

    vec3 rcpMxRGB = vec3(1) / mxRGB;
    vec3 ampRGB = clamp((min(mnRGB, 2.0 - mxRGB) * rcpMxRGB), 0, 1);

    // Shaping amount of sharpening.
    ampRGB = inversesqrt(ampRGB);
    float peak = 8.0 - 3.0 * SHARPENING_AMOUNT;
    vec3 wRGB = -vec3(1) / (ampRGB * peak);
    vec3 rcpWeightRGB = vec3(1) / (1.0 + 4.0 * wRGB);

    vec3 window = (b + d) + (f + h);
    vec3 outColor = clamp((window * wRGB + e) * rcpWeightRGB, 0, 1);

    return outColor;
}
