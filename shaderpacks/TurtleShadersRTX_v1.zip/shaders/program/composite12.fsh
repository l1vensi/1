#include "/lib/all_the_libs.glsl"

#include "/generic/post/bloom.glsl"
in vec2 texcoord;
const bool colortex0MipmapEnabled = true;

// Draws to some random buffer
// I will definetly forget about this
/* RENDERTARGETS:12 */

void main() {
    vec3 Color = blur6x6(colortex0, texcoord) / 10;
    write_bloom(ivec2(gl_FragCoord.xy), Color, false);
    discard;
}
