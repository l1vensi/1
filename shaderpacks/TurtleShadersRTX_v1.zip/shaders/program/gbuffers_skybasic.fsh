#include "/lib/all_the_libs.glsl"

void main() {
    /* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(0);
}
