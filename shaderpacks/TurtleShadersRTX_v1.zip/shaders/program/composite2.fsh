#define DEFERRED

#include "/lib/all_the_libs.glsl"

in vec2 texcoord;
flat in vec3 LightColorDirect; // This needs to be initialized in the vertex stage of the pass

#include "/generic/water.glsl"
#include "/generic/shadow/main.glsl"
#include "/generic/gtao.glsl"
#include "/generic/sky.glsl"
#include "/generic/shadow/vl.glsl"
#include "/generic/fog.glsl"
#include "/generic/clouds.glsl"
#include "/generic/reflections.glsl"
#include "/generic/shadow/rsm.glsl"
#include "/generic/post/taa.glsl"

#ifdef SPATIAL_DENOISING
    /* DRAWBUFFERS:03 */
#else
    /* DRAWBUFFERS:0 */
#endif

layout(location = 0) out vec4 Color;
#ifdef SPATIAL_DENOISING
    layout(location = 1) out vec4 GIDenoise;
#endif

vec3 refract2(vec3 I, vec3 N, vec3 NF, float eta) {
    float NoI = dot(N, I);
    float k = 1.0 - eta * eta * (1.0 - NoI * NoI);
    if (k < 0.0) {
        return vec3(0.0);
    } else {
        float sqrtk = sqrt(k);
        vec3 R = (eta * dot(NF, I) + sqrtk) * NF - (eta * NoI + sqrtk) * N;
        return normalize(R * sqrt(abs(NoI)) + eta * I);
    }
}

void main() {
    #ifdef SPATIAL_DENOISING
        GIDenoise = vec4(0);
    #endif

    bool IsDH;
    float Depth = get_depth(texcoord, IsDH);
    Positions Pos = get_positions(texcoord, Depth, IsDH, true);
    bool IsHand = Depth <= 0.56;
    if (IsHand) {
        Depth = Depth * 2 - 1;
        Depth /= MC_HAND_DEPTH;
        Depth = Depth * 0.5 + 0.5;
    }

    float Dither = dither(gl_FragCoord.xy, true);

    if (Depth < 1) {
        vec4 Data = texture(colortex1, texcoord);
        vec4 Data2 = texture(colortex2, texcoord);
        vec2 UnpackX = unpackUnorm2x8(Data.x);
        vec2 UnpackY = unpackUnorm2x8(Data.y);
        float Material = UnpackY.y * 255;
        vec3 Normal = decodeUnitVector(unpackUnorm2x8(Data.w) * 2 - 1);
        if(Material == MATERIAL_WATER) {
            mat3 TBN = tbn_normal(Normal);
            Normal = TBN * get_water_normal(Pos.World, Normal, Pos.View.z);
        }
        Normal = player_view(Normal);
        
        vec3 FlatNormal = decodeUnitVector(unpackUnorm2x8(Data2.w) * 2 - 1);
        FlatNormal = player_view(FlatNormal);

        bool IsDH1;
        float Depth1 = get_depth_solid(texcoord, IsDH1);
        vec3 ViewPos1 = screen_view(vec3(Pos.Screen.xy, Depth1), IsDH1, true);
        if (Depth != Depth1 && Depth1 < 1) {
            vec3 RefractedDir = refract2(Pos.ViewN, Normal, FlatNormal, 0.7518);

            vec3 RefractedPos = ViewPos1 + RefractedDir * distance(Pos.View, ViewPos1);
            vec3 ScreenPosRef = view_screen(RefractedPos, IsDH1, true);

            vec4 NewDepths;
            if(IsDH1) {
                NewDepths = textureGather(dhDepthTex1, ScreenPosRef.xy, 0);
            } else {
                NewDepths = textureGather(depthtex1, ScreenPosRef.xy, 0);
            }
            float NewDepthClosest = min_component(NewDepths);
            if (NewDepthClosest < Depth)
                ScreenPosRef = Pos.Screen;
            else {
                Depth1 = lerp(NewDepths.x, NewDepths.y, NewDepths.z, NewDepths.w, ScreenPosRef.xy);
                ViewPos1 = screen_view(vec3(Pos.Screen.xy, Depth1), IsDH1, true);
            }

            Color = texture(colortex0, ScreenPosRef.xy);
        }
        else {
            Color = texture(colortex0, Pos.Screen.xy);
        }

        // Light water fog enabled
        if (Material == MATERIAL_WATER && isEyeInWater == 0) {
            vec3 PlayerPos1 = view_player(ViewPos1);
            float WaterDepth = distance(Pos.Player, PlayerPos1);
            float FogFactor = exp(-WaterDepth * 0.12);
            vec3 WaterFogColor = vec3(0.02, 0.1, 0.2) * (dataBuf.AmbientColor + 0.05);
            Color.rgb = mix(WaterFogColor, Color.rgb, FogFactor);
        }

        float Smoothness = get_smoothness(Pos.Screen.xy, Material);
        bool IsMetal, IsHardcodedMetal;
        mat2x3 Reflectance = get_reflectance(Pos.Screen.xy, Material, Color.rgb, IsMetal, IsHardcodedMetal);
        vec2 Lightmap = unpackUnorm2x8(Data2.x);

        // Wetness / Puddles
        #if (defined DIMENSION_OVERWORLD) && (defined WETNESS)
        if (rainStrength > 0.01 && isEyeInWater == 0 && Material < MATERIAL_TALL_PLANT_LOWER && Material != MATERIAL_WATER && Material != MATERIAL_FARMLAND) {
            vec3 WorldNormal = view_player(Normal);
            float Wetness = rainStrength * clamp(WorldNormal.y, 0.0, 1.0) * smoothstep(0.3, 0.9, Lightmap.y);
            
            float PuddleNoise = texture(waterNoise, Pos.World.xz * 0.08).r;
            PuddleNoise = smoothstep(0.2 - WETNESS_PUDDLES * 0.15, 0.85 - WETNESS_PUDDLES * 0.4, PuddleNoise);
            Wetness *= PuddleNoise;

            if (Wetness > 0.01) {
                Smoothness = mix(Smoothness, 0.98, Wetness);
                Color.rgb *= 1.0 - Wetness * 0.4;
                if (!IsMetal) {
                    Reflectance[0] = mix(Reflectance[0], vec3(0.04), Wetness); 
                }
                
                vec2 RipplePos = Pos.World.xz * 4.0;
                vec2 Ripples = texture(waterNoise, RipplePos + frameTimeCounter * 0.2).rg;
                Ripples += texture(waterNoise, RipplePos * 1.5 - frameTimeCounter * 0.15).rg;
                Normal = normalize(Normal + player_view(vec3(Ripples.x - 1.0, 0.0, Ripples.y - 1.0) * 0.02 * Wetness));
            }
        }
        #endif

        // Farmland Wetness (always applied)
        #if (defined DIMENSION_OVERWORLD) && (defined WETNESS)
        if (Material == MATERIAL_FARMLAND) {
            vec3 WorldNormal = view_player(Normal);
            float Wetness = 1.0 * clamp(WorldNormal.y, 0.0, 1.0) * smoothstep(0.3, 0.9, Lightmap.y);
            
            float PuddleNoise = texture(waterNoise, Pos.World.xz * 0.08).r;
            PuddleNoise = smoothstep(0.2 - WETNESS_PUDDLES * 0.15, 0.85 - WETNESS_PUDDLES * 0.4, PuddleNoise);
            Wetness *= PuddleNoise;
            
            if (Wetness > 0.01) {
                Smoothness = mix(Smoothness, 0.98, Wetness);
                Color.rgb *= 1.0 - Wetness * 0.3;
                if (!IsMetal) {
                    Reflectance[0] = mix(Reflectance[0], vec3(0.04), Wetness); 
                }
                
                vec2 RipplePos = Pos.World.xz * 4.0;
                vec2 Ripples = texture(waterNoise, RipplePos + frameTimeCounter * 0.2).rg;
                Ripples += texture(waterNoise, RipplePos * 1.5 - frameTimeCounter * 0.15).rg;
                Normal = normalize(Normal + player_view(vec3(Ripples.x - 1.0, 0.0, Ripples.y - 1.0) * 0.02 * Wetness));
            }
        }
        #endif

        // Farmland Wetness (always applied)
        #if (defined DIMENSION_OVERWORLD) && (defined WETNESS)
        if (Material == MATERIAL_FARMLAND) {
            vec3 WorldNormal = view_player(Normal);
            float Wetness = 1.0 * clamp(WorldNormal.y, 0.0, 1.0) * smoothstep(0.3, 0.9, Lightmap.y);
            
            float PuddleNoise = texture(waterNoise, Pos.World.xz * 0.08).r;
            PuddleNoise = smoothstep(0.2 - WETNESS_PUDDLES * 0.15, 0.85 - WETNESS_PUDDLES * 0.4, PuddleNoise);
            Wetness *= PuddleNoise;
            
            if (Wetness > 0.01) {
                Smoothness = mix(Smoothness, 0.98, Wetness);
                Color.rgb *= 1.0 - Wetness * 0.3;
                if (!IsMetal) {
                    Reflectance[0] = mix(Reflectance[0], vec3(0.04), Wetness); 
                }
                
                vec2 RipplePos = Pos.World.xz * 4.0;
                vec2 Ripples = texture(waterNoise, RipplePos + frameTimeCounter * 0.2).rg;
                Ripples += texture(waterNoise, RipplePos * 1.5 - frameTimeCounter * 0.15).rg;
                Normal = normalize(Normal + player_view(vec3(Ripples.x - 1.0, 0.0, Ripples.y - 1.0) * 0.02 * Wetness));
            }
        }
        #endif

        // Reflections (SSR — enabled on all blocks when BLOCK_REFLECTIONS is on)
        #ifdef BLOCK_REFLECTIONS
        float ReflectionThreshold = 0.15;
        #else
        float ReflectionThreshold = 0.3;
        #endif

        if (Smoothness > ReflectionThreshold && isEyeInWater == 0) {
            #if defined ROUGH_REFLECTIONS || defined BLOCK_REFLECTIONS
            bool RoughReflections = Smoothness < 0.95 && Material != MATERIAL_WATER;
            #else
            bool RoughReflections = false;
            #endif

            float RayCount = RoughReflections ? ROUGH_REFLECTIONS_STEPS : 1;
            vec2 Noise = blue_noise(gl_FragCoord.xy, true).rg;
            float Roughness = smoothness_to_roughness(Smoothness);
            mat3 TBN = tbn_normal(Normal);
            for(int i = 1; i <= RayCount; i++) {
                vec3 RefNormal;
                if(RoughReflections) {
                    float OffsetAng = (i + Noise.x) * TAU / RayCount;
                    vec2 Offset = Noise.y * vec2(cos(OffsetAng), sin(OffsetAng));
                    
                    RefNormal = TBN * SampleVndf_GGX(Offset * 0.5 + 0.5, -(TBN * Pos.ViewN), vec2(Roughness));
                } else {
                    RefNormal = Normal;
                }
            
                vec3 ReflectionBlendFactor = vec3(Smoothness / RayCount);

                if (IsHardcodedMetal) {
                    ReflectionBlendFactor *= fresnel_metals(RefNormal, -Pos.ViewN, Reflectance);
                } else {
                    ReflectionBlendFactor *= schlick(RefNormal, -Pos.ViewN, Reflectance[0]);
                }

                if(IsMetal) {
                    vec3 Albedo = vec3(UnpackX, UnpackY.x);
                    ReflectionBlendFactor *= Albedo;
                }

                #ifdef BLOCK_REFLECTIONS
                    if (!IsMetal && Material != MATERIAL_WATER) {
                        ReflectionBlendFactor *= BLOCK_REFLECTION_STRENGTH;
                    }
                #endif
                
                Color.rgb += ssr(RefNormal, Pos, IsDH, Lightmap.y, Dither) * ReflectionBlendFactor;
            }
        }

        // Specular
        float Shadow = texture(colortex5, Pos.Screen.xy).r;
        float NdotL = max(dot(sLightPosN, Normal), 0);
        Shadow *= NdotL;
        if (Shadow != 0) {
            vec3 H = normalize(sLightPosN - Pos.ViewN); // Half-way vector
            vec3 F;
            if (IsHardcodedMetal) {
                F = fresnel_metals(H, -Pos.ViewN, Reflectance);
            }
            else {
                F = schlick(H, -Pos.ViewN, Reflectance[0]);
            }

            vec3 Specular = cook_torrance(-Pos.ViewN, sLightPosN, Normal, 1 - (Smoothness), H, F);

            if(IsMetal) {
                vec3 Albedo = vec3(UnpackX, UnpackY.x);
                Specular *= Albedo;
            }
            
            Color.rgb += Specular * LightColorDirect * Shadow;
        }

        if (!IsHand) {
            float Gtao = 1;
            #ifdef GTAO
                if(Shadow < 0.01)
                    Gtao = gtao(Pos, IsDH, Normal, Shadow);
            #endif

            vec3 Rsm = vec3(0);
            #ifdef RSM
                #ifndef DIMENSION_NETHER
                if (!IsMetal)
                    Rsm = rsm(Pos.Player, Normal, LightColorDirect, Shadow);
                #endif
            #endif
            
            #ifdef SPATIAL_DENOISING
                GIDenoise = vec4(Rsm.rgb, 1 - Gtao);
            #endif

            #ifdef SSAO
                Color.rgb *= 1 - ssao(Normal, Pos.View, IsDH);
            #endif
        }

        
    }
    else {
        Color = texture(colortex0, texcoord);
        #ifdef SPATIAL_DENOISING
            GIDenoise = vec4(0, 0, 0, 1);
        #endif
    }

   
}
