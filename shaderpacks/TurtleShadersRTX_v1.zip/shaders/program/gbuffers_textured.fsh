#include "/lib/all_the_libs.glsl"
#include "/generic/gbuffers.fsh"

void main() {
 init_frag();
}

