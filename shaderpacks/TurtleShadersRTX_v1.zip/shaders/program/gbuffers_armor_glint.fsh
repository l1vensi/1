#include "/lib/all_the_libs.glsl"

in Data {
    vec2 lmcoord;
    vec2 texcoord;
    vec4 glcolor;
    flat uint Material;
    flat mat3 TBN;
    vec3 ViewPos;
} DataIn;

/* DRAWBUFFERS:0 */
layout(location = 0) out vec4 Color;

void main() {
	Color = texture(texture, DataIn.texcoord) * DataIn.glcolor;

    if (Color.a < 0.1) {
        discard;
        return;
    }

    Color.rgb = srgb_linear(Color.rgb);
}

