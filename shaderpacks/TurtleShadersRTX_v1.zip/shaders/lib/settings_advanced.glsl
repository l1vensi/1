const int shadowMapResolution = 2048; // [512 1024 2048 4096 8192]
const float shadowDistance = 192.0; // [64.0 96.0 128.0 192.0 256.0]
#define SHADOW_FILTER 2 // [0 1 2]

#define VL_OVERWORLD_MODE 1 // [0 1]
const bool VL_OVERWORLD_RT = bool(VL_OVERWORLD_MODE);
#define VL_WATER_MODE 1 // [0 1]
const bool VL_WATER_RT = bool(VL_WATER_MODE);
#define FOG_OVERWORLD_DETAIL true // [false true]
const bool VL_OVERWORLD_DETAIL = FOG_OVERWORLD_DETAIL;
#define VL_SAMPLES 12 // [4 8 12 16 20]

// #define SSAO
#define GTAO
#define RSM

#define PBR_NORMAL
#define PBR_SPECULAR
#define PBR_EMISSIVENESS
#define PBR_SSS
// #define PBR_POM
// #define ROUGH_REFLECTIONS