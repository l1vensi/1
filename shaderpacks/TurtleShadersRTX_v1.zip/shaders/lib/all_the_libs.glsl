#include "all_the_uniforms.glsl"

// #define USE_ADVANCED_SETTINGS

#ifdef USE_ADVANCED_SETTINGS
    #include "settings_advanced.glsl"
#else
    #include "settings_simple.glsl"
#endif

#include "settings_preferences.glsl"
#include "math.glsl"
#include "transformations.glsl"
#include "filters.glsl"
#include "light_colors.glsl"
#include "util.glsl"
#include "atmosphere.glsl"
#include "noise.glsl"
#include "lods.glsl"
#include "distort.glsl"
#include "kernels.glsl"
#include "packing.glsl"
#include "tonemap.glsl"
#include "materials.glsl"
#include "speculars.glsl"

