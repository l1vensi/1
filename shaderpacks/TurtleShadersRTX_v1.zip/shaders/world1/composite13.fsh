#version 430 compatibility
#define DIMENSION_END

#include "/program/composite13.fsh"
