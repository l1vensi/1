#version 430 compatibility
#define DIMENSION_END

#include "/program/shadow_water.vsh"