#version 430 compatibility
#define DIMENSION_END

#include "/program/gbuffers_clouds.vsh"
